# DirectPath

A KernelSU module that restores access to sites and services that a network
is interfering with — without a VPN, without a proxy app, and without
touching traffic it has no reason to touch.

It works on the connections of the apps you choose, for the destinations you
choose, and it is built so that the worst realistic failure is *your phone
goes back to behaving exactly as it did before you installed it*.

---

## Contents

- [What it actually does](#what-it-actually-does)
- [What it does not do](#what-it-does-not-do)
- [Requirements](#requirements)
- [Installing](#installing)
- [First run](#first-run)
- [Using the control panel](#using-the-control-panel)
- [Modes](#modes)
- [Choosing apps](#choosing-apps)
- [Destinations](#destinations)
- [Diagnostics](#diagnostics)
- [DNS](#dns)
- [IPv6 and QUIC](#ipv6-and-quic)
- [The command line](#the-command-line)
- [Updating](#updating)
- [Emergency recovery](#emergency-recovery)
- [Troubleshooting](#troubleshooting)
- [Uninstalling](#uninstalling)
- [Known limitations](#known-limitations)
- [How it works inside](#how-it-works-inside)
- [Building from source](#building-from-source)
- [Licence](#licence)

---

## What it actually does

Network interference usually happens at one of three layers, and each needs a
different answer. DirectPath addresses all three, separately, and tells you
which one it thinks is being used against you.

**Name resolution.** Many networks answer DNS queries for particular names
with an address that is not the real one — usually a block page, sometimes a
dead address. DirectPath can run a small local resolver that asks upstream
resolvers over TCP, checks the answers against a list of known sinkhole
addresses, and discards ones that look injected.

**The TLS handshake.** The first packet your phone sends to a website
contains the hostname in plain text, before any encryption starts. Equipment
in the middle reads that name and, if it does not like it, kills the
connection with a forged reset. DirectPath handles the connections of your
chosen apps locally and sends that first message in a way that is still
perfectly valid TCP, but is much harder for that equipment to read as a
single unit — split across segments, sent out of order, or preceded by a
decoy that expires before it reaches the real server.

**Address-level blocking.** Where the address itself is unreachable, nothing
in this category of tool can help, and DirectPath says so rather than
pretending otherwise.

Everything is per-app and per-destination. Traffic from apps you have not
selected, and traffic to destinations not in an enabled group, is never
redirected at all.

## What it does not do

This is as important as the feature list.

- **It does not decrypt anything.** It reads the hostname from the
  unencrypted opening bytes of a TLS handshake, the same field any router on
  the path can see, and never anything after that. There is no certificate
  authority to install, no interception, no proxy certificate.
- **It does not log your browsing.** Hostnames appear in the log only at
  `debug` level, which is off by default and which you have to switch on
  yourself. Nothing is ever sent off the device.
- **It does not hide from you.** It appears in the KernelSU manager, its
  status is readable from a shell, and it has an off switch in four
  independent places.
- **It does not weaken Android's security.** SELinux is not disabled,
  verified boot is untouched, no vulnerability is used, no system partition
  is modified beyond the module's own mounted files, and no other app's
  behaviour is altered.
- **It does not promise to defeat any particular filter.** See
  [Known limitations](#known-limitations).

---

## Requirements

| | |
|---|---|
| Root | KernelSU (this module uses the KernelSU WebUI and action hooks) |
| Android | 10 through 16 (API 29+) |
| Architecture | arm64 primarily; arm and x86_64 build targets exist |
| Kernel | `iptables` with the `nat` table, `REDIRECT`, and ideally the `owner` match |

The module checks all of this at install time and again at every start. Where
something is missing it disables the feature that needed it and keeps going,
rather than failing wholesale. The control panel has a page showing exactly
what your kernel does and does not support.

**Installing KernelSU** is out of scope here. It is specific to your device
and getting it wrong can leave you unable to boot. Follow the official guide
at <https://kernelsu.org> for your exact model, and make sure you can already
boot normally with KernelSU installed before adding this module.

---

## Installing

1. Open the KernelSU manager.
2. Go to **Modules**, tap the **+** button, choose `directpath-v1.0.0.zip`.
3. Read the installer output. It reports your architecture, your Android API
   level, and which kernel features it found. Anything it warns about there
   will limit what the module can do.
4. Reboot.

The installer will refuse to continue if you are not on KernelSU, if your
Android version is below 10, or if there is no binary for your architecture.

Installing over an existing version keeps your settings and your app
selection, and refreshes the destination lists.

---

## First run

**Nothing is redirected until you turn it on.** After the reboot:

1. Open the KernelSU manager → **Modules** → **DirectPath** → **WebUI**.
2. The state at the top will read **Off**.
3. Pick which apps to cover — the quickest way is one of the preset chips
   under **Apps** (Social, Video, Messaging, Browsers…).
4. Tap the switch at the top right.

Give it a few seconds. The state should change to **Working** and the path
strip underneath will show which layers are being repaired.

On every subsequent boot the module waits for Android to finish starting,
then waits a further 25 seconds by default, before it touches anything. That
delay exists because Android's own network daemon is still rewriting firewall
tables during early boot, and starting into the middle of that is how modules
break networking. You can shorten it under Advanced, but 25 seconds is a
sensible default and there is little to gain.

---

## Using the control panel

The panel opens in **Simple** view. Everything you need day to day is there:

**The state word** is the headline. It is one of:

| State | Meaning |
|---|---|
| **Working** | Selected apps are being repaired. |
| **Partly on** | Running, but one component had to be switched off. Usually DNS. |
| **Starting** | Coming up. |
| **Recovering** | Something failed, rules were removed, a retry is in progress. |
| **Standing by** | A Wi-Fi sign-in page was detected. Sign in first. |
| **Paused** | Rules removed deliberately; the service is still running. |
| **Off** | Nothing redirected. Stock networking. |
| **Switched off** | A safety switch is set. Clear it to start again. |
| **Not running** | It could not start. Check the log. |

**The path strip** below it shows four points — your app, name lookup,
handshake, destination — with the link between each. A solid link is clean, a
dashed amber link is one being actively repaired, and a red link is one that
is failing. This is how you tell *which layer* the interference is at.

**The figures** are counts since the service last started: connections
repaired, connections passed straight through untouched, forged resets
observed, and poisoned DNS answers rejected.

Tap **Advanced** in the top bar for DNS settings, IPv6 and QUIC handling,
manual technique selection, the kernel capability report, the log, settings
backup, and the destination database updater.

---

## Modes

The mode is the one setting most people should ever need to change.

| Mode | What it does |
|---|---|
| **Compatible** | The gentlest technique only, no per-site escalation, QUIC left alone, IPv6 steered towards IPv4. Start here if anything misbehaves. |
| **Automatic** | The default. A moderate technique, escalated per hostname when handshakes keep failing, QUIC blocked so apps fall back to repairable TCP. |
| **Fast** | Lowest overhead. Same technique, no added delays. |
| **Strongest** | The most disruptive techniques, applied to every destination rather than just the enabled groups, with a small inter-segment delay. Uses noticeably more battery and is more likely to upset a poorly written app. |
| **Custom** | Whatever you choose under Advanced → Technique. |

Modes are described by what they do for you, not by their internals. If you
want the internals, they are in [How it works inside](#how-it-works-inside).

---

## Choosing apps

Under **Apps** you can work three ways:

- **Selected** (the default) — only the apps you tick are covered.
- **All** — every installed app is covered, system components excluded.
- **Excluded** — everything is covered *except* the apps you tick.

The preset chips add the installed apps from a category in one tap; they only
add apps that are actually present on the device, so the list stays
meaningful. **Clear** empties the selection.

System apps are hidden by default. You can show them with the checkbox, but
be careful: redirecting Android's own connectivity checks can make the system
believe it has no internet.

Changes take effect immediately. There is no need to reboot or reinstall.

Work profiles and secondary users are handled automatically — the same app
has a different user ID in each profile, and all of them are covered.

---

## Destinations

Under **Destinations** you enable groups of sites: Social, Video, Messaging,
Developer, AI, News, Gaming. Each is a plain list of domain names, and a rule
covers subdomains too, so `youtube.com` also covers `www.youtube.com` and the
`googlevideo.com` servers that carry the actual video.

Anything not in an enabled group is relayed through untouched, which costs a
negligible amount and keeps behaviour predictable.

To add your own destinations, edit:

```
/data/adb/directpath/rules/custom.list
```

One domain per line. That file is never overwritten by an update. Then enable
the **custom** group in the panel.

---

## Diagnostics

**Diagnostics → Run tests** performs real connection attempts and reports
what happened at each stage. Every verdict comes from a measurement:

| Verdict | Meaning |
|---|---|
| `working` | A normal, unmodified handshake succeeded. Nothing to fix. |
| `repaired` | The normal handshake failed; with the repair applied it succeeded. |
| `restricted` | Blocked, and the repair did not help for this destination. |
| `blocked` | Refused at the address level, or the name would not resolve. |
| `poisoned` | The resolver returned an address from a known block-page range. |
| `suspect` | UDP and TCP answers from the same resolver disagree. |
| `unavailable` | No response. This may be the network rather than filtering. |
| `unknown` | The test could not determine an answer. |

That last row matters. A filtered network produces ambiguous results, and a
diagnostic that claims certainty it does not have is worse than useless.

The test takes up to a minute and is rate-limited to once every 20 seconds so
it cannot be used to drain the battery.

---

## DNS

Four options, under Advanced → Name resolution:

- **Automatic** (default) — if you have Android's own **Private DNS** turned
  on, DirectPath leaves DNS completely alone, because Private DNS is already
  encrypted and authenticated and is a better answer than anything this
  module can do. Otherwise it runs its local forwarder.
- **Always use the built-in forwarder** — run it regardless.
- **Use Android Private DNS** — DirectPath sets Android's Private DNS to a
  hostname you supply and then stands down. Your original setting is backed
  up and restored on uninstall.
- **Leave DNS alone** — do nothing to name resolution at all.

The built-in forwarder listens on loopback, forwards queries **over TCP** to
your chosen upstream resolvers, and rejects answers that point at addresses
in `rules/bogus-ip.list` — which includes the `10.10.34.0/24` range long used
as a filtering sinkhole in Iran. It caches answers with a clamped TTL.

**It is not encrypted.** It is harder to tamper with than plain UDP, but a
network operator can still see which names you are asking for. If that
matters to you, use Private DNS.

If every upstream becomes unreachable, the forwarder raises a flag, the
supervisor pulls the DNS redirect out of the firewall, and your system
resolver takes over again. Losing the repair is always preferable to losing
name resolution.

---

## IPv6 and QUIC

**IPv6.** DirectPath never disables IPv6 globally — doing that breaks
networks that need it and is exactly the sort of blunt change this module
avoids. Instead:

- If your kernel can NAT IPv6, the repair is mirrored onto IPv6 and both
  families behave identically.
- If it cannot, but IPv6 is up, then selected apps' IPv6 web traffic would
  silently bypass the repair. So their IPv6 connections on ports 80 and 443
  are refused, which makes the app fall back to IPv4 within a fraction of a
  second. This is narrow by design: only those apps, only those ports.
- **Prefer IPv4** forces the second behaviour; **Prefer IPv6** the first;
  **Do not handle IPv6** leaves it entirely alone.

**QUIC.** QUIC runs over UDP and encrypts its own handshake, so a TCP relay
cannot repair it — and on a filtered network, QUIC connections to blocked
sites usually just hang. Blocking UDP port 443 for the selected apps makes
browsers and apps like YouTube fall back to TLS over TCP, where the repair
works. The block uses `REJECT` rather than `DROP` specifically so that
fallback is instant rather than waiting for a timeout.

---

## The command line

The module installs a `dp` command, usable from any root shell. This exists
so recovery never depends on a working browser.

```
dp status              # current state, as JSON
dp on                  # turn the repair on
dp off                 # turn it off, restore stock networking
dp panic               # emergency off: remove everything and set the kill switch
dp clear-panic         # clear the kill switch
dp health              # exit code 0 healthy, 1 degraded, 2 down
dp apply               # reapply after a settings change
dp restart             # full restart
dp diag                # run diagnostics
dp logs 200            # last 200 log lines
dp set KEY VALUE       # change a setting
dp apps list           # installed apps and whether each is selected
dp apps add com.foo    # cover an app
dp apps remove com.foo # stop covering it
dp apps profile social # apply a preset
dp groups list         # destination groups
dp groups set a,b,c    # enable specific groups
dp update rules        # refresh the destination database
dp help
```

---

## Updating

**The module** updates through KernelSU's normal flashing flow. Your settings
and app selection are preserved; the destination lists are refreshed.

**The destination database** can be updated on its own, under Advanced →
Destination database. This downloads plain lists of domain names over HTTPS
together with a SHA-256 manifest, verifies every file against the manifest,
validates every line as a domain name, and only then swaps the new database
in — keeping the old one until the swap succeeds.

It never downloads or runs code. The worst a compromised update server could
do is make the module repair the wrong websites.

If your device has no SHA-256 tool available, the update is refused rather
than applied unverified.

---

## Emergency recovery

There are six independent ways out, in rough order of convenience. Any one of
them is enough.

**1. The WebUI.** Advanced is not needed — the switch at the top, or the
**Turn everything off** button at the bottom of the panel. Both take effect
immediately, with no reboot.

**2. The action button.** In the KernelSU manager, on the module's entry,
tap **Action**. It toggles the module on or off and prints the result. This
works even if the WebUI will not load.

**3. A root shell.**

```sh
su -c 'dp off'
```

**4. A file, no shell needed beyond creating it.** Any of these disables the
module completely at its next check, and prevents it doing anything at all on
the next boot:

```
/data/local/tmp/directpath_off
/data/adb/directpath/disable
/data/adb/modules/directpath/disable      # KernelSU's own module disable flag
```

The last one is what the KernelSU manager itself writes when you toggle a
module off, so disabling the module in the manager is also a valid recovery
route.

**5. Automatic recovery.** You do not have to do anything:

- If the daemon dies, the supervisor **removes the firewall rules first**,
  then tries to restart it. Three failures in a row and the module disables
  itself permanently until you clear it.
- If the daemon crashes hard, its own fatal signal handler runs the rollback
  before the process dies.
- If the rules go missing (Android's network daemon reloads them on network
  changes), the supervisor reinstalls them; if that fails three times, it
  disables itself.
- If a boot does not reach a healthy state, a counter increments. After three
  such boots the module disables itself before doing anything at all, so a
  boot loop caused by this module resolves itself by the third attempt.

**6. Uninstall from recovery.** If you somehow cannot boot at all, remove
`/data/adb/modules/directpath` from a recovery shell. Deleting that directory
is sufficient; the module does nothing outside it and `/data/adb/directpath`.

After any of these, **normal networking returns without a reboot.** Removing
the rules is a single operation, and it is written to be safe to run twice, at
any moment, from any context.

---

## Troubleshooting

**The state says "Not running".**
Open Advanced → Log. The usual causes are a kernel without a usable `nat`
table, or a port conflict on 9451/9453 with another module. You can change
those ports under Advanced.

**A site still does not work.**
Run diagnostics. If it reports `restricted`, the filtering on that
destination is beyond what this technique can do. Try **Strongest** mode. If
it reports `blocked`, the address itself is unreachable and no amount of
handshake shaping will help.

**Everything is slow.**
Turn off **Strongest** mode; the inter-segment delay it adds costs latency on
every connection. Also check whether QUIC blocking is on — for sites that are
*not* filtered, blocking QUIC makes them slightly slower.

**One app misbehaves.**
Uncheck it under Apps. Applications that pin certificates work fine — nothing
is intercepted — but some apps with unusual networking do not enjoy being
relayed.

**Wi-Fi sign-in pages do not appear.**
The module should detect this and stand down automatically. If it does not,
turn the switch off, sign in, and turn it back on. The detection is a
heuristic across several Android versions and is not perfect.

**No internet at all.**
Use any recovery route above. `dp off` is the fastest. Then send the log:
Advanced → **Copy diagnostics** produces a report with device model, Android
version, kernel capabilities, settings and recent log lines — and no traffic
data, addresses or hostnames.

---

## Uninstalling

Remove the module in the KernelSU manager. On removal the module:

- stops its daemon and supervisor,
- removes every firewall rule and chain it created, on both IPv4 and IPv6,
- restores your Private DNS setting if it was the one that changed it,
- deletes `/data/adb/directpath` and its temporary kill-switch file.

It does not touch any other configuration, any other module, or any of your
own files.

---

## Known limitations

Read this section before deciding whether this module is worth installing.

**There is no guarantee of access to anything.** Filtering varies enormously
between countries, operators, and even between two SIMs on the same network,
and it changes over time. The techniques here work against a common class of
inspection equipment. They do not work against all of it, and a network that
blocks by address, or that blocks encrypted traffic it cannot classify, will
not be affected by any of this. Nothing in this module can promise you access
to any particular site.

**QUIC cannot be repaired**, only blocked so that apps fall back to TCP. If
you allow QUIC, connections that use it bypass the repair entirely.

**Only ports 80 and 443 are redirected.** Other protocols on other ports are
untouched.

**DNS over TCP (port 53) is not redirected**, only UDP. Applications that
speak DNS over TCP directly, or DNS over HTTPS to their own resolver, bypass
the forwarder — as does anything using Private DNS, deliberately.

**Root applications are not covered.** Traffic from UID 0 is excluded, which
is what prevents the relay looping into itself.

**"All apps" mode is coarse on some kernels.** Where the kernel's `owner`
match does not support UID ranges, "all" is implemented by exempting a fixed
list of platform UIDs and covering everything else. That is less precise than
the range-based path.

**IPv6 cannot be repaired on kernels without NAT6.** On those, selected apps'
IPv6 web traffic is refused so they fall back to IPv4. If you disable that
behaviour, IPv6 traffic bypasses the repair silently.

**The network selection for relayed connections is best effort.** The relay
copies the socket mark from the incoming connection so the outgoing one uses
the same network. In unusual multi-network configurations an app bound to a
non-default network may still egress over the default one.

**Captive portal detection is a heuristic.** It reads Android's connectivity
state, which is formatted differently across versions and OEM builds.

**The local DNS forwarder is not encrypted.** It resists tampering; it does
not provide privacy. Use Private DNS if privacy is your goal.

**Tethering is not implemented.** The configuration key exists and is
reserved, but tethered clients are never affected in this release.

**Battery.** Steady-state cost is small — the daemon wakes once a minute, the
supervisor once every 30 seconds — but relaying every connection for selected
apps is not free, and **Strongest** mode is meaningfully more expensive than
the others.

---

## How it works inside

For those who want the detail the mode descriptions deliberately omit.

**Architecture.** A single small native daemon (`dpcore`) runs two
loopback listeners. `iptables` rules in the module's own `DP_*` chains
redirect, for selected UIDs only, outbound TCP on ports 80 and 443 to the
relay, and outbound UDP on port 53 to the forwarder. The relay recovers each
connection's real destination with `SO_ORIGINAL_DST`, reads the hostname from
the plaintext SNI field or HTTP `Host` header, decides whether the
destination is in an enabled group, and either passes the connection straight
through or applies a repair to the first message only. Everything after that
first message is copied verbatim in both directions.

**Techniques.** `split` cuts the first message inside the hostname so no
single segment contains it whole. `split-multi` does so three ways.
`disorder` sends the second part first, with the first part given a TTL low
enough that it expires before the server but after the inspector — the kernel
then retransmits it normally. `fake` sends a decoy handshake for a neutral
hostname at a low TTL and uses `TCP_REPAIR` to rewind the sequence number so
the real server never sees it. `oob` uses an urgent-pointer byte that some
inspectors mishandle. Each is probed for kernel support at startup and
silently downgraded to the next best available.

**Adaptation.** Per hostname, two consecutive handshake failures move that
hostname one rung up the ladder; a success freezes it there. The table
persists across restarts in `state/learn.tsv`, capped and LRU-evicted.

**Boot safety.** The daemon is started and proven to be listening before a
single firewall rule exists. Rules are verified after application and rolled
back on any failure. The boot counter incremented in `post-fs-data.sh` is
cleared only after 60 seconds of confirmed health. Nothing in `post-fs-data`
touches the network.

**Firewall discipline.** Everything lives in `DP_*` chains reached by a
single jump. The module never runs `iptables-restore` against a whole table,
because Android's `netd` owns those tables and rewrites them constantly.
Teardown is unconditional, idempotent, and safe to run from a crash handler.

---

## Building from source

The daemon is C11 with no dependencies beyond bionic.

```sh
export ANDROID_NDK_HOME=/path/to/android-ndk
cd src
./build.sh all        # or ./build.sh for arm64 only
```

That produces `bin/dpcore-arm64`, `bin/dpcore-arm`, `bin/dpcore-x86_64` and a
`SHA256SUMS` manifest, built against API 29, stripped, with stack protector,
FORTIFY_SOURCE, full RELRO and immediate binding. Nothing is downloaded
during the build.

Then zip the project directory with the module files at the root:

```sh
cd ..
zip -r directpath-v1.0.0.zip . -x '.*' -x 'src/.build-*'
```

Shell sources are checked with `sh -n`. The parsers have unit tests in
`src/` — see `TESTING.md`.

## Licence

GPL-3.0-or-later. The daemon source is in `src/`; there are no prebuilt
binaries in this repository that are not reproducible from it.
