/* test_rules.c - destination matching.
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * The rule engine decides whether a connection is repaired or passed
 * through untouched, so both directions of error matter: missing a listed
 * destination makes the module useless, and matching an unlisted one makes
 * it intrusive. The bare-TLD case is the dangerous one, because a naive
 * suffix walk ends up matching every .com address in existence.
 */

#include "dpcore.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

dp_config    g_cfg;
dp_stats     g_stats;
volatile int g_stop;

static int failures;

static void check(int cond, const char *what)
{
    printf("%-52s %s\n", what, cond ? "ok" : "FAILED");
    if (!cond) failures++;
}

static void write_list(const char *path, const char *body)
{
    FILE *f = fopen(path, "w");
    if (!f) { perror(path); exit(2); }
    fputs(body, f);
    fclose(f);
}

int main(void)
{
    char group[32];
    const char *dir = "/tmp/dp_rule_test";

    dp_log_open("/dev/null", LL_ERROR, 20000);

    if (system("mkdir -p /tmp/dp_rule_test") != 0) return 2;
    write_list("/tmp/dp_rule_test/video.list",
               "youtube.com\n*.googlevideo.com\n# a comment\n\nreddit.com\n");
    write_list("/tmp/dp_rule_test/social.list",
               "instagram.com\n");

    /* ---- all groups enabled ---- */
    dp_rules_load(dir, "all");

    group[0] = '\0';
    check(dp_rules_match("www.youtube.com", group, sizeof(group)) == 1,
          "subdomain matches its parent rule");
    check(strcmp(group, "video") == 0, "match reports the right group");

    check(dp_rules_match("youtube.com", NULL, 0) == 1,
          "exact hostname matches");
    check(dp_rules_match("r1---sn-4g5e6nez.googlevideo.com", NULL, 0) == 1,
          "wildcard rule matches a deep subdomain");
    check(dp_rules_match("instagram.com", NULL, 0) == 1,
          "second group file is loaded");

    check(dp_rules_match("com", NULL, 0) == 0,
          "a bare TLD never matches");
    check(dp_rules_match("example.com", NULL, 0) == 0,
          "an unrelated domain does not match");
    check(dp_rules_match("notyoutube.com", NULL, 0) == 0,
          "a domain that merely ends with the rule text does not match");
    check(dp_rules_match("", NULL, 0) == 0,
          "an empty hostname does not match");

    /* ---- group filtering ---- */
    dp_rules_load(dir, "social");
    check(dp_rules_match("www.youtube.com", NULL, 0) == 0,
          "a disabled group's rules are not loaded");
    check(dp_rules_match("instagram.com", NULL, 0) == 1,
          "an enabled group's rules still match");

    dp_rules_free();

    printf("\n%s\n", failures ? "FAILURES PRESENT" : "all checks passed");
    return failures ? 1 : 0;
}
