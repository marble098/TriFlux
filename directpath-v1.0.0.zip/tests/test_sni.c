/* test_sni.c - the SNI and Host parsers.
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * A bounds error in this parser would be both a crash and a security bug,
 * since it runs on the first bytes of every relayed connection. So the test
 * does two things: check that a well-formed message parses to exactly the
 * right hostname at exactly the right byte offset, and then feed the parser
 * every truncation of that message to confirm it neither crashes nor
 * reports a match it cannot justify.
 */

#include "dpcore.h"

#include <stdio.h>
#include <string.h>

dp_config    g_cfg;
dp_stats     g_stats;
volatile int g_stop;

static int failures;

static void check(int cond, const char *what)
{
    printf("%-46s %s\n", what, cond ? "ok" : "FAILED");
    if (!cond) failures++;
}

/* Assemble a structurally valid TLS 1.2 ClientHello carrying one SNI. */
static size_t build_hello(unsigned char *h, const char *host)
{
    size_t p = 0, i, hl = strlen(host);
    size_t sni_ext = 2 + 1 + 2 + hl;
    size_t ext_len = 4 + sni_ext;
    size_t body    = 2 + 32 + 1 + 2 + 2 + 2 + 2 + ext_len;

    h[p++] = 0x16; h[p++] = 0x03; h[p++] = 0x01;
    h[p++] = (unsigned char)(((4 + body) >> 8) & 0xff);
    h[p++] = (unsigned char)((4 + body) & 0xff);

    h[p++] = 0x01;
    h[p++] = (unsigned char)((body >> 16) & 0xff);
    h[p++] = (unsigned char)((body >> 8) & 0xff);
    h[p++] = (unsigned char)(body & 0xff);

    h[p++] = 0x03; h[p++] = 0x03;
    for (i = 0; i < 32; i++) h[p++] = (unsigned char)i;

    h[p++] = 0x00;                                  /* no session id      */
    h[p++] = 0x00; h[p++] = 0x02;                   /* cipher suites len  */
    h[p++] = 0x13; h[p++] = 0x01;
    h[p++] = 0x01; h[p++] = 0x00;                   /* compression        */

    h[p++] = (unsigned char)((ext_len >> 8) & 0xff);
    h[p++] = (unsigned char)(ext_len & 0xff);
    h[p++] = 0x00; h[p++] = 0x00;                   /* extension: SNI     */
    h[p++] = (unsigned char)((sni_ext >> 8) & 0xff);
    h[p++] = (unsigned char)(sni_ext & 0xff);
    h[p++] = (unsigned char)(((1 + 2 + hl) >> 8) & 0xff);
    h[p++] = (unsigned char)((1 + 2 + hl) & 0xff);
    h[p++] = 0x00;                                  /* name type: host    */
    h[p++] = (unsigned char)((hl >> 8) & 0xff);
    h[p++] = (unsigned char)(hl & 0xff);
    memcpy(h + p, host, hl);
    p += hl;
    return p;
}

int main(void)
{
    unsigned char h[1024];
    char   out[256];
    size_t off, len, k;
    int    rc;

    dp_log_open("/dev/null", LL_ERROR, 20000);

    /* ---- a well formed handshake ---- */
    len = build_hello(h, "www.youtube.com");
    off = 0;
    out[0] = '\0';
    rc = dp_tls_peek_sni(h, len, out, sizeof(out), &off);
    check(rc == 1, "ClientHello: SNI is found");
    check(strcmp(out, "www.youtube.com") == 0, "ClientHello: hostname is exact");
    check(off == len - strlen("www.youtube.com"),
          "ClientHello: offset points at the hostname");

    /* ---- a plain HTTP request ---- */
    {
        const char *req =
            "GET / HTTP/1.1\r\nUser-Agent: x\r\nHost: reddit.com\r\nAccept: */*\r\n\r\n";
        off = 0;
        out[0] = '\0';
        rc = dp_http_peek_host((const uint8_t *)req, strlen(req), out, sizeof(out), &off);
        check(rc == 1, "HTTP: Host header is found");
        check(strcmp(out, "reddit.com") == 0, "HTTP: hostname is exact");
        check(memcmp(req + off, "reddit.com", 10) == 0, "HTTP: offset points at the host");
    }

    /* ---- every truncation ---- */
    for (k = 1; k < len; k++) {
        char   o2[256];
        size_t f = 0;
        o2[0] = '\0';
        rc = dp_tls_peek_sni(h, k, o2, sizeof(o2), &f);
        if (rc == 1 && f + strlen(o2) > k) {
            printf("truncation at %zu reported an out-of-range match\n", k);
            failures++;
            break;
        }
    }
    check(1, "truncation: no crash and no out-of-range match");

    /* ---- garbage ---- */
    {
        unsigned char junk[64];
        size_t f = 0;
        memset(junk, 0xAA, sizeof(junk));
        rc = dp_tls_peek_sni(junk, sizeof(junk), out, sizeof(out), &f);
        check(rc != 1, "garbage: no false match");
    }

    /* ---- an IP literal must not be treated as a hostname ---- */
    len = build_hello(h, "93.184.216.34");
    rc = dp_tls_peek_sni(h, len, out, sizeof(out), &off);
    check(rc != 1, "IP literal in SNI is rejected");

    printf("\n%s\n", failures ? "FAILURES PRESENT" : "all checks passed");
    return failures ? 1 : 0;
}
