#!/system/bin/sh
# boot-completed.sh - a second chance at starting.
#
# Not every KernelSU build runs this hook, and not every device reaches
# service.sh in a usable state, so both paths call the same guarded starter.
# boot.sh holds a lock, so whichever arrives second simply exits.

MODDIR=${0%/*}

[ -f "$MODDIR/disable" ] && exit 0
[ -f /data/adb/directpath/disable ] && exit 0
[ -f /data/adb/directpath/state/auto_disabled ] && exit 0
[ -f /data/local/tmp/directpath_off ] && exit 0

[ -x "$MODDIR/scripts/boot.sh" ] || exit 0
"$MODDIR/scripts/boot.sh" boot-completed >/dev/null 2>&1 &

exit 0
