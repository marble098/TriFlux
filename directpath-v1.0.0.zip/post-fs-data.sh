#!/system/bin/sh
# post-fs-data.sh - runs very early, before Android's networking exists.
#
# The single most dangerous place in a module is right here, so this script
# does the least possible: it counts boot attempts, trips the automatic kill
# switch if the count says the previous boots did not finish, and clears
# stale runtime files. It touches no interface, no table and no daemon.
#
# Anything that could hang here would hang the boot, so there are no loops,
# no waits and no network calls.

MODDIR=${0%/*}
DATA=/data/adb/directpath
STATE=$DATA/state
MAX_BOOT_ATTEMPTS=3

mkdir -p "$DATA/config" "$DATA/rules" "$STATE" "$DATA/run" \
         "$DATA/log" "$DATA/backup" "$DATA/bin" 2>/dev/null
chmod 700 "$DATA" "$STATE" "$DATA/run" 2>/dev/null

# Stale runtime state from a boot that never completed.
rm -rf "$DATA/run/lock" 2>/dev/null
rm -f  "$DATA/run/dpcore.pid" "$DATA/run/watchdog.pid" "$DATA/run/status" 2>/dev/null

# ---- boot attempt counter -------------------------------------------------
# Incremented here and cleared only once a boot has been up and healthy for
# a while (see boot.sh). A device stuck in a loop therefore climbs to the
# limit and disables the module by itself, without the user needing recovery.
COUNT=0
[ -f "$STATE/boot_count" ] && COUNT=$(cat "$STATE/boot_count" 2>/dev/null)
case "$COUNT" in ''|*[!0-9]*) COUNT=0 ;; esac
COUNT=$((COUNT + 1))
printf '%s\n' "$COUNT" > "$STATE/boot_count"

if [ "$COUNT" -ge "$MAX_BOOT_ATTEMPTS" ]; then
    printf 'reached %s boot attempts without a healthy start\n' "$COUNT" \
        > "$STATE/auto_disabled"
    printf '%s disabled after %s boot attempts\n' \
        "$(date '+%m-%d %H:%M:%S')" "$COUNT" >> "$DATA/log/engine.log"
fi

exit 0
