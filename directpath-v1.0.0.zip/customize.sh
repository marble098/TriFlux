#!/system/bin/sh
# customize.sh - runs once, at install time, inside the KernelSU installer.
#
# Everything here is checked before anything is written. If the device
# cannot run the module we abort during installation, which is the one
# moment where failing loudly costs the user nothing.

SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=true
LATESTARTSERVICE=true

DATA=/data/adb/directpath

ui_print ""
ui_print "  DirectPath"
ui_print "  connection repair for restricted networks"
ui_print ""

# ---------------------------------------------------------------- platform

if [ "$KSU" != "true" ]; then
    ui_print "! This module targets KernelSU."
    ui_print "! It uses the KernelSU WebUI and module action hooks."
    ui_print "! Install it from the KernelSU manager instead."
    abort "  aborting"
fi
ui_print "- KernelSU ${KSU_VER:-unknown} (kernel ${KSU_KERNEL_VER_CODE:-?})"

if [ -n "$API" ] && [ "$API" -lt 29 ]; then
    ui_print "! Android 10 (API 29) or newer is required."
    ui_print "! This device reports API $API."
    abort "  aborting"
fi
ui_print "- Android API ${API:-unknown}"

case "$ARCH" in
    arm64) BINSRC=dpcore-arm64 ;;
    arm)   BINSRC=dpcore-arm ;;
    x64)   BINSRC=dpcore-x86_64 ;;
    *)
        ui_print "! Unsupported architecture: $ARCH"
        ui_print "! Prebuilt binaries exist for arm64, arm and x86_64."
        ui_print "! Build one yourself with src/build.sh and reinstall."
        abort "  aborting"
        ;;
esac
ui_print "- Architecture $ARCH"

if [ ! -f "$MODPATH/bin/$BINSRC" ]; then
    ui_print "! $BINSRC is missing from this package."
    ui_print "! Run src/build.sh to produce it, then repackage."
    abort "  aborting"
fi

# ------------------------------------------------------- verify the binary

if [ -f "$MODPATH/bin/SHA256SUMS" ] && command -v sha256sum >/dev/null 2>&1; then
    WANT=$(grep -m1 " $BINSRC\$" "$MODPATH/bin/SHA256SUMS" | cut -d' ' -f1)
    HAVE=$(sha256sum "$MODPATH/bin/$BINSRC" | cut -d' ' -f1)
    if [ -n "$WANT" ] && [ "$WANT" != "$HAVE" ]; then
        ui_print "! The bundled binary does not match its checksum."
        abort "  aborting"
    fi
    ui_print "- Binary checksum verified"
else
    ui_print "- Binary checksum not verified (no manifest or no sha256sum)"
fi

# ----------------------------------------------------------- the data tree

ui_print "- Preparing $DATA"
mkdir -p "$DATA/config" "$DATA/rules" "$DATA/state" "$DATA/run" \
         "$DATA/log" "$DATA/backup" "$DATA/bin"

install -m 0700 "$MODPATH/bin/$BINSRC" "$DATA/bin/dpcore" 2>/dev/null ||
    { cp -f "$MODPATH/bin/$BINSRC" "$DATA/bin/dpcore"; chmod 700 "$DATA/bin/dpcore"; }

# Drop the other architectures so the installed module stays small.
rm -f "$MODPATH/bin/dpcore-"* "$MODPATH/bin/SHA256SUMS"

# Rule lists are data, not config: always refreshed from the package so an
# update ships new destinations, while user settings below are preserved.
cp -f "$MODPATH/config/rules/"*.list "$DATA/rules/" 2>/dev/null
chmod 644 "$DATA/rules/"*.list 2>/dev/null

if [ -f "$DATA/config/directpath.conf" ]; then
    ui_print "- Existing settings kept"
    cp -f "$DATA/config/directpath.conf" "$DATA/backup/directpath.conf.preupdate"
else
    cp -f "$MODPATH/config/default.conf" "$DATA/config/directpath.conf"
    ui_print "- Default settings written"
fi
[ -f "$DATA/config/apps.list" ] || cp -f "$MODPATH/config/apps.default" "$DATA/config/apps.list"

# A fresh install must never inherit a previous kill switch or crash count.
rm -f "$DATA/disable" "$DATA/state/auto_disabled" "$DATA/state/crash_count" \
      "$DATA/state/boot_count" "$DATA/state/caps" /data/local/tmp/directpath_off
rm -rf "$DATA/run/lock"

# ------------------------------------------------------------- permissions

set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm_recursive "$MODPATH/scripts" 0 0 0755 0755
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
set_perm "$MODPATH/boot-completed.sh" 0 0 0755
set_perm "$MODPATH/action.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755
set_perm "$MODPATH/system/bin/dp" 0 0 0755

chmod 700 "$DATA" "$DATA/config" "$DATA/state" "$DATA/run" "$DATA/backup"
chmod 755 "$DATA/rules" "$DATA/bin" "$DATA/log"
chown 0:0 "$DATA" 2>/dev/null

# ---------------------------------------------------------------- capability

ui_print "- Probing kernel support"
CAPS=$("$DATA/bin/dpcore" --probe 2>/dev/null)
case "$CAPS" in
    *cap_ttl=1*) ui_print "  TTL control: yes" ;;
    *)           ui_print "  TTL control: no (disorder and fake modes unavailable)" ;;
esac
case "$CAPS" in
    *cap_tcp_repair=1*) ui_print "  TCP_REPAIR: yes" ;;
    *)                  ui_print "  TCP_REPAIR: no (fake mode will fall back)" ;;
esac

if command -v iptables >/dev/null 2>&1; then
    if iptables -t nat -L -n >/dev/null 2>&1; then
        ui_print "  IPv4 nat table: yes"
    else
        ui_print "! IPv4 nat table is not usable on this kernel."
        ui_print "! The module will install but cannot redirect traffic."
    fi
else
    ui_print "! iptables was not found. The module will install but"
    ui_print "! will not be able to apply rules."
fi

ui_print ""
ui_print "- Installed."
ui_print "  Open the KernelSU manager, tap this module, then WebUI."
ui_print "  Nothing is redirected until you turn the switch on."
ui_print ""
ui_print "  Emergency off, from any root shell:"
ui_print "    dp off"
ui_print "  or create the file /data/local/tmp/directpath_off"
ui_print ""
