#!/system/bin/sh
# action.sh - the module's Action button in the KernelSU manager.
#
# One tap, no menus: it toggles between running and fully off. This is the
# recovery path that needs no WebUI, no browser and no working network, so
# it is written to be readable and to never depend on the daemon.

MODDIR=${0%/*}
DATA=/data/adb/directpath
CTL="$MODDIR/scripts/control.sh"
ENG="$MODDIR/scripts/engine.sh"

STATUS=$(cat "$DATA/run/status" 2>/dev/null || printf unknown)
ENABLED=$(grep -m1 '^enabled=' "$DATA/config/directpath.conf" 2>/dev/null | cut -d= -f2-)

echo ""
echo "  DirectPath"
echo "  current state: $STATUS"
echo ""

if [ -f "$DATA/disable" ] || [ -f "$DATA/state/auto_disabled" ] || \
   [ -f /data/local/tmp/directpath_off ] || [ "$ENABLED" != "1" ]; then
    echo "  Turning it on..."
    rm -f "$DATA/disable" /data/local/tmp/directpath_off
    rm -f "$DATA/state/auto_disabled" "$DATA/state/crash_count"
    sh "$CTL" on >/dev/null 2>&1
    sleep 2
    echo "  now: $(cat "$DATA/run/status" 2>/dev/null || printf unknown)"
    echo ""
    echo "  If a website still fails, open the WebUI and run Diagnostics."
else
    echo "  Turning it off and restoring stock networking..."
    sh "$ENG" stop >/dev/null 2>&1
    printf 'disabled from the action button\n' > "$DATA/disable"
    sleep 1
    echo "  now: disabled"
    echo ""
    echo "  All redirection has been removed. Tap again to turn it back on."
fi
echo ""
exit 0
