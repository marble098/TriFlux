/* dpcore.h - shared declarations for the DirectPath userspace daemon.
 *
 * Copyright (c) 2026 DirectPath contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * dpcore is a local, transparent TCP relay plus a validating DNS forwarder.
 * It never decrypts TLS. It reads only the plaintext SNI field of a
 * ClientHello (and the Host header of plaintext HTTP) in order to decide
 * whether a destination is one the user asked us to repair. Payload bytes
 * are relayed verbatim and are never logged or stored.
 */

#ifndef DPCORE_H
#define DPCORE_H

#include <stdint.h>
#include <stddef.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define DP_VERSION "1.0.0"

/* ---- limits -------------------------------------------------------- */
#define DP_MAX_CONNS        384
#define DP_RELAY_BUF        8192
#define DP_HEAD_BUF         8192    /* first client chunk (a TLS CH fits) */
#define DP_MAX_HOST         256
#define DP_MAX_UPSTREAMS    4
#define DP_DNS_INFLIGHT     64
#define DP_DNS_CACHE        1024
#define DP_DNS_MSG          4096
#define DP_LEARN_MAX        512
#define DP_HANDSHAKE_TMO    15      /* seconds to see the first client chunk */
#define DP_IDLE_TMO         300     /* seconds of total silence            */
#define DP_CONNECT_TMO      12

/* ---- socket option numbers (declared here so we do not depend on the
 * exact netfilter uapi headers being present in every NDK sysroot) ---- */
#ifndef DP_SO_ORIGINAL_DST
#define DP_SO_ORIGINAL_DST  80
#endif
#ifndef DP_TCP_REPAIR
#define DP_TCP_REPAIR       19
#define DP_TCP_REPAIR_QUEUE 20
#define DP_TCP_QUEUE_SEQ    21
#define DP_TCP_SEND_QUEUE   2
#endif

/* ---- desync strategies --------------------------------------------- */
typedef enum {
    DS_NONE = 0,   /* pure relay, no modification                        */
    DS_SPLIT,      /* two writes, boundary inside/near the SNI           */
    DS_DISORDER,   /* first segment sent with a TTL that expires en route*/
    DS_FAKE,       /* decoy record sent with low TTL, seq rewound        */
    DS_OOB,        /* one byte of urgent data injected at the boundary   */
    DS_SPLIT_MULTI /* three-way split, boundary offsets 1 and SNI        */
} dp_strategy;

dp_strategy dp_strategy_from_name(const char *s);
const char *dp_strategy_name(dp_strategy s);

/* ---- logging ------------------------------------------------------- */
typedef enum { LL_ERROR = 0, LL_WARN, LL_INFO, LL_DEBUG } dp_level;

void dp_log_open(const char *path, dp_level lvl, long max_bytes);
void dp_log_close(void);
void dp_logf(dp_level lvl, const char *fmt, ...)
    __attribute__((format(printf, 2, 3)));

#define LOGE(...) dp_logf(LL_ERROR, __VA_ARGS__)
#define LOGW(...) dp_logf(LL_WARN,  __VA_ARGS__)
#define LOGI(...) dp_logf(LL_INFO,  __VA_ARGS__)
#define LOGD(...) dp_logf(LL_DEBUG, __VA_ARGS__)

/* ---- configuration -------------------------------------------------- */
typedef struct {
    char     rundir[192];        /* /data/adb/directpath                  */
    char     ruledir[192];       /* directory holding *.list group files  */
    char     logfile[224];
    dp_level loglevel;
    long     logmax;

    uint16_t proxy_port;
    uint16_t dns_port;
    int      dns_enabled;
    int      proxy_enabled;

    dp_strategy strategy;        /* default strategy for matched hosts    */
    int      split_pos;          /* byte offset used when SNI is absent   */
    int      fake_ttl;           /* TTL for DS_FAKE / DS_DISORDER decoys   */
    int      split_delay_us;     /* pause between the two writes          */
    int      scope_all;          /* 1 = repair every host, not just rules */
    int      adaptive;           /* 1 = escalate strategy on repeated RST */

    char     upstream[DP_MAX_UPSTREAMS][64];
    int      upstream_n;
    int      dns_tcp;            /* 1 = talk to upstreams over TCP        */
    int      dns_desync;         /* 1 = apply split to upstream DNS/TCP   */
    int      dns_cache_ttl_min;
    int      dns_cache_ttl_max;
} dp_config;

extern dp_config g_cfg;
extern volatile int g_stop;

int  dp_config_load(const char *path);

/* ---- statistics (exported to the shell layer as key=value) ---------- */
typedef struct {
    unsigned long conn_total;
    unsigned long conn_active;
    unsigned long conn_repaired;
    unsigned long conn_passthrough;
    unsigned long conn_failed;
    unsigned long reset_seen;
    unsigned long dns_queries;
    unsigned long dns_cached;
    unsigned long dns_bogus;
    unsigned long dns_failed;
    long          started_at;
} dp_stats;

extern dp_stats g_stats;
void dp_stats_dump(const char *path);

/* ---- util.c --------------------------------------------------------- */
int   dp_set_nonblock(int fd);
int   dp_set_cloexec(int fd);
long  dp_now(void);
int   dp_write_atomic(const char *path, const char *data, size_t len);
char *dp_trim(char *s);
int   dp_parse_hostport(const char *spec, char *host, size_t hlen, uint16_t *port,
                        uint16_t defport);
int   dp_sa_from_str(const char *host, uint16_t port, struct sockaddr_storage *ss,
                     socklen_t *len);
int   dp_addr_is_private(const struct sockaddr_storage *ss);
const char *dp_sa_str(const struct sockaddr_storage *ss, char *buf, size_t len);
int   dp_orig_dst(int fd, struct sockaddr_storage *ss, socklen_t *len);
uint32_t dp_hash(const char *s);

/* ---- sni.c ---------------------------------------------------------- */
/* Returns 1 and fills host/offset when a name was found.
 * offset receives the byte position of the first character of the name
 * inside buf, which is what the split strategies aim at. */
int dp_tls_peek_sni(const uint8_t *buf, size_t len, char *host, size_t hlen,
                    size_t *offset);
int dp_http_peek_host(const uint8_t *buf, size_t len, char *host, size_t hlen,
                      size_t *offset);

/* ---- rules.c -------------------------------------------------------- */
int  dp_rules_load(const char *dir, const char *enabled_groups);
int  dp_rules_match(const char *host, char *group, size_t glen);
void dp_rules_free(void);

int  dp_learn_load(const char *path);
int  dp_learn_save(const char *path);
/* Returns the strategy to use for host, honouring learned escalation. */
dp_strategy dp_learn_strategy(const char *host, dp_strategy base);
void dp_learn_report(const char *host, int success);

/* ---- desync.c ------------------------------------------------------- */
int  dp_desync_probe(void);   /* bitmask of usable techniques           */
#define DP_CAP_TTL     0x1
#define DP_CAP_REPAIR  0x2
#define DP_CAP_OOB     0x4
/* Writes the first client chunk to fd using strategy. Returns 0 on
 * success, -1 on hard error. Falls back to a plain write when the
 * requested technique is unavailable on this kernel. */
int  dp_desync_send(int fd, int family, const uint8_t *buf, size_t len,
                    size_t split_at, dp_strategy st);
size_t dp_build_client_hello(uint8_t *out, size_t cap, const char *host);

/* ---- check.c --------------------------------------------------------- */
/* One-shot reachability probe. Writes a key=value report to stdout.
 * sni may be NULL for a plain TCP connect test. */
int  dp_check_tcp(const char *ip, uint16_t port, const char *sni,
                  dp_strategy st, int timeout_ms);

/* ---- proxy.c -------------------------------------------------------- */
int  dp_proxy_start(void);
void dp_proxy_run(void);
void dp_proxy_stop(void);

/* ---- dns.c ---------------------------------------------------------- */
int  dp_dns_start(void);
void dp_dns_run(void);
void dp_dns_stop(void);
int  dp_dns_load_bogus(const char *path);
/* One-shot resolver probe: query name at server, report the first address
 * and whether it lands in a known sinkhole range. */
int  dp_dns_probe(const char *name, const char *server, int use_tcp,
                  int timeout_ms);

#endif /* DPCORE_H */
