/* check.c - the diagnostic probe.
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * Diagnostics that cannot tell "there is no route" apart from "the
 * handshake was reset" are not diagnostics, they are decoration. This probe
 * makes the distinction by walking the connection one stage at a time and
 * reporting where it stopped:
 *
 *   refused    the SYN was answered with a RST         -> blocked at the IP
 *   timeout    the SYN went nowhere                    -> dropped or no route
 *   reset      TCP came up, then died mid handshake    -> inspection on SNI
 *   silent     TCP came up, the server never answered  -> throttled or dropped
 *   ok         a ServerHello came back                 -> the path works
 *
 * Passing a strategy runs the same repair the relay would, so the UI can
 * answer "would turning this on actually help?" with a measurement rather
 * than an opinion.
 */

#define _GNU_SOURCE
#include "dpcore.h"

#include <errno.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <netdb.h>
#include <poll.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>

static long now_ms(void)
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (long)tv.tv_sec * 1000L + tv.tv_usec / 1000L;
}

static void report(const char *result, const char *stage, long rtt, const char *note)
{
    printf("result=%s\nstage=%s\nrtt_ms=%ld\nnote=%s\n",
           result, stage, rtt < 0 ? -1 : rtt, note ? note : "");
}

int dp_check_tcp(const char *ip, uint16_t port, const char *sni,
                 dp_strategy st, int timeout_ms)
{
    struct sockaddr_storage ss;
    socklen_t sl;
    struct pollfd pfd;
    uint8_t  hello[512], resp[64];
    size_t   hlen;
    long     t0, connected_at;
    int      fd, err = 0, on = 1;
    socklen_t el = sizeof(err);
    ssize_t  n;

    /* A literal address tests the path only. A hostname additionally
     * exercises the system resolver, which is usually the first thing to
     * break on a filtered network, so both forms are accepted. */
    if (dp_sa_from_str(ip, port, &ss, &sl) != 0) {
        struct addrinfo hints, *res = NULL;
        char portstr[8];

        memset(&hints, 0, sizeof(hints));
        hints.ai_family   = AF_UNSPEC;
        hints.ai_socktype = SOCK_STREAM;
        snprintf(portstr, sizeof(portstr), "%u", port);

        if (getaddrinfo(ip, portstr, &hints, &res) != 0 || !res) {
            report("dnsfail", "resolve", -1, "the name could not be resolved");
            return 1;
        }
        memcpy(&ss, res->ai_addr, res->ai_addrlen);
        sl = res->ai_addrlen;
        freeaddrinfo(res);

        {   /* Show what we got: a sinkhole address is visible right here. */
            char buf[80];
            dp_sa_str(&ss, buf, sizeof(buf));
            printf("resolved=%s\n", buf);
        }
        if (!sni) sni = ip;   /* checking a name implies checking its SNI */
    }

    fd = socket(ss.ss_family, SOCK_STREAM | SOCK_CLOEXEC | SOCK_NONBLOCK,
                IPPROTO_TCP);
    if (fd < 0) {
        report("error", "socket", -1, strerror(errno));
        return 2;
    }
    setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &on, sizeof(on));

    t0 = now_ms();
    if (connect(fd, (struct sockaddr *)&ss, sl) != 0 && errno != EINPROGRESS) {
        report(errno == ECONNREFUSED ? "refused" : "error", "connect", -1,
               strerror(errno));
        close(fd);
        return 1;
    }

    pfd.fd = fd; pfd.events = POLLOUT; pfd.revents = 0;
    n = poll(&pfd, 1, timeout_ms);
    if (n == 0) {
        report("timeout", "connect", -1, "no response to the connection attempt");
        close(fd);
        return 1;
    }
    if (getsockopt(fd, SOL_SOCKET, SO_ERROR, &err, &el) != 0 || err != 0) {
        report(err == ECONNREFUSED ? "refused" : "timeout", "connect", -1,
               strerror(err ? err : errno));
        close(fd);
        return 1;
    }
    connected_at = now_ms() - t0;

    /* A plain reachability question stops here. */
    if (!sni || !*sni) {
        report("ok", "tcp", connected_at, "port is open");
        close(fd);
        return 0;
    }

    hlen = dp_build_client_hello(hello, sizeof(hello), sni);
    if (hlen == 0) {
        report("error", "hello", connected_at, "hostname too long");
        close(fd);
        return 2;
    }

    {   /* Aim the boundary at the middle of the name, exactly as the relay
         * does, so a repaired probe and repaired traffic behave alike. */
        size_t nlen = strlen(sni);
        size_t off  = hlen - nlen + (nlen > 3 ? nlen / 2 : 1);
        if (dp_desync_send(fd, ss.ss_family, hello, hlen, off, st) != 0) {
            report("reset", "hello", connected_at, "connection died while sending");
            close(fd);
            return 1;
        }
    }

    pfd.events = POLLIN; pfd.revents = 0;
    n = poll(&pfd, 1, timeout_ms);
    if (n == 0) {
        report("silent", "handshake", connected_at,
               "connected but the server never replied");
        close(fd);
        return 1;
    }

    n = recv(fd, resp, sizeof(resp), 0);
    if (n < 0) {
        report(errno == ECONNRESET ? "reset" : "error", "handshake", connected_at,
               strerror(errno));
        close(fd);
        return 1;
    }
    if (n == 0) {
        report("reset", "handshake", connected_at, "closed without answering");
        close(fd);
        return 1;
    }
    if (resp[0] == 0x16) {
        report("ok", "tls", now_ms() - t0, "server hello received");
        close(fd);
        return 0;
    }
    if (resp[0] == 0x15) {
        /* A TLS alert is a real server declining, not interference. */
        report("ok", "tls", now_ms() - t0, "server answered with an alert");
        close(fd);
        return 0;
    }
    report("unexpected", "handshake", now_ms() - t0, "reply was not TLS");
    close(fd);
    return 1;
}
