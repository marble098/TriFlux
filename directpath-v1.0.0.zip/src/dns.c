/* dns.c - a small validating DNS forwarder.
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * The dominant DNS attack on a restricted network is a forged UDP answer
 * that arrives before the real one. Two properties defeat it cheaply:
 *
 *   1. Ask upstream over TCP. A spoofer has to win a three way handshake,
 *      not just guess a 16 bit ID, and injected data has to land inside a
 *      valid sequence window.
 *   2. Refuse answers that point at known sinkhole addresses. When a
 *      resolver hands back the block page address for a name that plainly
 *      is not hosted there, that answer is evidence, not a result.
 *
 * When an upstream misbehaves we move to the next one. When every upstream
 * fails repeatedly we raise a flag the supervisor watches, and it removes
 * the DNS redirect entirely so the phone falls back to the network's own
 * resolver. Losing the repair is always preferable to losing name
 * resolution.
 *
 * This forwarder does not encrypt queries and does not pretend to. On a
 * device where Android's own Private DNS is available, the shell layer
 * prefers that and leaves this subsystem switched off; see engine.sh.
 */

#define _GNU_SOURCE
#include "dpcore.h"

#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/epoll.h>
#include <sys/socket.h>
#include <unistd.h>

/* ---- bogus address table -------------------------------------------- */

typedef struct {
    int      family;
    uint8_t  addr[16];
    int      bits;
} cidr;

static cidr g_bogus[64];
static int  g_bogus_n;

static int cidr_parse(const char *s, cidr *out)
{
    char  buf[80], *slash;
    int   bits;

    snprintf(buf, sizeof(buf), "%s", s);
    slash = strchr(buf, '/');
    if (slash) { *slash = '\0'; bits = atoi(slash + 1); }
    else       { bits = -1; }

    memset(out, 0, sizeof(*out));
    if (strchr(buf, ':')) {
        if (inet_pton(AF_INET6, buf, out->addr) != 1) return -1;
        out->family = AF_INET6;
        out->bits   = (bits < 0 || bits > 128) ? 128 : bits;
    } else {
        if (inet_pton(AF_INET, buf, out->addr) != 1) return -1;
        out->family = AF_INET;
        out->bits   = (bits < 0 || bits > 32) ? 32 : bits;
    }
    return 0;
}

int dp_dns_load_bogus(const char *path)
{
    FILE *f = fopen(path, "r");
    char  line[128];

    g_bogus_n = 0;
    if (!f) return 0;
    while (fgets(line, sizeof(line), f) && g_bogus_n < 64) {
        char *s = dp_trim(line);
        if (!*s || *s == '#') continue;
        if (cidr_parse(s, &g_bogus[g_bogus_n]) == 0) g_bogus_n++;
    }
    fclose(f);
    LOGI("loaded %d sinkhole ranges", g_bogus_n);
    return g_bogus_n;
}

static int addr_is_bogus(int family, const uint8_t *a)
{
    int i;
    for (i = 0; i < g_bogus_n; i++) {
        const cidr *c = &g_bogus[i];
        int full, rem;
        if (c->family != family) continue;
        full = c->bits / 8;
        rem  = c->bits % 8;
        if (full && memcmp(c->addr, a, (size_t)full) != 0) continue;
        if (rem) {
            uint8_t mask = (uint8_t)(0xFF << (8 - rem));
            if ((c->addr[full] & mask) != (a[full] & mask)) continue;
        }
        return 1;
    }
    return 0;
}

/* ---- wire format helpers -------------------------------------------- */

static int name_skip(const uint8_t *m, size_t len, size_t pos, size_t *out)
{
    int hops = 0;
    while (pos < len) {
        uint8_t l = m[pos];
        if (l == 0) { *out = pos + 1; return 0; }
        if ((l & 0xC0) == 0xC0) {
            if (pos + 1 >= len) return -1;
            *out = pos + 2;
            return 0;
        }
        if (l > 63 || ++hops > 128) return -1;
        pos += 1 + l;
    }
    return -1;
}

/* Reads a possibly compressed name into dotted lowercase form. */
static int name_read(const uint8_t *m, size_t len, size_t pos, char *out,
                     size_t olen)
{
    size_t o = 0;
    int    hops = 0;

    out[0] = '\0';
    while (pos < len) {
        uint8_t l = m[pos];
        if (l == 0) { if (o && out[o - 1] == '.') o--; out[o] = '\0'; return 0; }
        if ((l & 0xC0) == 0xC0) {
            if (pos + 1 >= len || ++hops > 16) return -1;
            pos = ((size_t)(l & 0x3F) << 8) | m[pos + 1];
            continue;
        }
        if (l > 63 || pos + 1 + l > len) return -1;
        if (o + l + 2 >= olen) return -1;
        {
            size_t i;
            for (i = 0; i < l; i++)
                out[o++] = (char)tolower((unsigned char)m[pos + 1 + i]);
        }
        out[o++] = '.';
        pos += 1 + l;
    }
    return -1;
}

/* Extract qname/qtype and the offset just past the question. */
static int question_parse(const uint8_t *m, size_t len, char *qname, size_t qlen,
                          uint16_t *qtype, size_t *after)
{
    size_t pos = 12, end;

    if (len < 17) return -1;
    if (name_read(m, len, pos, qname, qlen) != 0) return -1;
    if (name_skip(m, len, pos, &end) != 0) return -1;
    if (end + 4 > len) return -1;
    *qtype = (uint16_t)((m[end] << 8) | m[end + 1]);
    *after = end + 4;
    return 0;
}

/* Returns 1 when the answer section carries a sinkhole address, and
 * reports the smallest TTL it saw. */
static int answer_inspect(const uint8_t *m, size_t len, uint32_t *min_ttl)
{
    uint16_t ancount, qdcount;
    size_t   pos;
    int      bogus = 0, i;

    *min_ttl = 0;
    if (len < 12) return 0;
    qdcount = (uint16_t)((m[4] << 8) | m[5]);
    ancount = (uint16_t)((m[6] << 8) | m[7]);
    pos = 12;

    for (i = 0; i < qdcount; i++) {
        size_t e;
        if (name_skip(m, len, pos, &e) != 0) return 0;
        pos = e + 4;
    }
    for (i = 0; i < ancount; i++) {
        size_t   e;
        uint16_t type, rdlen;
        uint32_t ttl;

        if (name_skip(m, len, pos, &e) != 0) return bogus;
        if (e + 10 > len) return bogus;
        type  = (uint16_t)((m[e] << 8) | m[e + 1]);
        ttl   = ((uint32_t)m[e + 4] << 24) | ((uint32_t)m[e + 5] << 16) |
                ((uint32_t)m[e + 6] << 8) | m[e + 7];
        rdlen = (uint16_t)((m[e + 8] << 8) | m[e + 9]);
        if (e + 10 + rdlen > len) return bogus;

        if (*min_ttl == 0 || ttl < *min_ttl) *min_ttl = ttl;
        if (type == 1 && rdlen == 4 && addr_is_bogus(AF_INET, m + e + 10))
            bogus = 1;
        if (type == 28 && rdlen == 16 && addr_is_bogus(AF_INET6, m + e + 10))
            bogus = 1;
        pos = e + 10 + rdlen;
    }
    return bogus;
}

/* ---- cache ----------------------------------------------------------- */

typedef struct {
    char     key[DP_MAX_HOST + 8];
    uint8_t *msg;
    size_t   len;
    long     expires;
} centry;

static centry g_cache[DP_DNS_CACHE];

static centry *cache_slot(const char *key)
{
    uint32_t h = dp_hash(key) % DP_DNS_CACHE;
    return &g_cache[h];
}

static const centry *cache_get(const char *key)
{
    centry *e = cache_slot(key);
    if (e->msg && strcmp(e->key, key) == 0 && e->expires > dp_now()) return e;
    return NULL;
}

static void cache_put(const char *key, const uint8_t *msg, size_t len, long ttl)
{
    centry *e = cache_slot(key);
    uint8_t *copy;

    if (len < 12 || len > DP_DNS_MSG) return;
    copy = malloc(len);
    if (!copy) return;
    memcpy(copy, msg, len);
    free(e->msg);
    snprintf(e->key, sizeof(e->key), "%s", key);
    e->msg     = copy;
    e->len     = len;
    e->expires = dp_now() + ttl;
}

/* ---- in flight queries ----------------------------------------------- */

typedef struct {
    int      used;
    int      fd;
    int      connected;
    int      up;                 /* index into g_cfg.upstream            */
    int      tries;
    int      lfd;                /* UDP socket to answer on              */
    uint16_t cid;
    struct sockaddr_storage cli;
    socklen_t clilen;
    uint8_t  q[DP_DNS_MSG + 2];
    size_t   qlen, qsent;
    uint8_t  r[DP_DNS_MSG + 2];
    size_t   rlen, rneed;
    long     deadline;
    char     key[DP_MAX_HOST + 8];
} dq;

static dq   g_dq[DP_DNS_INFLIGHT];
static int  g_dep = -1;
static int  g_u4 = -1, g_u6 = -1;
static int  g_fail_streak;

static void dq_free(dq *d)
{
    if (!d->used) return;
    if (d->fd >= 0) { epoll_ctl(g_dep, EPOLL_CTL_DEL, d->fd, NULL); close(d->fd); }
    memset(d, 0, sizeof(*d));
    d->fd = -1;
}

static void reply_raw(dq *d, const uint8_t *msg, size_t len)
{
    uint8_t out[DP_DNS_MSG];
    if (len < 12 || len > sizeof(out)) return;
    memcpy(out, msg, len);
    out[0] = (uint8_t)(d->cid >> 8);
    out[1] = (uint8_t)(d->cid & 0xff);
    sendto(d->lfd, out, len, 0, (struct sockaddr *)&d->cli, d->clilen);
}

static void reply_servfail(dq *d)
{
    uint8_t out[DP_DNS_MSG];
    size_t  len = d->qlen - 2;

    if (len < 12 || len > sizeof(out)) return;
    memcpy(out, d->q + 2, len);
    out[0] = (uint8_t)(d->cid >> 8);
    out[1] = (uint8_t)(d->cid & 0xff);
    out[2] = 0x81;                 /* QR=1, RD=1                          */
    out[3] = 0x82;                 /* RA=1, RCODE=SERVFAIL                */
    out[6] = out[7] = 0;           /* no answers                          */
    sendto(d->lfd, out, len, 0, (struct sockaddr *)&d->cli, d->clilen);
    g_stats.dns_failed++;
}

static int upstream_connect(dq *d);

/* Move to the next resolver, or give up. */
static void dq_retry(dq *d, const char *why)
{
    if (d->fd >= 0) { epoll_ctl(g_dep, EPOLL_CTL_DEL, d->fd, NULL); close(d->fd); d->fd = -1; }
    d->connected = 0;
    d->rlen = d->rneed = 0;
    d->qsent = 0;
    d->tries++;

    if (d->tries >= g_cfg.upstream_n || d->tries >= 3) {
        LOGD("dns give up (%s)", why);
        g_fail_streak++;
        reply_servfail(d);
        dq_free(d);
        return;
    }
    d->up = (d->up + 1) % g_cfg.upstream_n;
    if (upstream_connect(d) != 0) { reply_servfail(d); dq_free(d); }
}

static int upstream_connect(dq *d)
{
    struct sockaddr_storage ss;
    socklen_t sl;
    char      host[80];
    uint16_t  port;
    int       fd, on = 1;
    struct epoll_event ev;

    if (dp_parse_hostport(g_cfg.upstream[d->up], host, sizeof(host), &port, 53) != 0)
        return -1;
    if (dp_sa_from_str(host, port, &ss, &sl) != 0) return -1;

    fd = socket(ss.ss_family, SOCK_STREAM | SOCK_CLOEXEC | SOCK_NONBLOCK,
                IPPROTO_TCP);
    if (fd < 0) return -1;
    setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &on, sizeof(on));
    if (connect(fd, (struct sockaddr *)&ss, sl) != 0 && errno != EINPROGRESS) {
        close(fd);
        return -1;
    }
    d->fd       = fd;
    d->deadline = dp_now() + 5;

    memset(&ev, 0, sizeof(ev));
    ev.events   = EPOLLOUT;
    ev.data.ptr = d;
    if (epoll_ctl(g_dep, EPOLL_CTL_ADD, fd, &ev) != 0) {
        close(fd); d->fd = -1; return -1;
    }
    return 0;
}

static dq *dq_alloc(void)
{
    int i;
    for (i = 0; i < DP_DNS_INFLIGHT; i++)
        if (!g_dq[i].used) {
            memset(&g_dq[i], 0, sizeof(dq));
            g_dq[i].used = 1;
            g_dq[i].fd   = -1;
            return &g_dq[i];
        }
    return NULL;
}

/* ---- client side ------------------------------------------------------ */

static void on_query(int lfd)
{
    uint8_t  buf[DP_DNS_MSG];
    struct sockaddr_storage cli;
    socklen_t clen = sizeof(cli);
    ssize_t  n;
    char     qname[DP_MAX_HOST], key[DP_MAX_HOST + 8];
    uint16_t qtype;
    size_t   after;
    const centry *hit;
    dq      *d;

    n = recvfrom(lfd, buf, sizeof(buf), 0, (struct sockaddr *)&cli, &clen);
    if (n < 12) return;
    g_stats.dns_queries++;

    if (question_parse(buf, (size_t)n, qname, sizeof(qname), &qtype, &after) != 0)
        return;
    snprintf(key, sizeof(key), "%u|%s", qtype, qname);

    hit = cache_get(key);
    if (hit) {
        uint8_t out[DP_DNS_MSG];
        if (hit->len <= sizeof(out)) {
            memcpy(out, hit->msg, hit->len);
            out[0] = buf[0]; out[1] = buf[1];
            sendto(lfd, out, hit->len, 0, (struct sockaddr *)&cli, clen);
            g_stats.dns_cached++;
        }
        return;
    }

    d = dq_alloc();
    if (!d) { LOGW("dns table full"); return; }
    d->lfd    = lfd;
    d->cid    = (uint16_t)((buf[0] << 8) | buf[1]);
    d->cli    = cli;
    d->clilen = clen;
    d->up     = 0;
    snprintf(d->key, sizeof(d->key), "%s", key);

    d->q[0] = (uint8_t)((n >> 8) & 0xff);
    d->q[1] = (uint8_t)(n & 0xff);
    memcpy(d->q + 2, buf, (size_t)n);
    d->qlen = (size_t)n + 2;

    if (upstream_connect(d) != 0) { reply_servfail(d); dq_free(d); }
}

/* ---- upstream side ---------------------------------------------------- */

static void on_upstream(dq *d, uint32_t events)
{
    if (events & (EPOLLERR | EPOLLHUP)) { dq_retry(d, "transport"); return; }

    if (!d->connected && (events & EPOLLOUT)) {
        int err = 0; socklen_t el = sizeof(err);
        struct epoll_event ev;

        if (getsockopt(d->fd, SOL_SOCKET, SO_ERROR, &err, &el) != 0 || err) {
            dq_retry(d, "connect");
            return;
        }
        d->connected = 1;

        /* Split the query the same way we split a ClientHello: an
         * inspector matching on the question name in a single segment
         * sees only half of it. */
        if (g_cfg.dns_desync)
            dp_desync_send(d->fd, AF_INET, d->q, d->qlen, 2 + 14, DS_SPLIT);
        else
            (void)send(d->fd, d->q, d->qlen, MSG_NOSIGNAL);
        d->qsent = d->qlen;

        memset(&ev, 0, sizeof(ev));
        ev.events   = EPOLLIN;
        ev.data.ptr = d;
        epoll_ctl(g_dep, EPOLL_CTL_MOD, d->fd, &ev);
        d->deadline = dp_now() + 5;
        return;
    }

    if (events & EPOLLIN) {
        ssize_t n = recv(d->fd, d->r + d->rlen, sizeof(d->r) - d->rlen, 0);
        uint32_t ttl = 0;
        long     use_ttl;

        if (n <= 0) {
            if (n < 0 && (errno == EAGAIN || errno == EINTR)) return;
            dq_retry(d, "short read");
            return;
        }
        d->rlen += (size_t)n;
        if (d->rlen < 2) return;
        d->rneed = 2 + (((size_t)d->r[0] << 8) | d->r[1]);
        if (d->rneed > sizeof(d->r)) { dq_retry(d, "oversize"); return; }
        if (d->rlen < d->rneed) return;

        {
            const uint8_t *msg = d->r + 2;
            size_t         len = d->rneed - 2;
            int            rcode = msg[3] & 0x0F;

            if (rcode != 0 && rcode != 3) { dq_retry(d, "rcode"); return; }
            if (answer_inspect(msg, len, &ttl)) {
                g_stats.dns_bogus++;
                LOGI("sinkhole answer rejected for %s", d->key);
                dq_retry(d, "sinkhole");
                return;
            }

            use_ttl = (long)ttl;
            if (use_ttl < g_cfg.dns_cache_ttl_min) use_ttl = g_cfg.dns_cache_ttl_min;
            if (use_ttl > g_cfg.dns_cache_ttl_max) use_ttl = g_cfg.dns_cache_ttl_max;
            cache_put(d->key, msg, len, use_ttl);
            reply_raw(d, msg, len);
            g_fail_streak = 0;
        }
        dq_free(d);
    }
}

/* ---- lifecycle -------------------------------------------------------- */

static int bind_udp(int family)
{
    struct sockaddr_storage ss;
    socklen_t sl;
    int fd, on = 1;

    if (dp_sa_from_str(family == AF_INET ? "127.0.0.1" : "::1",
                       g_cfg.dns_port, &ss, &sl) != 0)
        return -1;
    fd = socket(family, SOCK_DGRAM | SOCK_CLOEXEC | SOCK_NONBLOCK, 0);
    if (fd < 0) return -1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));
    if (family == AF_INET6)
        setsockopt(fd, IPPROTO_IPV6, IPV6_V6ONLY, &on, sizeof(on));
    if (bind(fd, (struct sockaddr *)&ss, sl) != 0) {
        LOGE("dns bind %u failed: %s", g_cfg.dns_port, strerror(errno));
        close(fd);
        return -1;
    }
    return fd;
}

int dp_dns_start(void)
{
    struct epoll_event ev;

    if (g_cfg.upstream_n <= 0) {
        LOGW("no DNS upstreams configured, forwarder disabled");
        return -1;
    }
    g_dep = epoll_create1(EPOLL_CLOEXEC);
    if (g_dep < 0) return -1;

    g_u4 = bind_udp(AF_INET);
    if (g_u4 < 0) return -1;
    g_u6 = bind_udp(AF_INET6);

    memset(&ev, 0, sizeof(ev));
    ev.events   = EPOLLIN;
    ev.data.ptr = &g_u4;
    epoll_ctl(g_dep, EPOLL_CTL_ADD, g_u4, &ev);
    if (g_u6 >= 0) {
        ev.data.ptr = &g_u6;
        epoll_ctl(g_dep, EPOLL_CTL_ADD, g_u6, &ev);
    }
    LOGI("dns forwarder listening on 127.0.0.1:%u", g_cfg.dns_port);
    return 0;
}

void dp_dns_run(void)
{
    struct epoll_event evs[32];
    char flag[288];

    snprintf(flag, sizeof(flag), "%s/state/dns_unhealthy", g_cfg.rundir);

    while (!g_stop) {
        int n = epoll_wait(g_dep, evs, 32, 5000);
        int i;
        long now;

        if (n < 0) {
            if (errno == EINTR) continue;
            break;
        }
        for (i = 0; i < n; i++) {
            void *p = evs[i].data.ptr;
            if (p == &g_u4) { on_query(g_u4); continue; }
            if (p == &g_u6) { on_query(g_u6); continue; }
            on_upstream((dq *)p, evs[i].events);
        }

        now = dp_now();
        for (i = 0; i < DP_DNS_INFLIGHT; i++)
            if (g_dq[i].used && g_dq[i].deadline && now > g_dq[i].deadline)
                dq_retry(&g_dq[i], "timeout");

        /* Hand the supervisor a reason to pull the DNS redirect. */
        if (g_fail_streak >= 8) {
            dp_write_atomic(flag, "1\n", 2);
            LOGW("dns upstreams unreachable, requesting fallback to system resolver");
            g_fail_streak = 0;
        }
    }
}

void dp_dns_stop(void)
{
    int i;
    for (i = 0; i < DP_DNS_INFLIGHT; i++) dq_free(&g_dq[i]);
    for (i = 0; i < DP_DNS_CACHE; i++) { free(g_cache[i].msg); g_cache[i].msg = NULL; }
    if (g_u4 >= 0)  { close(g_u4);  g_u4 = -1; }
    if (g_u6 >= 0)  { close(g_u6);  g_u6 = -1; }
    if (g_dep >= 0) { close(g_dep); g_dep = -1; }
}

/* ---- diagnostic probe -------------------------------------------------- */
/*
 * Ask one specific resolver one specific question and describe what came
 * back, including whether the answer points into a sinkhole range. This is
 * what lets the diagnostics page say "your resolver is answering, but with
 * the wrong address" instead of the useless "DNS failed".
 */

static size_t query_build(uint8_t *out, size_t cap, const char *name, uint16_t id)
{
    size_t p = 0;
    const char *lab = name;

    if (cap < 12 + strlen(name) + 6) return 0;
    out[p++] = (uint8_t)(id >> 8); out[p++] = (uint8_t)(id & 0xff);
    out[p++] = 0x01; out[p++] = 0x00;      /* RD */
    out[p++] = 0x00; out[p++] = 0x01;      /* QDCOUNT */
    out[p++] = 0x00; out[p++] = 0x00;
    out[p++] = 0x00; out[p++] = 0x00;
    out[p++] = 0x00; out[p++] = 0x00;

    while (*lab) {
        const char *dot = strchr(lab, '.');
        size_t l = dot ? (size_t)(dot - lab) : strlen(lab);
        if (l == 0 || l > 63) return 0;
        out[p++] = (uint8_t)l;
        memcpy(out + p, lab, l);
        p += l;
        if (!dot) break;
        lab = dot + 1;
    }
    out[p++] = 0x00;
    out[p++] = 0x00; out[p++] = 0x01;      /* QTYPE A     */
    out[p++] = 0x00; out[p++] = 0x01;      /* QCLASS IN   */
    return p;
}

/* Pull the first A record out of an answer section. */
static int answer_first_a(const uint8_t *m, size_t len, char *out, size_t olen)
{
    uint16_t qd, an;
    size_t   pos;
    int      i;

    if (len < 12) return -1;
    qd = (uint16_t)((m[4] << 8) | m[5]);
    an = (uint16_t)((m[6] << 8) | m[7]);
    pos = 12;
    for (i = 0; i < qd; i++) {
        size_t e;
        if (name_skip(m, len, pos, &e) != 0) return -1;
        pos = e + 4;
    }
    for (i = 0; i < an; i++) {
        size_t e; uint16_t type, rdlen;
        if (name_skip(m, len, pos, &e) != 0) return -1;
        if (e + 10 > len) return -1;
        type  = (uint16_t)((m[e] << 8) | m[e + 1]);
        rdlen = (uint16_t)((m[e + 8] << 8) | m[e + 9]);
        if (e + 10 + rdlen > len) return -1;
        if (type == 1 && rdlen == 4) {
            inet_ntop(AF_INET, m + e + 10, out, (socklen_t)olen);
            return addr_is_bogus(AF_INET, m + e + 10) ? 1 : 0;
        }
        pos = e + 10 + rdlen;
    }
    return -1;
}

int dp_dns_probe(const char *name, const char *server, int use_tcp, int timeout_ms)
{
    struct sockaddr_storage ss;
    socklen_t sl;
    uint8_t   q[DP_DNS_MSG], r[DP_DNS_MSG + 2];
    char      host[80], addr[64] = "";
    uint16_t  port;
    size_t    qlen;
    int       fd, bogus;
    ssize_t   n;
    struct pollfd pfd;

    if (dp_parse_hostport(server, host, sizeof(host), &port, 53) != 0 ||
        dp_sa_from_str(host, port, &ss, &sl) != 0) {
        printf("result=error\nnote=bad server address\n");
        return 2;
    }
    qlen = query_build(q, sizeof(q), name, 0x4242);
    if (qlen == 0) { printf("result=error\nnote=bad name\n"); return 2; }

    fd = socket(ss.ss_family, (use_tcp ? SOCK_STREAM : SOCK_DGRAM) | SOCK_CLOEXEC,
                use_tcp ? IPPROTO_TCP : IPPROTO_UDP);
    if (fd < 0) { printf("result=error\nnote=socket\n"); return 2; }

    if (connect(fd, (struct sockaddr *)&ss, sl) != 0) {
        printf("result=unreachable\nnote=%s\n", strerror(errno));
        close(fd);
        return 1;
    }
    if (use_tcp) {
        uint8_t framed[DP_DNS_MSG + 2];
        framed[0] = (uint8_t)(qlen >> 8);
        framed[1] = (uint8_t)(qlen & 0xff);
        memcpy(framed + 2, q, qlen);
        if (send(fd, framed, qlen + 2, MSG_NOSIGNAL) < 0) {
            printf("result=reset\nnote=%s\n", strerror(errno));
            close(fd);
            return 1;
        }
    } else if (send(fd, q, qlen, MSG_NOSIGNAL) < 0) {
        printf("result=error\nnote=%s\n", strerror(errno));
        close(fd);
        return 1;
    }

    pfd.fd = fd; pfd.events = POLLIN; pfd.revents = 0;
    if (poll(&pfd, 1, timeout_ms) <= 0) {
        printf("result=timeout\nnote=no answer within %d ms\n", timeout_ms);
        close(fd);
        return 1;
    }
    n = recv(fd, r, sizeof(r), 0);
    close(fd);
    if (n <= 0) { printf("result=reset\nnote=connection closed\n"); return 1; }

    {
        const uint8_t *msg = use_tcp ? r + 2 : r;
        size_t         len = use_tcp ? (size_t)n - 2 : (size_t)n;
        int            rcode;

        if ((use_tcp && n < 14) || len < 12) {
            printf("result=malformed\nnote=short answer\n");
            return 1;
        }
        rcode = msg[3] & 0x0F;
        bogus = answer_first_a(msg, len, addr, sizeof(addr));

        if (rcode == 3) { printf("result=nxdomain\nnote=name does not exist\n"); return 0; }
        if (rcode != 0) { printf("result=rcode%d\nnote=resolver returned an error\n", rcode); return 1; }
        if (bogus < 0)  { printf("result=noaddress\nnote=answer carried no A record\n"); return 1; }
        if (bogus == 1) {
            printf("result=poisoned\naddress=%s\nnote=answer points at a known sinkhole\n", addr);
            return 1;
        }
        printf("result=ok\naddress=%s\nnote=resolved normally\n", addr);
        return 0;
    }
}
