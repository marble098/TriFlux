#!/usr/bin/env bash
#
# build.sh - build dpcore for Android and drop it into ../bin/
#
# Requirements: Android NDK r25 or newer, cmake 3.18+, ninja.
# Usage:
#   ANDROID_NDK_HOME=/opt/android-ndk ./build.sh            # arm64 only
#   ANDROID_NDK_HOME=/opt/android-ndk ./build.sh all        # all ABIs
#
# The result is a static-PIE-friendly, fully stripped binary with no
# dependency beyond bionic. Nothing is downloaded at build time.

set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$HERE/../bin"
API=29                       # Android 10
NDK="${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}"

if [ -z "$NDK" ] || [ ! -d "$NDK" ]; then
    echo "error: set ANDROID_NDK_HOME to your NDK path" >&2
    exit 1
fi

TOOLCHAIN="$NDK/build/cmake/android.toolchain.cmake"
[ -f "$TOOLCHAIN" ] || { echo "error: toolchain file not found: $TOOLCHAIN" >&2; exit 1; }

case "${1:-arm64}" in
    all) ABIS="arm64-v8a armeabi-v7a x86_64" ;;
    *)   ABIS="arm64-v8a" ;;
esac

mkdir -p "$OUT"

for ABI in $ABIS; do
    BUILD="$HERE/.build-$ABI"
    rm -rf "$BUILD"
    cmake -S "$HERE" -B "$BUILD" -G Ninja \
        -DCMAKE_TOOLCHAIN_FILE="$TOOLCHAIN" \
        -DANDROID_ABI="$ABI" \
        -DANDROID_PLATFORM="android-$API" \
        -DCMAKE_BUILD_TYPE=Release
    cmake --build "$BUILD" --parallel

    STRIP="$(find "$NDK/toolchains/llvm/prebuilt" -name 'llvm-strip' | head -n1)"
    [ -n "$STRIP" ] && "$STRIP" --strip-all "$BUILD/dpcore"

    case "$ABI" in
        arm64-v8a)   NAME=dpcore-arm64 ;;
        armeabi-v7a) NAME=dpcore-arm ;;
        x86_64)      NAME=dpcore-x86_64 ;;
        *)           NAME="dpcore-$ABI" ;;
    esac
    install -m 0755 "$BUILD/dpcore" "$OUT/$NAME"
    echo "built $OUT/$NAME"
    sha256sum "$OUT/$NAME" | tee -a "$OUT/SHA256SUMS.new"
    rm -rf "$BUILD"
done

[ -f "$OUT/SHA256SUMS.new" ] && mv "$OUT/SHA256SUMS.new" "$OUT/SHA256SUMS"

# customize.sh picks the right file at install time and renames it to dpcore.
echo "done. Commit bin/ and SHA256SUMS alongside the module."
