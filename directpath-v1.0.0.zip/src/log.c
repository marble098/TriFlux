/* log.c - level filtered, size capped logging.
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * Deliberately dumb: one file, one rotation, no payload bytes ever.
 * Callers pass hostnames and numbers only.
 */

#define _GNU_SOURCE
#include "dpcore.h"

#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

static FILE           *g_fp;
static char            g_path[224];
static dp_level        g_level  = LL_INFO;
static long            g_max    = 262144;
static pthread_mutex_t g_lock   = PTHREAD_MUTEX_INITIALIZER;

static const char *lvl_tag(dp_level l)
{
    switch (l) {
    case LL_ERROR: return "E";
    case LL_WARN:  return "W";
    case LL_INFO:  return "I";
    default:       return "D";
    }
}

void dp_log_open(const char *path, dp_level lvl, long max_bytes)
{
    pthread_mutex_lock(&g_lock);
    if (g_fp) { fclose(g_fp); g_fp = NULL; }
    snprintf(g_path, sizeof(g_path), "%s", path);
    g_level = lvl;
    g_max   = max_bytes > 8192 ? max_bytes : 8192;
    g_fp    = fopen(g_path, "a");
    if (g_fp) {
        setvbuf(g_fp, NULL, _IOLBF, 0);
        fchmod(fileno(g_fp), 0600);
    }
    pthread_mutex_unlock(&g_lock);
}

void dp_log_close(void)
{
    pthread_mutex_lock(&g_lock);
    if (g_fp) { fclose(g_fp); g_fp = NULL; }
    pthread_mutex_unlock(&g_lock);
}

/* Single generation rotation: dpcore.log -> dpcore.log.1. Keeps the
 * on-disk footprint bounded at 2 * g_max without any external cron. */
static void rotate_locked(void)
{
    char old[240];
    long sz;

    if (!g_fp) return;
    sz = ftell(g_fp);
    if (sz < g_max) return;

    fclose(g_fp);
    g_fp = NULL;
    snprintf(old, sizeof(old), "%s.1", g_path);
    rename(g_path, old);
    g_fp = fopen(g_path, "a");
    if (g_fp) {
        setvbuf(g_fp, NULL, _IOLBF, 0);
        fchmod(fileno(g_fp), 0600);
    }
}

void dp_logf(dp_level lvl, const char *fmt, ...)
{
    va_list    ap;
    time_t     t;
    struct tm  tm;
    char       ts[32];

    if (lvl > g_level) return;

    pthread_mutex_lock(&g_lock);
    if (!g_fp) { pthread_mutex_unlock(&g_lock); return; }

    t = time(NULL);
    localtime_r(&t, &tm);
    strftime(ts, sizeof(ts), "%m-%d %H:%M:%S", &tm);

    fprintf(g_fp, "%s %s dpcore: ", ts, lvl_tag(lvl));
    va_start(ap, fmt);
    vfprintf(g_fp, fmt, ap);
    va_end(ap);
    fputc('\n', g_fp);

    rotate_locked();
    pthread_mutex_unlock(&g_lock);
}
