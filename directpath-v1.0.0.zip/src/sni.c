/* sni.c - locate the destination name inside the first client chunk.
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * Two parsers, both strictly read-only and strictly bounds checked:
 *
 *   dp_tls_peek_sni()   reads the server_name extension of a TLS
 *                       ClientHello. That field is transmitted in the
 *                       clear by design; reading it is not interception
 *                       and involves no key material whatsoever.
 *
 *   dp_http_peek_host() reads the Host header of a plaintext HTTP
 *                       request.
 *
 * Both also return the byte offset of the name so the desync layer can
 * place a segment boundary exactly where a middlebox is looking.
 */

#include "dpcore.h"

#include <strings.h>

#include <ctype.h>
#include <string.h>

static int name_is_sane(const char *h)
{
    size_t n = strlen(h), i;
    if (n < 2 || n > 253) return 0;
    if (h[0] == '.' || h[n - 1] == '.') return 0;
    for (i = 0; i < n; i++) {
        char c = h[i];
        if (!(isalnum((unsigned char)c) || c == '.' || c == '-' || c == '_'))
            return 0;
    }
    /* Reject bare IP literals: nothing to match a domain rule against. */
    for (i = 0; i < n; i++)
        if (isalpha((unsigned char)h[i])) return 1;
    return 0;
}

#define RD16(p) ((size_t)(((p)[0] << 8) | (p)[1]))

int dp_tls_peek_sni(const uint8_t *buf, size_t len, char *host, size_t hlen,
                    size_t *offset)
{
    size_t pos, end, ext_end, sni_end, n;

    if (len < 45)         return 0;
    if (buf[0] != 0x16)   return 0;   /* handshake record            */
    if (buf[5] != 0x01)   return 0;   /* ClientHello                 */

    /* Bound the walk by the record length when it is present and fits,
     * otherwise by what we actually hold. A ClientHello split across
     * records is rare enough that we simply decline to guess. */
    end = 5 + RD16(buf + 3);
    if (end > len) end = len;
    if (end < 45)  return 0;

    pos = 43;                       /* skip version + 32 byte random */
    if (pos >= end) return 0;

    n = buf[pos++];                 /* session id                    */
    if (pos + n > end) return 0;
    pos += n;

    if (pos + 2 > end) return 0;
    n = RD16(buf + pos); pos += 2;  /* cipher suites                 */
    if (pos + n > end) return 0;
    pos += n;

    if (pos + 1 > end) return 0;
    n = buf[pos++];                 /* compression methods           */
    if (pos + n > end) return 0;
    pos += n;

    if (pos + 2 > end) return 0;
    n = RD16(buf + pos); pos += 2;  /* extensions block              */
    ext_end = pos + n;
    if (ext_end > end) ext_end = end;

    while (pos + 4 <= ext_end) {
        size_t etype = RD16(buf + pos);
        size_t elen  = RD16(buf + pos + 2);
        size_t ebody = pos + 4;

        if (ebody + elen > ext_end) return 0;

        if (etype == 0x0000) {                 /* server_name          */
            size_t p = ebody;
            if (p + 2 > ebody + elen) return 0;
            sni_end = p + 2 + RD16(buf + p);
            p += 2;
            if (sni_end > ebody + elen) return 0;

            while (p + 3 <= sni_end) {
                size_t ntype = buf[p];
                size_t nlen  = RD16(buf + p + 1);
                p += 3;
                if (p + nlen > sni_end) return 0;
                if (ntype == 0 && nlen > 0 && nlen < hlen) {
                    size_t i;
                    for (i = 0; i < nlen; i++)
                        host[i] = (char)tolower((unsigned char)buf[p + i]);
                    host[nlen] = '\0';
                    if (!name_is_sane(host)) { host[0] = '\0'; return 0; }
                    if (offset) *offset = p;
                    return 1;
                }
                p += nlen;
            }
            return 0;
        }
        pos = ebody + elen;
    }
    return 0;
}

int dp_http_peek_host(const uint8_t *buf, size_t len, char *host, size_t hlen,
                      size_t *offset)
{
    size_t i, scan;

    /* Only look at things that begin like a request line. */
    if (len < 16) return 0;
    if (!isupper((unsigned char)buf[0])) return 0;

    scan = len > 2048 ? 2048 : len;
    for (i = 0; i + 6 < scan; i++) {
        if (buf[i] != '\n') continue;
        if (strncasecmp((const char *)buf + i + 1, "Host:", 5) != 0) continue;
        {
            size_t p = i + 6, s, n = 0;
            while (p < scan && (buf[p] == ' ' || buf[p] == '\t')) p++;
            s = p;
            while (p < scan && buf[p] != '\r' && buf[p] != '\n' &&
                   buf[p] != ':' && n + 1 < hlen) {
                host[n++] = (char)tolower((unsigned char)buf[p]);
                p++;
            }
            host[n] = '\0';
            if (!name_is_sane(host)) { host[0] = '\0'; return 0; }
            if (offset) *offset = s;
            return 1;
        }
    }
    return 0;
}
