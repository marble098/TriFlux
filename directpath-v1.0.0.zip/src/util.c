/* util.c - small helpers shared across dpcore.
 * SPDX-License-Identifier: GPL-3.0-or-later */

#define _GNU_SOURCE
#include "dpcore.h"

#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

int dp_set_nonblock(int fd)
{
    int fl = fcntl(fd, F_GETFL, 0);
    if (fl < 0) return -1;
    return fcntl(fd, F_SETFL, fl | O_NONBLOCK);
}

int dp_set_cloexec(int fd)
{
    int fl = fcntl(fd, F_GETFD, 0);
    if (fl < 0) return -1;
    return fcntl(fd, F_SETFD, fl | FD_CLOEXEC);
}

long dp_now(void)
{
    struct timespec ts;
    if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0) return (long)time(NULL);
    return (long)ts.tv_sec;
}

/* Write to <path>.tmp then rename, so a reader never observes a half
 * written file even if we are killed mid-write. */
int dp_write_atomic(const char *path, const char *data, size_t len)
{
    char tmp[320];
    int  fd, rc = -1;
    ssize_t n;

    if (snprintf(tmp, sizeof(tmp), "%s.tmp", path) >= (int)sizeof(tmp))
        return -1;

    fd = open(tmp, O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0600);
    if (fd < 0) return -1;

    while (len > 0) {
        n = write(fd, data, len);
        if (n < 0) {
            if (errno == EINTR) continue;
            goto out;
        }
        data += n;
        len  -= (size_t)n;
    }
    if (fsync(fd) != 0) goto out;
    rc = 0;
out:
    close(fd);
    if (rc == 0 && rename(tmp, path) != 0) rc = -1;
    if (rc != 0) unlink(tmp);
    return rc;
}

char *dp_trim(char *s)
{
    char *e;
    while (*s && isspace((unsigned char)*s)) s++;
    if (!*s) return s;
    e = s + strlen(s) - 1;
    while (e > s && isspace((unsigned char)*e)) *e-- = '\0';
    return s;
}

/* Accepts "1.1.1.1", "1.1.1.1:53", "[2606:4700:4700::1111]:53". */
int dp_parse_hostport(const char *spec, char *host, size_t hlen, uint16_t *port,
                      uint16_t defport)
{
    const char *colon;
    size_t      n;

    *port = defport;
    if (!spec || !*spec) return -1;

    if (*spec == '[') {
        const char *close = strchr(spec, ']');
        if (!close) return -1;
        n = (size_t)(close - spec - 1);
        if (n == 0 || n >= hlen) return -1;
        memcpy(host, spec + 1, n);
        host[n] = '\0';
        if (close[1] == ':') {
            long p = strtol(close + 2, NULL, 10);
            if (p < 1 || p > 65535) return -1;
            *port = (uint16_t)p;
        }
        return 0;
    }

    colon = strrchr(spec, ':');
    /* A bare IPv6 literal contains several colons and no port. */
    if (colon && strchr(spec, ':') == colon) {
        long p = strtol(colon + 1, NULL, 10);
        if (p < 1 || p > 65535) return -1;
        *port = (uint16_t)p;
        n = (size_t)(colon - spec);
    } else {
        n = strlen(spec);
    }
    if (n == 0 || n >= hlen) return -1;
    memcpy(host, spec, n);
    host[n] = '\0';
    return 0;
}

/* Numeric only. dpcore never performs a recursive lookup of its own
 * upstreams, which would be a chicken-and-egg problem. */
int dp_sa_from_str(const char *host, uint16_t port, struct sockaddr_storage *ss,
                   socklen_t *len)
{
    memset(ss, 0, sizeof(*ss));

    if (strchr(host, ':')) {
        struct sockaddr_in6 *s6 = (struct sockaddr_in6 *)ss;
        if (inet_pton(AF_INET6, host, &s6->sin6_addr) != 1) return -1;
        s6->sin6_family = AF_INET6;
        s6->sin6_port   = htons(port);
        *len = sizeof(*s6);
        return 0;
    } else {
        struct sockaddr_in *s4 = (struct sockaddr_in *)ss;
        if (inet_pton(AF_INET, host, &s4->sin_addr) != 1) return -1;
        s4->sin_family = AF_INET;
        s4->sin_port   = htons(port);
        *len = sizeof(*s4);
        return 0;
    }
}

/* Destinations we must never touch: loopback, RFC1918, CGNAT, link-local,
 * multicast, and the IPv6 equivalents. The firewall layer already excludes
 * these, this is the belt to that suspenders. */
int dp_addr_is_private(const struct sockaddr_storage *ss)
{
    if (ss->ss_family == AF_INET) {
        uint32_t a = ntohl(((const struct sockaddr_in *)ss)->sin_addr.s_addr);
        if ((a >> 24) == 10)  return 1;
        if ((a >> 24) == 127) return 1;
        if ((a >> 24) == 0)   return 1;
        if ((a & 0xFFF00000u) == 0xAC100000u) return 1;   /* 172.16/12  */
        if ((a & 0xFFFF0000u) == 0xC0A80000u) return 1;   /* 192.168/16 */
        if ((a & 0xFFC00000u) == 0x64400000u) return 1;   /* 100.64/10  */
        if ((a & 0xFFFF0000u) == 0xA9FE0000u) return 1;   /* 169.254/16 */
        if ((a >> 28) == 0xE) return 1;                   /* multicast  */
        return 0;
    }
    if (ss->ss_family == AF_INET6) {
        const uint8_t *b = ((const struct sockaddr_in6 *)ss)->sin6_addr.s6_addr;
        static const uint8_t lo[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1};
        if (memcmp(b, lo, 16) == 0) return 1;
        if ((b[0] & 0xFE) == 0xFC) return 1;              /* fc00::/7   */
        if (b[0] == 0xFE && (b[1] & 0xC0) == 0x80) return 1; /* fe80::/10 */
        if (b[0] == 0xFF) return 1;                       /* multicast  */
        /* IPv4-mapped: re-check as v4 */
        if (memcmp(b, "\0\0\0\0\0\0\0\0\0\0\xff\xff", 12) == 0) {
            struct sockaddr_storage tmp;
            struct sockaddr_in *s4 = (struct sockaddr_in *)&tmp;
            memset(&tmp, 0, sizeof(tmp));
            s4->sin_family = AF_INET;
            memcpy(&s4->sin_addr, b + 12, 4);
            return dp_addr_is_private(&tmp);
        }
        return 0;
    }
    return 1;
}

const char *dp_sa_str(const struct sockaddr_storage *ss, char *buf, size_t len)
{
    char ip[INET6_ADDRSTRLEN] = "?";
    uint16_t port = 0;

    if (ss->ss_family == AF_INET) {
        const struct sockaddr_in *s = (const struct sockaddr_in *)ss;
        inet_ntop(AF_INET, &s->sin_addr, ip, sizeof(ip));
        port = ntohs(s->sin_port);
    } else if (ss->ss_family == AF_INET6) {
        const struct sockaddr_in6 *s = (const struct sockaddr_in6 *)ss;
        inet_ntop(AF_INET6, &s->sin6_addr, ip, sizeof(ip));
        port = ntohs(s->sin6_port);
    }
    snprintf(buf, len, "%s/%u", ip, port);
    return buf;
}

/* Recover the pre-REDIRECT destination of an accepted connection. */
int dp_orig_dst(int fd, struct sockaddr_storage *ss, socklen_t *len)
{
    socklen_t l = sizeof(*ss);
    memset(ss, 0, sizeof(*ss));

    /* Try IPv6 first: on a dual-stack listener the socket is AF_INET6 even
     * for v4-mapped peers, and the v4 lookup then returns garbage. */
    if (getsockopt(fd, IPPROTO_IPV6, DP_SO_ORIGINAL_DST, ss, &l) == 0 &&
        ss->ss_family == AF_INET6) {
        *len = l;
        return 0;
    }
    l = sizeof(*ss);
    if (getsockopt(fd, IPPROTO_IP, DP_SO_ORIGINAL_DST, ss, &l) == 0 &&
        ss->ss_family == AF_INET) {
        *len = l;
        return 0;
    }
    /* No NAT entry: the client connected to us directly. */
    l = sizeof(*ss);
    if (getsockname(fd, (struct sockaddr *)ss, &l) == 0) {
        *len = l;
        return 1;   /* caller treats this as "not redirected" */
    }
    return -1;
}

uint32_t dp_hash(const char *s)
{
    uint32_t h = 2166136261u;
    while (*s) {
        h ^= (uint8_t)tolower((unsigned char)*s++);
        h *= 16777619u;
    }
    return h;
}
