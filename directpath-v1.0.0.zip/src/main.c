/* main.c - dpcore entry point.
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * Two worker threads share one process so the supervisor has exactly one
 * PID to watch:
 *
 *   relay thread   transparent TCP repair
 *   dns thread     validating forwarder (optional)
 *
 * The most important thing in this file is the fatal signal handler. If
 * dpcore dies, the firewall still points traffic at a port nobody is
 * listening on, and the phone loses the internet. So before exiting for
 * any reason at all, including SIGSEGV, we execute the rollback helper.
 * The supervisor is the second line of defence, not the first.
 */

#define _GNU_SOURCE
#include "dpcore.h"

#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

dp_config       g_cfg;
dp_stats        g_stats;
volatile int    g_stop;

static char     g_rollback[288];
static char     g_pidfile[288];
static char     g_statfile[288];
static int      g_rollback_done;

/* ---- defaults --------------------------------------------------------- */

static void config_defaults(void)
{
    memset(&g_cfg, 0, sizeof(g_cfg));
    snprintf(g_cfg.rundir,  sizeof(g_cfg.rundir),  "%s", "/data/adb/directpath");
    snprintf(g_cfg.ruledir, sizeof(g_cfg.ruledir), "%s", "/data/adb/directpath/rules");
    snprintf(g_cfg.logfile, sizeof(g_cfg.logfile), "%s", "/data/adb/directpath/log/dpcore.log");
    g_cfg.loglevel          = LL_INFO;
    g_cfg.logmax            = 262144;
    g_cfg.proxy_port        = 9451;
    g_cfg.dns_port          = 9453;
    g_cfg.proxy_enabled     = 1;
    g_cfg.dns_enabled       = 1;
    g_cfg.strategy          = DS_SPLIT;
    g_cfg.split_pos         = 3;
    g_cfg.fake_ttl          = 4;
    g_cfg.split_delay_us    = 0;
    g_cfg.scope_all         = 0;
    g_cfg.adaptive          = 1;
    g_cfg.dns_tcp           = 1;
    g_cfg.dns_desync        = 1;
    g_cfg.dns_cache_ttl_min = 60;
    g_cfg.dns_cache_ttl_max = 3600;
    g_cfg.upstream_n        = 0;
}

static int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

/*
 * Strict key=value reader. Unknown keys are ignored rather than fatal, so
 * a newer config on an older binary degrades instead of refusing to boot.
 * Every value is range checked here and nowhere else.
 */
int dp_config_load(const char *path)
{
    FILE *f = fopen(path, "r");
    char  line[512];

    if (!f) return -1;
    while (fgets(line, sizeof(line), f)) {
        char *s = dp_trim(line), *eq, *k, *v;

        if (!*s || *s == '#' || *s == ';') continue;
        eq = strchr(s, '=');
        if (!eq) continue;
        *eq = '\0';
        k = dp_trim(s);
        v = dp_trim(eq + 1);
        if (!*k || !*v) continue;

        if      (!strcmp(k, "rundir"))        snprintf(g_cfg.rundir, sizeof(g_cfg.rundir), "%s", v);
        else if (!strcmp(k, "ruledir"))       snprintf(g_cfg.ruledir, sizeof(g_cfg.ruledir), "%s", v);
        else if (!strcmp(k, "logfile"))       snprintf(g_cfg.logfile, sizeof(g_cfg.logfile), "%s", v);
        else if (!strcmp(k, "loglevel")) {
            if      (!strcmp(v, "error")) g_cfg.loglevel = LL_ERROR;
            else if (!strcmp(v, "warn"))  g_cfg.loglevel = LL_WARN;
            else if (!strcmp(v, "debug")) g_cfg.loglevel = LL_DEBUG;
            else                          g_cfg.loglevel = LL_INFO;
        }
        else if (!strcmp(k, "log_max_bytes")) g_cfg.logmax = clampi(atoi(v), 16384, 4194304);
        else if (!strcmp(k, "proxy_port"))    g_cfg.proxy_port = (uint16_t)clampi(atoi(v), 1024, 65535);
        else if (!strcmp(k, "dns_port"))      g_cfg.dns_port = (uint16_t)clampi(atoi(v), 1024, 65535);
        else if (!strcmp(k, "proxy_enabled")) g_cfg.proxy_enabled = atoi(v) ? 1 : 0;
        else if (!strcmp(k, "dns_enabled"))   g_cfg.dns_enabled = atoi(v) ? 1 : 0;
        else if (!strcmp(k, "strategy"))      g_cfg.strategy = dp_strategy_from_name(v);
        else if (!strcmp(k, "split_pos"))     g_cfg.split_pos = clampi(atoi(v), 1, 2048);
        else if (!strcmp(k, "fake_ttl"))      g_cfg.fake_ttl = clampi(atoi(v), 1, 16);
        else if (!strcmp(k, "split_delay_us"))g_cfg.split_delay_us = clampi(atoi(v), 0, 50000);
        else if (!strcmp(k, "scope_all"))     g_cfg.scope_all = atoi(v) ? 1 : 0;
        else if (!strcmp(k, "adaptive"))      g_cfg.adaptive = atoi(v) ? 1 : 0;
        else if (!strcmp(k, "dns_desync"))    g_cfg.dns_desync = atoi(v) ? 1 : 0;
        else if (!strcmp(k, "dns_cache_ttl_min")) g_cfg.dns_cache_ttl_min = clampi(atoi(v), 5, 3600);
        else if (!strcmp(k, "dns_cache_ttl_max")) g_cfg.dns_cache_ttl_max = clampi(atoi(v), 60, 86400);
        else if (!strcmp(k, "dns_upstream")) {
            /* comma separated list of numeric addresses */
            char *p = v;
            g_cfg.upstream_n = 0;
            while (*p && g_cfg.upstream_n < DP_MAX_UPSTREAMS) {
                char *c = strchr(p, ',');
                size_t l = c ? (size_t)(c - p) : strlen(p);
                if (l > 0 && l < sizeof(g_cfg.upstream[0])) {
                    memcpy(g_cfg.upstream[g_cfg.upstream_n], p, l);
                    g_cfg.upstream[g_cfg.upstream_n][l] = '\0';
                    g_cfg.upstream_n++;
                }
                if (!c) break;
                p = c + 1;
            }
        }
    }
    fclose(f);
    if (g_cfg.dns_cache_ttl_max < g_cfg.dns_cache_ttl_min)
        g_cfg.dns_cache_ttl_max = g_cfg.dns_cache_ttl_min;
    return 0;
}

/* ---- stats ------------------------------------------------------------ */

void dp_stats_dump(const char *path)
{
    char buf[768];
    int  n;

    n = snprintf(buf, sizeof(buf),
        "pid=%d\nversion=%s\nuptime=%ld\nstrategy=%s\nscope=%s\n"
        "conn_total=%lu\nconn_active=%lu\nconn_repaired=%lu\n"
        "conn_passthrough=%lu\nconn_failed=%lu\nreset_seen=%lu\n"
        "dns_queries=%lu\ndns_cached=%lu\ndns_bogus=%lu\ndns_failed=%lu\n",
        (int)getpid(), DP_VERSION, dp_now() - g_stats.started_at,
        dp_strategy_name(g_cfg.strategy), g_cfg.scope_all ? "all" : "rules",
        g_stats.conn_total, g_stats.conn_active, g_stats.conn_repaired,
        g_stats.conn_passthrough, g_stats.conn_failed, g_stats.reset_seen,
        g_stats.dns_queries, g_stats.dns_cached, g_stats.dns_bogus,
        g_stats.dns_failed);
    if (n > 0) dp_write_atomic(path, buf, (size_t)n);
}

/* ---- fail open -------------------------------------------------------- */
/*
 * Async signal safe enough: fork+exec only. We deliberately do not try to
 * flush logs or free memory here, because we may be inside a SIGSEGV.
 */
static void run_rollback(void)
{
    pid_t p;

    if (g_rollback_done || g_rollback[0] == '\0') return;
    g_rollback_done = 1;

    p = fork();
    if (p == 0) {
        execl("/system/bin/sh", "sh", g_rollback, "panic", (char *)NULL);
        _exit(127);
    }
}

static void on_term(int sig)
{
    (void)sig;
    g_stop = 1;
}

static void on_fatal(int sig)
{
    run_rollback();
    signal(sig, SIG_DFL);
    raise(sig);
}

static void on_hup(int sig)
{
    (void)sig;
    /* Reloading rule files from a signal handler would race the relay
     * thread, so we only mark it; the relay picks it up on its next tick
     * by way of the supervisor restarting us. Cheap and predictable. */
    g_stop = 1;
}

/* ---- threads ---------------------------------------------------------- */

static void *relay_thread(void *arg)
{
    (void)arg;
    dp_proxy_run();
    g_stop = 1;
    return NULL;
}

static void *dns_thread(void *arg)
{
    (void)arg;
    dp_dns_run();
    return NULL;
}

static int write_pidfile(void)
{
    char buf[32];
    int  n = snprintf(buf, sizeof(buf), "%d\n", (int)getpid());
    return dp_write_atomic(g_pidfile, buf, (size_t)n);
}

static void usage(void)
{
    fprintf(stderr,
        "dpcore " DP_VERSION "\n"
        "usage:\n"
        "  dpcore --config PATH [--rollback PATH] [--foreground]\n"
        "  dpcore --probe\n"
        "  dpcore --check IP PORT [--sni NAME] [--strategy S] [--timeout MS]\n"
        "  dpcore --resolve NAME --server IP [--udp] [--timeout MS]\n"
        "  dpcore --version\n");
}

int main(int argc, char **argv)
{
    const char *cfgpath  = "/data/adb/directpath/config/dpcore.conf";
    int         i, foreground = 0;
    pthread_t   t_relay, t_dns;
    int         dns_ok = 0;
    char        path[320];

    config_defaults();

    for (i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--config") && i + 1 < argc)        cfgpath = argv[++i];
        else if (!strcmp(argv[i], "--rollback") && i + 1 < argc)
            snprintf(g_rollback, sizeof(g_rollback), "%s", argv[++i]);
        else if (!strcmp(argv[i], "--foreground"))               foreground = 1;
        else if (!strcmp(argv[i], "--version")) { printf("%s\n", DP_VERSION); return 0; }
        else if (!strcmp(argv[i], "--check")) {
            /* --check IP PORT [--sni N] [--strategy S] [--timeout MS] */
            const char *ip = NULL, *sni = NULL;
            long        port = 0;
            int         tmo = 6000;
            dp_strategy st = DS_NONE;

            if (i + 2 >= argc) { usage(); return 2; }
            ip   = argv[++i];
            port = strtol(argv[++i], NULL, 10);
            if (port < 1 || port > 65535) { usage(); return 2; }
            for (++i; i < argc; i++) {
                if (!strcmp(argv[i], "--sni") && i + 1 < argc)           sni = argv[++i];
                else if (!strcmp(argv[i], "--strategy") && i + 1 < argc) st = dp_strategy_from_name(argv[++i]);
                else if (!strcmp(argv[i], "--timeout") && i + 1 < argc)  tmo = (int)strtol(argv[++i], NULL, 10);
                else { usage(); return 2; }
            }
            if (tmo < 500 || tmo > 30000) tmo = 6000;
            config_defaults();
            return dp_check_tcp(ip, (uint16_t)port, sni, st, tmo);
        }
        else if (!strcmp(argv[i], "--resolve")) {
            const char *name = NULL, *server = NULL;
            int use_tcp = 1, tmo = 4000;

            if (i + 1 >= argc) { usage(); return 2; }
            name = argv[++i];
            for (++i; i < argc; i++) {
                if (!strcmp(argv[i], "--server") && i + 1 < argc) server = argv[++i];
                else if (!strcmp(argv[i], "--udp"))               use_tcp = 0;
                else if (!strcmp(argv[i], "--tcp"))               use_tcp = 1;
                else if (!strcmp(argv[i], "--bogus") && i + 1 < argc) dp_dns_load_bogus(argv[++i]);
                else if (!strcmp(argv[i], "--timeout") && i + 1 < argc) tmo = (int)strtol(argv[++i], NULL, 10);
                else { usage(); return 2; }
            }
            if (!server) { usage(); return 2; }
            if (tmo < 500 || tmo > 30000) tmo = 4000;
            config_defaults();
            return dp_dns_probe(name, server, use_tcp, tmo);
        }
        else if (!strcmp(argv[i], "--probe")) {
            int caps;
            config_defaults();
            caps = dp_desync_probe();
            printf("version=%s\ncap_ttl=%d\ncap_tcp_repair=%d\ncap_oob=%d\n",
                   DP_VERSION, !!(caps & DP_CAP_TTL), !!(caps & DP_CAP_REPAIR),
                   !!(caps & DP_CAP_OOB));
            return 0;
        } else { usage(); return 2; }
    }

    if (dp_config_load(cfgpath) != 0) {
        fprintf(stderr, "dpcore: cannot read %s\n", cfgpath);
        return 3;
    }

    snprintf(g_pidfile,  sizeof(g_pidfile),  "%s/run/dpcore.pid",   g_cfg.rundir);
    snprintf(g_statfile, sizeof(g_statfile), "%s/run/dpcore.stats", g_cfg.rundir);

    if (!foreground) {
        pid_t p = fork();
        if (p < 0) return 4;
        if (p > 0) return 0;
        setsid();
        {   /* keep fd 0/1/2 valid so a stray printf cannot corrupt a socket */
            int nul = open("/dev/null", O_RDWR);
            if (nul >= 0) { dup2(nul, 0); dup2(nul, 1); dup2(nul, 2); if (nul > 2) close(nul); }
        }
    }

    umask(0077);
    dp_log_open(g_cfg.logfile, g_cfg.loglevel, g_cfg.logmax);
    g_stats.started_at = dp_now();
    LOGI("dpcore %s starting (config %s)", DP_VERSION, cfgpath);

    signal(SIGPIPE, SIG_IGN);
    signal(SIGTERM, on_term);
    signal(SIGINT,  on_term);
    signal(SIGHUP,  on_hup);
    signal(SIGSEGV, on_fatal);
    signal(SIGBUS,  on_fatal);
    signal(SIGABRT, on_fatal);
    signal(SIGILL,  on_fatal);
    signal(SIGFPE,  on_fatal);

    dp_desync_probe();

    snprintf(path, sizeof(path), "%s/bogus-ip.list", g_cfg.ruledir);
    dp_dns_load_bogus(path);

    {   /* enabled groups come from a one line file the shell layer owns */
        char groups[256] = "all";
        FILE *g;
        snprintf(path, sizeof(path), "%s/config/groups.active", g_cfg.rundir);
        g = fopen(path, "r");
        if (g) {
            if (fgets(groups, sizeof(groups), g)) dp_trim(groups);
            fclose(g);
        }
        dp_rules_load(g_cfg.ruledir, dp_trim(groups));
    }

    snprintf(path, sizeof(path), "%s/state/learn.tsv", g_cfg.rundir);
    dp_learn_load(path);

    if (g_cfg.proxy_enabled && dp_proxy_start() != 0) {
        LOGE("relay failed to start, exiting so the supervisor rolls back");
        run_rollback();
        return 5;
    }
    if (g_cfg.dns_enabled) dns_ok = (dp_dns_start() == 0);

    write_pidfile();

    if (g_cfg.proxy_enabled &&
        pthread_create(&t_relay, NULL, relay_thread, NULL) != 0) {
        LOGE("cannot spawn relay thread");
        run_rollback();
        return 6;
    }
    if (dns_ok && pthread_create(&t_dns, NULL, dns_thread, NULL) != 0) {
        LOGW("cannot spawn dns thread, continuing without the forwarder");
        dns_ok = 0;
    }

    /* Main thread does nothing but publish counters, once a minute. That
     * is one timer wakeup per minute for the whole daemon. */
    while (!g_stop) {
        int k;
        for (k = 0; k < 60 && !g_stop; k++) sleep(1);
        dp_stats_dump(g_statfile);
    }

    LOGI("dpcore stopping");
    dp_proxy_stop();
    if (dns_ok) dp_dns_stop();
    if (g_cfg.proxy_enabled) pthread_join(t_relay, NULL);
    if (dns_ok)              pthread_join(t_dns, NULL);
    dp_stats_dump(g_statfile);
    unlink(g_pidfile);
    dp_rules_free();
    LOGI("dpcore stopped");
    dp_log_close();
    return 0;
}
