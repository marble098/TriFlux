/* rules.c - destination groups plus the adaptive strategy ladder.
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * Groups live in plain one-domain-per-line text files, one file per
 * group, so the rule database can be shipped, edited and updated on its
 * own schedule without touching a line of shell or C.
 *
 * Matching is suffix based: a rule for "example.com" also covers
 * "cdn.example.com". Lookup walks at most one label at a time, so the
 * worst case is a handful of hash probes per connection.
 */

#define _GNU_SOURCE
#include "dpcore.h"

#include <ctype.h>
#include <strings.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ---- group table ---------------------------------------------------- */

#define RULE_BUCKETS 2048

typedef struct rule_node {
    struct rule_node *next;
    char             *domain;
    char              group[24];
} rule_node;

static rule_node *g_buckets[RULE_BUCKETS];
static int        g_rule_count;

static int group_enabled(const char *list, const char *name)
{
    const char *p = list;
    size_t      n = strlen(name);

    if (!list || !*list || strcmp(list, "all") == 0) return 1;
    while (*p) {
        const char *c = strchr(p, ',');
        size_t      l = c ? (size_t)(c - p) : strlen(p);
        if (l == n && strncmp(p, name, n) == 0) return 1;
        if (!c) break;
        p = c + 1;
    }
    return 0;
}

static void rule_add(const char *domain, const char *group)
{
    uint32_t   h = dp_hash(domain) % RULE_BUCKETS;
    rule_node *n;

    for (n = g_buckets[h]; n; n = n->next)
        if (strcmp(n->domain, domain) == 0) return;   /* already present */

    n = calloc(1, sizeof(*n));
    if (!n) return;
    n->domain = strdup(domain);
    if (!n->domain) { free(n); return; }
    snprintf(n->group, sizeof(n->group), "%s", group);
    n->next = g_buckets[h];
    g_buckets[h] = n;
    g_rule_count++;
}

static void load_one(const char *path, const char *group)
{
    FILE *f = fopen(path, "r");
    char  line[320];

    if (!f) return;
    while (fgets(line, sizeof(line), f)) {
        char *s = dp_trim(line);
        char *p;
        if (!*s || *s == '#' || *s == ';') continue;
        if (*s == '*' && s[1] == '.') s += 2;
        if (*s == '.') s++;
        for (p = s; *p; p++) *p = (char)tolower((unsigned char)*p);
        if (strlen(s) < 3 || strlen(s) > 253) continue;
        rule_add(s, group);
    }
    fclose(f);
}

int dp_rules_load(const char *dir, const char *enabled_groups)
{
    DIR           *d;
    struct dirent *e;

    dp_rules_free();
    d = opendir(dir);
    if (!d) {
        LOGW("rule directory %s unavailable, running with no domain rules", dir);
        return -1;
    }
    while ((e = readdir(d)) != NULL) {
        char  path[448], group[24];
        char *dot;
        size_t nl = strlen(e->d_name);

        if (nl < 6 || strcmp(e->d_name + nl - 5, ".list") != 0) continue;
        snprintf(group, sizeof(group), "%s", e->d_name);
        dot = strrchr(group, '.');
        if (dot) *dot = '\0';
        if (!group_enabled(enabled_groups, group)) continue;
        snprintf(path, sizeof(path), "%s/%s", dir, e->d_name);
        load_one(path, group);
    }
    closedir(d);
    LOGI("loaded %d destination rules from %s", g_rule_count, dir);
    return g_rule_count;
}

int dp_rules_match(const char *host, char *group, size_t glen)
{
    const char *p = host;

    if (!host || !*host) return 0;
    while (p && *p) {
        uint32_t   h = dp_hash(p) % RULE_BUCKETS;
        rule_node *n;
        for (n = g_buckets[h]; n; n = n->next) {
            if (strcasecmp(n->domain, p) == 0) {
                if (group && glen) snprintf(group, glen, "%s", n->group);
                return 1;
            }
        }
        p = strchr(p, '.');
        if (!p) break;
        p++;                       /* advance past the dot, one label up */
        if (!strchr(p, '.')) break; /* never match on a bare TLD          */
    }
    return 0;
}

void dp_rules_free(void)
{
    int i;
    for (i = 0; i < RULE_BUCKETS; i++) {
        rule_node *n = g_buckets[i];
        while (n) {
            rule_node *nx = n->next;
            free(n->domain);
            free(n);
            n = nx;
        }
        g_buckets[i] = NULL;
    }
    g_rule_count = 0;
}

/* ---- adaptive ladder ------------------------------------------------ */
/*
 * When a repaired handshake still dies, the destination is telling us the
 * current technique is not enough. Rather than pick a global "aggressive"
 * setting and pay its cost everywhere, we escalate per hostname and stop
 * as soon as something works. Two consecutive failures move one rung up;
 * a success freezes the rung. State survives restarts via a small TSV.
 */

static const dp_strategy g_ladder[] = {
    DS_SPLIT, DS_SPLIT_MULTI, DS_DISORDER, DS_FAKE, DS_OOB
};
#define LADDER_N ((int)(sizeof(g_ladder) / sizeof(g_ladder[0])))

typedef struct {
    char  host[DP_MAX_HOST];
    int   rung;
    int   fails;
    int   oks;
    long  seen;
} learn_ent;

static learn_ent g_learn[DP_LEARN_MAX];
static int       g_learn_n;
static int       g_learn_dirty;

static learn_ent *learn_find(const char *host, int create)
{
    int i, victim = -1;
    long oldest = 0;

    for (i = 0; i < g_learn_n; i++)
        if (strcasecmp(g_learn[i].host, host) == 0) return &g_learn[i];

    if (!create) return NULL;

    if (g_learn_n < DP_LEARN_MAX) {
        learn_ent *e = &g_learn[g_learn_n++];
        memset(e, 0, sizeof(*e));
        snprintf(e->host, sizeof(e->host), "%s", host);
        e->seen = dp_now();
        return e;
    }
    /* Table full: evict the least recently useful entry. */
    for (i = 0; i < g_learn_n; i++)
        if (victim < 0 || g_learn[i].seen < oldest) { victim = i; oldest = g_learn[i].seen; }
    memset(&g_learn[victim], 0, sizeof(learn_ent));
    snprintf(g_learn[victim].host, sizeof(g_learn[victim].host), "%s", host);
    g_learn[victim].seen = dp_now();
    return &g_learn[victim];
}

dp_strategy dp_learn_strategy(const char *host, dp_strategy base)
{
    learn_ent *e;
    if (!g_cfg.adaptive) return base;
    e = learn_find(host, 0);
    if (!e || e->rung <= 0) return base;
    if (e->rung >= LADDER_N) return g_ladder[LADDER_N - 1];
    return g_ladder[e->rung];
}

void dp_learn_report(const char *host, int success)
{
    learn_ent *e;

    if (!g_cfg.adaptive || !host || !*host) return;
    e = learn_find(host, 1);
    if (!e) return;
    e->seen = dp_now();

    if (success) {
        e->oks++;
        e->fails = 0;
    } else {
        e->fails++;
        if (e->fails >= 2 && e->rung < LADDER_N - 1) {
            e->rung++;
            e->fails = 0;
            LOGI("escalating %s to strategy %s", host,
                 dp_strategy_name(g_ladder[e->rung]));
        }
    }
    g_learn_dirty = 1;
}

int dp_learn_load(const char *path)
{
    FILE *f = fopen(path, "r");
    char  line[512];

    g_learn_n = 0;
    if (!f) return 0;
    while (fgets(line, sizeof(line), f) && g_learn_n < DP_LEARN_MAX) {
        learn_ent *e = &g_learn[g_learn_n];
        char       host[DP_MAX_HOST];
        int        rung = 0, fails = 0, oks = 0;
        long       seen = 0;

        if (sscanf(line, "%255s\t%d\t%d\t%d\t%ld", host, &rung, &fails, &oks,
                   &seen) < 2)
            continue;
        if (rung < 0 || rung >= LADDER_N) continue;
        memset(e, 0, sizeof(*e));
        snprintf(e->host, sizeof(e->host), "%s", host);
        e->rung = rung; e->fails = fails; e->oks = oks; e->seen = seen;
        g_learn_n++;
    }
    fclose(f);
    LOGD("restored %d learned destinations", g_learn_n);
    return g_learn_n;
}

int dp_learn_save(const char *path)
{
    char  *buf;
    size_t cap = (size_t)g_learn_n * 320 + 64, used = 0;
    int    i, rc;

    if (!g_learn_dirty) return 0;
    buf = malloc(cap);
    if (!buf) return -1;

    for (i = 0; i < g_learn_n; i++) {
        int n = snprintf(buf + used, cap - used, "%s\t%d\t%d\t%d\t%ld\n",
                         g_learn[i].host, g_learn[i].rung, g_learn[i].fails,
                         g_learn[i].oks, g_learn[i].seen);
        if (n < 0 || (size_t)n >= cap - used) break;
        used += (size_t)n;
    }
    rc = dp_write_atomic(path, buf, used);
    free(buf);
    if (rc == 0) g_learn_dirty = 0;
    return rc;
}
