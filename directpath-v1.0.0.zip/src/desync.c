/* desync.c - the actual mitigation techniques.
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * Everything here works on an ordinary connected TCP socket. There are no
 * raw sockets, no NFQUEUE, no kernel module and no packet forging. That is
 * a deliberate architectural constraint: it is the only way to get one
 * implementation that runs on the very wide range of Android kernels in
 * circulation, and it means a failure here can never wedge the network
 * stack itself.
 *
 * The techniques:
 *
 *   split         Write the first client chunk as two segments with the
 *                 boundary inside the hostname. A middlebox that matches
 *                 on a single segment never sees a complete name.
 *
 *   split-multi   Same idea with a 1 byte leading segment, which also
 *                 upsets reassemblers that assume a record starts at the
 *                 beginning of a segment.
 *
 *   disorder      Send the first segment with a TTL too small to reach the
 *                 server. The inspector, which is close to us, sees it; the
 *                 server does not. The kernel retransmits it normally a
 *                 moment later, so the server reassembles a correct stream.
 *                 Costs one retransmission timeout on the first packet.
 *
 *   fake          Send a synthetic ClientHello with a low TTL, then rewind
 *                 the socket's send sequence number with TCP_REPAIR so the
 *                 decoy never occupies stream space. The inspector has
 *                 already consumed a complete, boring handshake. Requires
 *                 CAP_NET_ADMIN and a kernel with TCP_REPAIR; probed at
 *                 startup and silently downgraded to split when absent.
 *
 *   oob           Place a byte of TCP urgent data at the boundary. The
 *                 receiver's stack discards it, some inspectors do not.
 *
 * None of these inspect, store or alter the application's own bytes. The
 * payload written to the server is byte-for-byte what the app produced.
 */

#define _GNU_SOURCE
#include "dpcore.h"

#include <errno.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <poll.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

static int g_caps = -1;

/* ---- primitives ----------------------------------------------------- */

static void nap(int usec)
{
    struct timespec ts;
    if (usec <= 0) return;
    ts.tv_sec  = usec / 1000000;
    ts.tv_nsec = (long)(usec % 1000000) * 1000L;
    nanosleep(&ts, NULL);
}

/* The proxy hands us a non-blocking socket. Right after connect() the send
 * buffer is empty, so this almost never blocks, but we still bound the
 * wait so one wedged peer cannot stall the event loop forever. */
static int full_write(int fd, const uint8_t *p, size_t n, int flags)
{
    long deadline = dp_now() + 5;

    while (n > 0) {
        ssize_t w = send(fd, p, n, flags | MSG_NOSIGNAL);
        if (w > 0) { p += w; n -= (size_t)w; continue; }
        if (w < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) {
            struct pollfd pfd = { fd, POLLOUT, 0 };
            if (dp_now() > deadline) return -1;
            if (poll(&pfd, 1, 1000) < 0 && errno != EINTR) return -1;
            continue;
        }
        if (w < 0 && errno == EINTR) continue;
        return -1;
    }
    return 0;
}

static int get_ttl(int fd, int family)
{
    int       v = 0;
    socklen_t l = sizeof(v);

    if (family == AF_INET6 &&
        getsockopt(fd, IPPROTO_IPV6, IPV6_UNICAST_HOPS, &v, &l) == 0 && v > 0)
        return v;
    l = sizeof(v);
    if (getsockopt(fd, IPPROTO_IP, IP_TTL, &v, &l) == 0 && v > 0)
        return v;
    return 64;
}

/* Set on both levels: a dual-stack socket carrying a v4-mapped peer needs
 * IP_TTL, a native v6 peer needs IPV6_UNICAST_HOPS, and we cannot always
 * tell which one applies without extra syscalls. Failures are ignored. */
static int set_ttl(int fd, int family, int ttl)
{
    int ok = 0;
    if (setsockopt(fd, IPPROTO_IP, IP_TTL, &ttl, sizeof(ttl)) == 0) ok = 1;
    if (family == AF_INET6 &&
        setsockopt(fd, IPPROTO_IPV6, IPV6_UNICAST_HOPS, &ttl, sizeof(ttl)) == 0)
        ok = 1;
    return ok ? 0 : -1;
}

static int seq_save(int fd, uint32_t *seq)
{
    int       on = 1, off = 0, q = DP_TCP_SEND_QUEUE;
    socklen_t l = sizeof(*seq);

    if (setsockopt(fd, IPPROTO_TCP, DP_TCP_REPAIR, &on, sizeof(on)) != 0)
        return -1;
    if (setsockopt(fd, IPPROTO_TCP, DP_TCP_REPAIR_QUEUE, &q, sizeof(q)) != 0 ||
        getsockopt(fd, IPPROTO_TCP, DP_TCP_QUEUE_SEQ, seq, &l) != 0) {
        setsockopt(fd, IPPROTO_TCP, DP_TCP_REPAIR, &off, sizeof(off));
        return -1;
    }
    setsockopt(fd, IPPROTO_TCP, DP_TCP_REPAIR, &off, sizeof(off));
    return 0;
}

/* Rewinding the send sequence while in repair mode discards the queued
 * decoy, so leaving repair mode leaves a socket that never sent it. */
static int seq_restore(int fd, uint32_t seq)
{
    int on = 1, off = 0, q = DP_TCP_SEND_QUEUE, rc = 0;

    if (setsockopt(fd, IPPROTO_TCP, DP_TCP_REPAIR, &on, sizeof(on)) != 0)
        return -1;
    if (setsockopt(fd, IPPROTO_TCP, DP_TCP_REPAIR_QUEUE, &q, sizeof(q)) != 0 ||
        setsockopt(fd, IPPROTO_TCP, DP_TCP_QUEUE_SEQ, &seq, sizeof(seq)) != 0)
        rc = -1;
    setsockopt(fd, IPPROTO_TCP, DP_TCP_REPAIR, &off, sizeof(off));
    return rc;
}

/* ---- capability probe ----------------------------------------------- */

int dp_desync_probe(void)
{
    int fd, caps = 0, on = 1, off = 0, ttl = 3;

    if (g_caps >= 0) return g_caps;

    fd = socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, IPPROTO_TCP);
    if (fd < 0) { g_caps = 0; return 0; }

    if (setsockopt(fd, IPPROTO_IP, IP_TTL, &ttl, sizeof(ttl)) == 0)
        caps |= DP_CAP_TTL;
    if (setsockopt(fd, IPPROTO_TCP, DP_TCP_REPAIR, &on, sizeof(on)) == 0) {
        caps |= DP_CAP_REPAIR;
        setsockopt(fd, IPPROTO_TCP, DP_TCP_REPAIR, &off, sizeof(off));
    }
    /* MSG_OOB needs no capability, only a peer that tolerates it. */
    caps |= DP_CAP_OOB;

    close(fd);
    g_caps = caps;
    LOGI("desync capabilities: ttl=%d repair=%d oob=%d",
         !!(caps & DP_CAP_TTL), !!(caps & DP_CAP_REPAIR), !!(caps & DP_CAP_OOB));
    return caps;
}

/* ---- decoy construction --------------------------------------------- */
/*
 * A minimal but structurally valid TLS 1.2 ClientHello. Used both as the
 * decoy for the fake strategy and as the payload of the diagnostic probe,
 * so the probe exercises the same code path real traffic does. Built at run
 * time: we ship no opaque blob.
 */
size_t dp_build_client_hello(uint8_t *out, size_t cap, const char *host)
{
    size_t hl = strlen(host);
    size_t body, total, i, p = 0;
    size_t ext_len, sni_ext, hs_len;

    sni_ext = 2 + 1 + 2 + hl;            /* list_len + type + len + name  */
    ext_len = 4 + sni_ext;               /* ext header + ext body         */
    body    = 2 + 32 + 1 + 2 + 2 + 2 + 2 + ext_len;
    hs_len  = body;
    total   = 5 + 4 + body;
    if (total > cap || hl == 0 || hl > 200) return 0;

    out[p++] = 0x16; out[p++] = 0x03; out[p++] = 0x01;
    out[p++] = (uint8_t)(((4 + body) >> 8) & 0xff);
    out[p++] = (uint8_t)((4 + body) & 0xff);

    out[p++] = 0x01;                                     /* ClientHello   */
    out[p++] = (uint8_t)((hs_len >> 16) & 0xff);
    out[p++] = (uint8_t)((hs_len >> 8) & 0xff);
    out[p++] = (uint8_t)(hs_len & 0xff);

    out[p++] = 0x03; out[p++] = 0x03;                    /* TLS 1.2       */
    for (i = 0; i < 32; i++) out[p++] = (uint8_t)(0xA5 ^ (i * 7 + 13));
    out[p++] = 0x00;                                     /* session id    */
    out[p++] = 0x00; out[p++] = 0x02;                    /* cipher len    */
    out[p++] = 0x13; out[p++] = 0x01;                    /* TLS_AES_128   */
    out[p++] = 0x01; out[p++] = 0x00;                    /* compression   */

    out[p++] = (uint8_t)((ext_len >> 8) & 0xff);
    out[p++] = (uint8_t)(ext_len & 0xff);
    out[p++] = 0x00; out[p++] = 0x00;                    /* server_name   */
    out[p++] = (uint8_t)((sni_ext >> 8) & 0xff);
    out[p++] = (uint8_t)(sni_ext & 0xff);
    out[p++] = (uint8_t)(((1 + 2 + hl) >> 8) & 0xff);
    out[p++] = (uint8_t)((1 + 2 + hl) & 0xff);
    out[p++] = 0x00;                                     /* host_name     */
    out[p++] = (uint8_t)((hl >> 8) & 0xff);
    out[p++] = (uint8_t)(hl & 0xff);
    memcpy(out + p, host, hl);
    p += hl;

    return p;
}

/* ---- the entry point ------------------------------------------------ */

int dp_desync_send(int fd, int family, const uint8_t *buf, size_t len,
                   size_t split_at, dp_strategy st)
{
    int caps = dp_desync_probe();
    int delay = g_cfg.split_delay_us;
    int ttl_save;

    if (len == 0) return 0;

    /* Clamp the boundary into a sane interior position. */
    if (split_at == 0 || split_at >= len)
        split_at = (size_t)g_cfg.split_pos;
    if (split_at == 0 || split_at >= len)
        split_at = len / 2;
    if (split_at == 0) split_at = 1;

    /* Downgrade anything the kernel refused at startup. */
    if ((st == DS_DISORDER || st == DS_FAKE) && !(caps & DP_CAP_TTL))
        st = DS_SPLIT;
    if (st == DS_FAKE && !(caps & DP_CAP_REPAIR))
        st = DS_DISORDER;

    switch (st) {
    case DS_NONE:
        return full_write(fd, buf, len, 0);

    case DS_SPLIT:
        if (full_write(fd, buf, split_at, 0) != 0) return -1;
        nap(delay);
        return full_write(fd, buf + split_at, len - split_at, 0);

    case DS_SPLIT_MULTI:
        if (full_write(fd, buf, 1, 0) != 0) return -1;
        nap(delay);
        if (split_at > 1) {
            if (full_write(fd, buf + 1, split_at - 1, 0) != 0) return -1;
            nap(delay);
        }
        return full_write(fd, buf + split_at, len - split_at, 0);

    case DS_OOB:
        if (full_write(fd, buf, split_at, 0) != 0) return -1;
        {
            static const uint8_t oob = 0x21;
            (void)send(fd, &oob, 1, MSG_OOB | MSG_NOSIGNAL);
        }
        nap(delay);
        return full_write(fd, buf + split_at, len - split_at, 0);

    case DS_DISORDER:
        ttl_save = get_ttl(fd, family);
        set_ttl(fd, family, g_cfg.fake_ttl);
        if (full_write(fd, buf, split_at, 0) != 0) {
            set_ttl(fd, family, ttl_save);
            return -1;
        }
        set_ttl(fd, family, ttl_save);
        nap(delay);
        return full_write(fd, buf + split_at, len - split_at, 0);

    case DS_FAKE: {
        uint8_t  fake[512];
        size_t   flen;
        uint32_t seq = 0;
        int      have_seq;

        flen = dp_build_client_hello(fake, sizeof(fake), "www.iana.org");
        if (flen == 0) goto plain_split;

        have_seq = (seq_save(fd, &seq) == 0);
        if (!have_seq) goto plain_split;

        ttl_save = get_ttl(fd, family);
        set_ttl(fd, family, g_cfg.fake_ttl);
        (void)full_write(fd, fake, flen, 0);
        set_ttl(fd, family, ttl_save);

        if (seq_restore(fd, seq) != 0) {
            /* The decoy is now stuck in the stream and the server would
             * see it. Tear the connection down rather than corrupt it. */
            LOGW("TCP_REPAIR rewind failed, dropping connection");
            return -1;
        }
        nap(delay);
    plain_split:
        if (full_write(fd, buf, split_at, 0) != 0) return -1;
        nap(delay);
        return full_write(fd, buf + split_at, len - split_at, 0);
    }

    default:
        return full_write(fd, buf, len, 0);
    }
}

/* ---- name mapping --------------------------------------------------- */

dp_strategy dp_strategy_from_name(const char *s)
{
    if (!s) return DS_SPLIT;
    if (!strcmp(s, "none"))        return DS_NONE;
    if (!strcmp(s, "split"))       return DS_SPLIT;
    if (!strcmp(s, "split-multi")) return DS_SPLIT_MULTI;
    if (!strcmp(s, "disorder"))    return DS_DISORDER;
    if (!strcmp(s, "fake"))        return DS_FAKE;
    if (!strcmp(s, "oob"))         return DS_OOB;
    return DS_SPLIT;
}

const char *dp_strategy_name(dp_strategy s)
{
    switch (s) {
    case DS_NONE:        return "none";
    case DS_SPLIT:       return "split";
    case DS_SPLIT_MULTI: return "split-multi";
    case DS_DISORDER:    return "disorder";
    case DS_FAKE:        return "fake";
    case DS_OOB:         return "oob";
    default:             return "split";
    }
}
