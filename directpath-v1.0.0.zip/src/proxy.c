/* proxy.c - the transparent TCP relay.
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * Connections arrive here because the firewall layer rewrote their
 * destination to 127.0.0.1. SO_ORIGINAL_DST gives us back where the app
 * actually wanted to go, so the relay is fully transparent: the app sees
 * its own destination, the server sees the app's own bytes.
 *
 * Per connection the flow is:
 *   accept -> read the first client chunk -> read the plaintext name from
 *   it -> decide a policy -> connect to the real destination -> emit that
 *   first chunk using the chosen technique -> pure byte relay from there.
 *
 * A connection whose destination matches no rule is relayed untouched.
 * That is the expensive-looking case, but the cost is one extra loopback
 * hop with no inspection and no buffering beyond 8 KiB, which is far
 * cheaper than maintaining kernel IP sets for thousands of CDN addresses.
 */

#define _GNU_SOURCE
#include "dpcore.h"

#include <errno.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/epoll.h>
#include <sys/socket.h>
#include <unistd.h>

enum { ST_HEAD = 0, ST_CONNECT, ST_RELAY, ST_DEAD };

typedef struct {
    int      used;
    int      state;
    int      cfd, sfd;
    int      cev, sev;              /* currently registered epoll masks   */
    int      family;

    uint8_t *head;                  /* first client chunk, handshake only */
    size_t   head_len;
    size_t   split_at;

    uint8_t *c2s, *s2c;
    size_t   c2s_len, c2s_off;
    size_t   s2c_len, s2c_off;

    int      c_eof, s_eof;
    unsigned long s2c_total;

    dp_strategy st;
    int      repaired;
    char     host[DP_MAX_HOST];
    char     group[24];
    struct sockaddr_storage dst;
    socklen_t dstlen;
    long     born, active;
} conn;

static conn  g_conn[DP_MAX_CONNS];
static int   g_ep = -1;
static int   g_l4 = -1, g_l6 = -1;

/* ---- epoll bookkeeping ---------------------------------------------- */

static void ep_set(int fd, int *cur, int want, void *ptr)
{
    struct epoll_event ev;
    if (fd < 0 || *cur == want) return;
    memset(&ev, 0, sizeof(ev));
    ev.events   = (uint32_t)want;
    ev.data.ptr = ptr;
    if (epoll_ctl(g_ep, *cur == -1 ? EPOLL_CTL_ADD : EPOLL_CTL_MOD, fd, &ev) == 0)
        *cur = want;
}

static void ep_del(int fd, int *cur)
{
    if (fd >= 0 && *cur != -1) epoll_ctl(g_ep, EPOLL_CTL_DEL, fd, NULL);
    *cur = -1;
}

static conn *conn_alloc(void)
{
    int i;
    for (i = 0; i < DP_MAX_CONNS; i++)
        if (!g_conn[i].used) {
            memset(&g_conn[i], 0, sizeof(conn));
            g_conn[i].used = 1;
            g_conn[i].cfd  = g_conn[i].sfd = -1;
            g_conn[i].cev  = g_conn[i].sev = -1;
            g_conn[i].born = g_conn[i].active = dp_now();
            g_stats.conn_active++;
            g_stats.conn_total++;
            return &g_conn[i];
        }
    return NULL;
}

static void conn_close(conn *c)
{
    if (!c->used) return;

    /* Feed the outcome back into the ladder before we forget the host. */
    if (c->repaired && c->host[0])
        dp_learn_report(c->host, c->s2c_total > 0);
    if (c->repaired && c->s2c_total == 0) g_stats.conn_failed++;

    ep_del(c->cfd, &c->cev);
    ep_del(c->sfd, &c->sev);
    if (c->cfd >= 0) close(c->cfd);
    if (c->sfd >= 0) close(c->sfd);
    free(c->head); free(c->c2s); free(c->s2c);
    memset(c, 0, sizeof(*c));
    c->cfd = c->sfd = -1;
    if (g_stats.conn_active) g_stats.conn_active--;
}

/* ---- policy --------------------------------------------------------- */
/*
 * Decide what to do with a connection now that we can see its first chunk.
 * Returns the strategy; fills c->host, c->group and c->split_at.
 */
static dp_strategy decide(conn *c, uint16_t dport)
{
    size_t off = 0;
    int    named = 0;

    if (dp_tls_peek_sni(c->head, c->head_len, c->host, sizeof(c->host), &off))
        named = 1;
    else if (dport == 80 &&
             dp_http_peek_host(c->head, c->head_len, c->host, sizeof(c->host), &off))
        named = 1;

    if (named) {
        /* Aim the boundary at the middle of the name so neither segment
         * carries a matchable copy of it. */
        size_t hl = strlen(c->host);
        c->split_at = off + (hl > 3 ? hl / 2 : 1);
        if (c->split_at >= c->head_len) c->split_at = c->head_len / 2;
    } else {
        c->split_at = (size_t)g_cfg.split_pos;
    }

    if (named && dp_rules_match(c->host, c->group, sizeof(c->group)))
        return dp_learn_strategy(c->host, g_cfg.strategy);

    if (g_cfg.scope_all) {
        snprintf(c->group, sizeof(c->group), "%s", "all");
        return named ? dp_learn_strategy(c->host, g_cfg.strategy) : g_cfg.strategy;
    }
    return DS_NONE;
}

/* ---- upstream connect ------------------------------------------------ */

static int upstream_open(conn *c)
{
    int fd, on = 1, mark = 0;
    socklen_t ml = sizeof(mark);

    fd = socket(c->dst.ss_family, SOCK_STREAM | SOCK_CLOEXEC | SOCK_NONBLOCK,
                IPPROTO_TCP);
    if (fd < 0) return -1;

    setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &on, sizeof(on));

    /* Android selects the outgoing network with an fwmark on the app's
     * socket. When the accepted socket carries that mark we copy it, so a
     * connection from an app bound to Wi-Fi does not silently leave over
     * mobile data. Best effort: many kernels return 0 here. */
    if (getsockopt(c->cfd, SOL_SOCKET, SO_MARK, &mark, &ml) == 0 && mark != 0)
        setsockopt(fd, SOL_SOCKET, SO_MARK, &mark, sizeof(mark));

    if (connect(fd, (struct sockaddr *)&c->dst, c->dstlen) != 0 &&
        errno != EINPROGRESS) {
        close(fd);
        return -1;
    }
    c->sfd = fd;
    return 0;
}

/* ---- relay ----------------------------------------------------------- */

static void want_events(conn *c)
{
    int cw = 0, sw = 0;

    if (c->state == ST_HEAD) {
        ep_set(c->cfd, &c->cev, EPOLLIN | EPOLLRDHUP, c);
        return;
    }
    if (c->state == ST_CONNECT) {
        ep_set(c->sfd, &c->sev, EPOLLOUT, c);
        ep_set(c->cfd, &c->cev, 0, c);
        return;
    }
    if (!c->c_eof && c->c2s_len < DP_RELAY_BUF) cw |= EPOLLIN | EPOLLRDHUP;
    if (c->s2c_len > c->s2c_off)               cw |= EPOLLOUT;
    if (!c->s_eof && c->s2c_len < DP_RELAY_BUF) sw |= EPOLLIN | EPOLLRDHUP;
    if (c->c2s_len > c->c2s_off)               sw |= EPOLLOUT;

    ep_set(c->cfd, &c->cev, cw, c);
    ep_set(c->sfd, &c->sev, sw, c);
}

static int pump_read(int fd, uint8_t *buf, size_t *len, int *eof)
{
    ssize_t n = recv(fd, buf + *len, DP_RELAY_BUF - *len, 0);
    if (n > 0) { *len += (size_t)n; return 1; }
    if (n == 0) { *eof = 1; return 0; }
    if (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR) return 0;
    if (errno == ECONNRESET) g_stats.reset_seen++;
    *eof = 1;
    return -1;
}

static int pump_write(int fd, uint8_t *buf, size_t *len, size_t *off)
{
    while (*off < *len) {
        ssize_t n = send(fd, buf + *off, *len - *off, MSG_NOSIGNAL);
        if (n > 0) { *off += (size_t)n; continue; }
        if (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)) return 0;
        if (n < 0 && errno == EINTR) continue;
        if (n < 0 && errno == ECONNRESET) g_stats.reset_seen++;
        return -1;
    }
    *off = *len = 0;
    return 0;
}

/* ---- state transitions ----------------------------------------------- */

static int enter_relay(conn *c)
{
    c->c2s = malloc(DP_RELAY_BUF);
    c->s2c = malloc(DP_RELAY_BUF);
    if (!c->c2s || !c->s2c) return -1;
    c->state = ST_RELAY;
    free(c->head);
    c->head = NULL;
    c->head_len = 0;
    want_events(c);
    return 0;
}

static int on_connected(conn *c)
{
    int       err = 0;
    socklen_t el = sizeof(err);

    if (getsockopt(c->sfd, SOL_SOCKET, SO_ERROR, &err, &el) != 0 || err != 0) {
        LOGD("connect failed for %s (%d)", c->host[0] ? c->host : "-", err);
        return -1;
    }
    if (dp_desync_send(c->sfd, c->family, c->head, c->head_len, c->split_at,
                       c->st) != 0)
        return -1;

    if (c->st != DS_NONE) {
        c->repaired = 1;
        g_stats.conn_repaired++;
        LOGD("repair %s via %s [%s]", c->host[0] ? c->host : "-",
             dp_strategy_name(c->st), c->group[0] ? c->group : "-");
    } else {
        g_stats.conn_passthrough++;
    }
    return enter_relay(c);
}

static int on_head(conn *c)
{
    ssize_t  n;
    uint16_t dport = 0;

    n = recv(c->cfd, c->head + c->head_len, DP_HEAD_BUF - c->head_len, 0);
    if (n <= 0) {
        if (n < 0 && (errno == EAGAIN || errno == EINTR)) return 0;
        return -1;
    }
    c->head_len += (size_t)n;
    c->active = dp_now();

    /* Wait for a complete TLS record header before deciding, but never
     * past the buffer: some protocols simply never send a name. */
    if (c->head_len < 64 && c->head_len < DP_HEAD_BUF && c->head[0] == 0x16) {
        size_t want = 5 + ((size_t)c->head[3] << 8 | c->head[4]);
        if (c->head_len < want && c->head_len < DP_HEAD_BUF) return 0;
    }

    dport = (c->dst.ss_family == AF_INET)
              ? ntohs(((struct sockaddr_in *)&c->dst)->sin_port)
              : ntohs(((struct sockaddr_in6 *)&c->dst)->sin6_port);

    c->st = decide(c, dport);
    if (upstream_open(c) != 0) return -1;
    c->state = ST_CONNECT;
    want_events(c);
    return 0;
}

static void on_accept(int lfd)
{
    for (;;) {
        struct sockaddr_storage peer;
        socklen_t plen = sizeof(peer);
        conn     *c;
        int       fd, on = 1, rc;

        fd = accept4(lfd, (struct sockaddr *)&peer, &plen,
                     SOCK_NONBLOCK | SOCK_CLOEXEC);
        if (fd < 0) return;

        c = conn_alloc();
        if (!c) { close(fd); LOGW("connection table full, refusing"); continue; }

        c->cfd = fd;
        rc = dp_orig_dst(fd, &c->dst, &c->dstlen);
        if (rc != 0 || dp_addr_is_private(&c->dst)) {
            /* Either nothing redirected this, or it is going somewhere we
             * promised never to touch. Both mean: not ours. */
            conn_close(c);
            continue;
        }
        c->family = c->dst.ss_family;
        setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &on, sizeof(on));

        c->head = malloc(DP_HEAD_BUF);
        if (!c->head) { conn_close(c); continue; }
        c->state = ST_HEAD;
        want_events(c);
    }
}

/* ---- listeners ------------------------------------------------------- */

static int listen_on(int family)
{
    struct sockaddr_storage ss;
    socklen_t sl;
    int fd, on = 1;

    if (dp_sa_from_str(family == AF_INET ? "127.0.0.1" : "::1",
                       g_cfg.proxy_port, &ss, &sl) != 0)
        return -1;

    fd = socket(family, SOCK_STREAM | SOCK_CLOEXEC | SOCK_NONBLOCK, IPPROTO_TCP);
    if (fd < 0) return -1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));
    if (family == AF_INET6)
        setsockopt(fd, IPPROTO_IPV6, IPV6_V6ONLY, &on, sizeof(on));

    if (bind(fd, (struct sockaddr *)&ss, sl) != 0 || listen(fd, 128) != 0) {
        LOGE("cannot listen on %s:%u (%s)",
             family == AF_INET ? "127.0.0.1" : "[::1]", g_cfg.proxy_port,
             strerror(errno));
        close(fd);
        return -1;
    }
    return fd;
}

int dp_proxy_start(void)
{
    struct epoll_event ev;

    g_ep = epoll_create1(EPOLL_CLOEXEC);
    if (g_ep < 0) { LOGE("epoll_create1: %s", strerror(errno)); return -1; }

    g_l4 = listen_on(AF_INET);
    if (g_l4 < 0) return -1;            /* v4 is mandatory */
    g_l6 = listen_on(AF_INET6);         /* v6 is optional  */

    memset(&ev, 0, sizeof(ev));
    ev.events   = EPOLLIN;
    ev.data.ptr = &g_l4;
    epoll_ctl(g_ep, EPOLL_CTL_ADD, g_l4, &ev);
    if (g_l6 >= 0) {
        ev.data.ptr = &g_l6;
        epoll_ctl(g_ep, EPOLL_CTL_ADD, g_l6, &ev);
    }
    LOGI("relay listening on 127.0.0.1:%u%s", g_cfg.proxy_port,
         g_l6 >= 0 ? " and [::1]" : " (IPv6 listener unavailable)");
    return 0;
}

/* Drop connections that stalled, so a hung peer cannot pin a slot. */
static void sweep(void)
{
    long now = dp_now();
    int  i;

    for (i = 0; i < DP_MAX_CONNS; i++) {
        conn *c = &g_conn[i];
        if (!c->used) continue;
        if (c->state == ST_HEAD || c->state == ST_CONNECT) {
            if (now - c->born > DP_HANDSHAKE_TMO) conn_close(c);
        } else if (now - c->active > DP_IDLE_TMO) {
            conn_close(c);
        }
    }
}

void dp_proxy_run(void)
{
    struct epoll_event evs[64];
    long last_sweep = dp_now(), last_save = dp_now();
    char learn_path[288];

    snprintf(learn_path, sizeof(learn_path), "%s/state/learn.tsv", g_cfg.rundir);

    while (!g_stop) {
        int timeout = g_stats.conn_active ? 5000 : 30000;
        int n = epoll_wait(g_ep, evs, 64, timeout);
        int i;

        if (n < 0) {
            if (errno == EINTR) continue;
            LOGE("epoll_wait: %s", strerror(errno));
            break;
        }

        for (i = 0; i < n; i++) {
            void *p = evs[i].data.ptr;
            conn *c;

            if (p == &g_l4) { on_accept(g_l4); continue; }
            if (p == &g_l6) { on_accept(g_l6); continue; }

            c = (conn *)p;
            if (!c->used) continue;
            c->active = dp_now();

            if (c->state == ST_HEAD) {
                if (on_head(c) != 0 || (evs[i].events & (EPOLLERR | EPOLLHUP)))
                    if (c->state == ST_HEAD) { conn_close(c); continue; }
                continue;
            }
            if (c->state == ST_CONNECT) {
                if (evs[i].events & (EPOLLERR | EPOLLHUP)) { conn_close(c); continue; }
                if (on_connected(c) != 0) { conn_close(c); continue; }
                continue;
            }

            /* ST_RELAY */
            {
                int dead = 0;
                uint32_t e = evs[i].events;
                int is_client = 0;

                /* One epoll entry per fd, both point at the same conn, so
                 * work out which side fired by testing readiness. */
                is_client = 0;
                if (e & (EPOLLIN | EPOLLERR | EPOLLHUP | EPOLLRDHUP | EPOLLOUT)) {
                    /* Try both sides; harmless when a side is not ready. */
                    if (!c->c_eof && c->c2s_len < DP_RELAY_BUF) {
                        int r = pump_read(c->cfd, c->c2s, &c->c2s_len, &c->c_eof);
                        if (r < 0) dead = 1;
                    }
                    if (!c->s_eof && c->s2c_len < DP_RELAY_BUF) {
                        size_t before = c->s2c_len;
                        int r = pump_read(c->sfd, c->s2c, &c->s2c_len, &c->s_eof);
                        if (r < 0 && c->s2c_len == before && c->s2c_total == 0)
                            dead = 1;
                        c->s2c_total += c->s2c_len - before;
                    }
                    if (c->c2s_len > c->c2s_off &&
                        pump_write(c->sfd, c->c2s, &c->c2s_len, &c->c2s_off) < 0)
                        dead = 1;
                    if (c->s2c_len > c->s2c_off &&
                        pump_write(c->cfd, c->s2c, &c->s2c_len, &c->s2c_off) < 0)
                        dead = 1;
                }
                (void)is_client;

                if (c->c_eof && c->c2s_len == c->c2s_off) shutdown(c->sfd, SHUT_WR);
                if (c->s_eof && c->s2c_len == c->s2c_off) shutdown(c->cfd, SHUT_WR);
                if (dead || (c->c_eof && c->s_eof &&
                             c->c2s_len == c->c2s_off && c->s2c_len == c->s2c_off)) {
                    conn_close(c);
                    continue;
                }
                want_events(c);
            }
        }

        if (dp_now() - last_sweep >= 5)  { sweep(); last_sweep = dp_now(); }
        if (dp_now() - last_save  >= 60) { dp_learn_save(learn_path); last_save = dp_now(); }
    }

    dp_learn_save(learn_path);
}

void dp_proxy_stop(void)
{
    int i;
    for (i = 0; i < DP_MAX_CONNS; i++)
        if (g_conn[i].used) conn_close(&g_conn[i]);
    if (g_l4 >= 0) { close(g_l4); g_l4 = -1; }
    if (g_l6 >= 0) { close(g_l6); g_l6 = -1; }
    if (g_ep >= 0) { close(g_ep); g_ep = -1; }
}
