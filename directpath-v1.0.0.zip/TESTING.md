# Testing checklist

Every scenario below has a defined expected result. A release is not
finished until all of them pass on at least one arm64 device running a
current Android version, and the boot-safety group (1–6) passes on every
device you can get hold of.

Throughout: **"stock networking"** means the device behaves exactly as it did
before installation — no `DP_*` chains present, no `dpcore` process running.

Verify that state with:

```sh
su -c 'iptables-save -t nat | grep DP_ ; iptables-save -t filter | grep DP_ ; pgrep -f dpcore'
```

Three empty results is a pass.

---

## 1. Installation and boot

| # | Scenario | Steps | Expected |
|---|---|---|---|
| 1.1 | Clean install | Flash the zip on a device with no previous version | Installer prints architecture, API level and capability report. No errors. |
| 1.2 | First boot | Reboot after 1.1 | Device boots normally. State is **Off**. Nothing redirected. `boot_count` is 0. |
| 1.3 | First enable | Turn the switch on | State reaches **Working** within ~15s. `DP_NAT_OUT` present. |
| 1.4 | Reboot while enabled | Reboot | Boots normally. After the start delay plus ~60s, state is **Working** and `boot_count` is 0. |
| 1.5 | Ten consecutive reboots | Reboot ten times, enabled | Every boot completes. `boot_count` returns to 0 each time. No cumulative state. |
| 1.6 | Update install | Flash the zip over an existing install | Settings and app selection preserved. Rule lists refreshed. `backup/directpath.conf.preupdate` exists. |
| 1.7 | Install on API < 29 | Flash on Android 9 | Installer aborts with a clear message. Nothing written. |
| 1.8 | Install on unsupported arch | Flash a zip missing the matching binary | Installer aborts with a clear message. Nothing written. |
| 1.9 | Module disabled in manager | Toggle the module off in KernelSU, reboot | Nothing starts. Stock networking. No log noise. |

## 2. Boot safety (the critical group)

| # | Scenario | Steps | Expected |
|---|---|---|---|
| 2.1 | Simulated bootloop | `rm /data/adb/directpath/state/boot_count`, then reboot three times, killing the device during boot each time | On the third boot `state/auto_disabled` exists, nothing is applied, device boots to a usable state. |
| 2.2 | Missing binary | `mv bin/dpcore bin/dpcore.bak`, reboot | State **Not running**. No rules applied. Stock networking. Log names the cause. |
| 2.3 | Corrupt config | Write garbage into `config/directpath.conf`, reboot | Every invalid value falls back to its default. Module starts normally. |
| 2.4 | Truncated config | `: > config/directpath.conf`, reboot | Defaults used throughout. Module starts. |
| 2.5 | Port already in use | Bind 9451 with another process, restart | Daemon fails to listen, **no rules are applied**, state **Not running**. |
| 2.6 | Daemon killed | `kill -9 $(cat run/dpcore.pid)` | Within one supervisor tick: rules removed **first**, then restart attempted. State briefly **Recovering**, then **Working**. |
| 2.7 | Daemon killed repeatedly | Kill it three times in quick succession | After the third, `state/auto_disabled` exists, rules removed, state **Switched off**. |
| 2.8 | Hard crash rollback | `kill -SEGV $(cat run/dpcore.pid)` | Rules are removed by the daemon's own signal handler, before the supervisor tick. |
| 2.9 | Supervisor killed | `kill $(cat run/watchdog.pid)` | Next engine action respawns it. Rules remain valid meanwhile. |
| 2.10 | Low memory kill | Force-kill both processes under memory pressure | Rules removed, no dead-socket redirection persists. |

## 3. Networking states

| # | Scenario | Steps | Expected |
|---|---|---|---|
| 3.1 | Airplane mode on | Enable airplane mode while running | No crash. Health may degrade. No rules left pointing at a dead daemon. |
| 3.2 | Airplane mode off | Disable it | Network signature change detected, rules reapplied within one tick. |
| 3.3 | Wi-Fi to mobile | Switch networks | Rules reapplied. Repaired sites still work. |
| 3.4 | Mobile to Wi-Fi | Switch back | Same. |
| 3.5 | Rapid transitions | Toggle Wi-Fi ten times quickly | No duplicate chains, no duplicate jump rules, single supervisor process. |
| 3.6 | IPv4-only network | Connect to one | Works. Diagnostics reports IPv6 unavailable, not an error. |
| 3.7 | IPv6-only network | Connect to one | Either mirrored via NAT6, or clearly reported as unsupported. No silent bypass. |
| 3.8 | Dual stack | Connect to one | Both families behave consistently with the configured IPv6 mode. |
| 3.9 | No internet at all | Connect to an AP with no upstream | No crash, no hang. Diagnostics reports `unavailable`, not `blocked`. |
| 3.10 | Captive portal | Join a hotel or café network | State **Standing by**. Sign-in page loads. After sign-in, module resumes. |
| 3.11 | Tethering active | Enable a hotspot | Tethered clients are unaffected. Phone's own traffic still repaired. |

## 4. DNS

| # | Scenario | Steps | Expected |
|---|---|---|---|
| 4.1 | Forwarder active | Default settings, no Private DNS | UDP 53 redirected, names resolve, `dns_queries` increments. |
| 4.2 | Private DNS set by user | Turn on Android Private DNS | Forwarder stands down. `dns_forwarder=0`. DNS untouched. |
| 4.3 | Upstreams unreachable | Set `dns_upstream` to an unroutable address, restart | `dns_unhealthy` raised, DNS redirect pulled, **name resolution keeps working** via the system resolver. |
| 4.4 | Poisoned answer | On a network known to inject | Diagnostics reports `poisoned` with the sinkhole address. `dns_bogus` increments. |
| 4.5 | Private DNS mode | Set mode to `private_dns` with a hostname | Android's setting changes; original backed up in `state/private_dns.bak`. |
| 4.6 | Restore on uninstall | Uninstall after 4.5 | Original Private DNS mode and specifier restored. |

## 5. Configuration and control

| # | Scenario | Steps | Expected |
|---|---|---|---|
| 5.1 | Every mode | Cycle through all five modes | Each applies without a reboot; `strategy` and `scope` in status change accordingly. |
| 5.2 | App selection | Add and remove apps | Rules rebuilt; UID count in `DP_TCP` matches selection × user profiles. |
| 5.3 | Work profile | Add an app present in a work profile | Both UIDs appear in the chain. |
| 5.4 | All-apps mode | Switch to `all` | Single range rule (or the CORE_UIDS fallback). Telephony and connectivity checks still work. |
| 5.5 | Group toggling | Disable every group but one | Only that group's destinations are repaired. |
| 5.6 | Master switch off | Turn the switch off | Rules gone **without a reboot**. Stock networking within a second. |
| 5.7 | Emergency off button | Press it | Same, plus `disable` file created. State **Switched off**. |
| 5.8 | Clear kill switch | `dp clear-panic`, then switch on | Starts normally. |
| 5.9 | Settings export/import | Export, reset, re-import | All values restored. Rejected count is 0. |
| 5.10 | Restore last working | Break a setting, then restore | Previous known-good config reinstated. |
| 5.11 | Reset | Reset settings | Defaults restored; app selection retained. |

## 6. Security of the control surface

Run each of these and confirm the command is **rejected**, and that no side
effect occurred:

```sh
sh control.sh set mode 'compat; touch /tmp/pwned'
sh control.sh set evil_key 1
sh control.sh groups-set 'social,$(touch /tmp/pwned)'
sh control.sh groups-set 'social,`id`'
sh control.sh apps-add 'com.x;reboot'
sh control.sh set start_delay 99999
sh control.sh set proxy_port 22
sh control.sh definitely-not-a-verb
```

Expected: every one returns `{"ok":false,...}`, `/tmp/pwned` does not exist,
and the configuration file is unchanged apart from legitimate edits.

Also confirm:

- `config/directpath.conf` and `state/` are mode 0700/0600.
- `bin/dpcore` is mode 0700.
- No control interface is bound to any address other than 127.0.0.1
  (`grep -v '^ *sl' /proc/net/tcp` — local addresses must be `0100007F`).
- The log at `info` level contains no hostnames.

## 7. WebUI

| # | Scenario | Expected |
|---|---|---|
| 7.1 | Open from KernelSU manager | Loads, shows real status within 2s. |
| 7.2 | Dark, light, system themes | All three render with readable contrast. |
| 7.3 | Small screen (360dp) | No horizontal scroll, all controls reachable. |
| 7.4 | Large text accessibility setting | Layout holds. |
| 7.5 | Reduced motion | Path strip sweep does not animate. |
| 7.6 | Opened outside KernelSU | Clear message that it must be opened from the manager. Nothing breaks. |
| 7.7 | Daemon stopped while panel open | Status updates to reflect it within one refresh cycle. |
| 7.8 | Long app list | 400 rows render; filter narrows correctly. |

## 8. Effectiveness

These depend on the network you are testing from and are pass/fail against
your own baseline, not absolute.

| # | Scenario | Expected |
|---|---|---|
| 8.1 | Known-good site | `working` before and after. No change in behaviour. |
| 8.2 | Known-blocked site | `repaired` if the technique helps, `restricted` if not. Never a false `working`. |
| 8.3 | Repeated failure | A site that keeps failing escalates one rung per two failures; `state/learn.tsv` records it. |
| 8.4 | Learned state persists | Restart the daemon; the learned rung is retained. |
| 8.5 | Non-selected app | Traffic is not redirected at all; `conn_total` does not increase. |
| 8.6 | Non-enabled destination | Relayed through untouched; `conn_passthrough` increments. |

## 9. Environment changes

| # | Scenario | Expected |
|---|---|---|
| 9.1 | KernelSU manager update | Module keeps working. WebUI still opens. |
| 9.2 | KernelSU version upgrade | Module keeps working, or fails safely with stock networking. |
| 9.3 | Android security patch | Module keeps working; if kernel features changed, capability report reflects it. |
| 9.4 | Android major version upgrade | Re-run capability detection (`dp caps-refresh`). Any lost feature is reported, not silently ignored. |
| 9.5 | Kernel without `nat` table | Install succeeds with a warning; module reports it cannot redirect and applies nothing. |
| 9.6 | Kernel without `owner` match | Falls back to all-apps mode with a logged warning. |
| 9.7 | Kernel without `TCP_REPAIR` | `fake` strategy downgrades silently; capability page shows it as unavailable. |

## 10. Uninstall

| # | Scenario | Expected |
|---|---|---|
| 10.1 | Uninstall while running | Daemon stopped, all chains removed, Private DNS restored, `/data/adb/directpath` gone. |
| 10.2 | Uninstall while disabled | Same, no errors. |
| 10.3 | Uninstall then reboot | Stock networking. No leftover processes, files or chains. |
| 10.4 | Unrelated data untouched | Other modules' data and any user files outside `/data/adb/directpath` are intact. |

---

## Unit tests

The parsers have standalone tests, since a bounds error in the SNI reader
would be both a crash and a security bug:

```sh
cd src
gcc -std=c11 -Wall -Wextra -Wshadow -Wpedantic -O2 -I. \
    ../tests/test_sni.c sni.c util.c log.c -o /tmp/test_sni -lpthread && /tmp/test_sni
gcc -std=c11 -Wall -Wextra -Wshadow -Wpedantic -O2 -I. \
    ../tests/test_rules.c rules.c util.c log.c desync.c -o /tmp/test_rules -lpthread && /tmp/test_rules
```

`test_sni` builds a real ClientHello, checks the extracted hostname and byte
offset, then re-runs the parser against every truncation of that message from
1 byte upwards to confirm it neither crashes nor matches.

`test_rules` checks suffix matching (`www.youtube.com` matches a
`youtube.com` rule), confirms a bare TLD never matches, and confirms group
filtering excludes rules from disabled groups.

Both must exit 0 with no diagnostics.
