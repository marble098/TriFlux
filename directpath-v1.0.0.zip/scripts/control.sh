#!/system/bin/sh
# control.sh - the only entry point the WebUI is allowed to call.
#
# Security model: the WebUI runs inside KernelSU's webview and reaches the
# shell through ksu.exec, which means the browser side is in a position to
# ask for anything. So this script is written as if every argument were
# hostile:
#
#   * the verb must match one of the cases below, exactly
#   * every argument is validated against an allowlist before use
#   * nothing is ever passed to eval, and no argument is ever expanded into
#     a command word without first passing a validator
#   * values that fail validation are rejected with a message, never
#     clamped into something "close enough"
#
# usage: control.sh VERB [ARGS...]

SDIR=${0%/*}
. "$SDIR/lib/util.sh"
. "$SDIR/lib/config.sh"
. "$SDIR/lib/caps.sh"
. "$SDIR/lib/apps.sh"
. "$SDIR/lib/net.sh"
. "$SDIR/lib/netfilter.sh"

ensure_tree
cfg_init

fail() { printf '{"ok":false,"error":"%s"}\n' "$1"; exit 1; }
okay() { printf '{"ok":true%s}\n' "$1"; exit 0; }

# ------------------------------------------------------------- k=v to JSON

kv_to_json() {
    awk -F= '
        BEGIN { printf "{" ; first = 1 }
        /^[a-z_]+=/ {
            key = $1
            val = substr($0, length(key) + 2)
            gsub(/\\/, "\\\\", val)
            gsub(/"/, "\\\"", val)
            if (!first) printf ","
            printf "\"%s\":\"%s\"", key, val
            first = 0
        }
        END { printf "}\n" }
    '
}

# --------------------------------------------------------------- the verbs

VERB=${1:-status}
shift 2>/dev/null

case "$VERB" in

status)
    "$SDIR/engine.sh" status | kv_to_json
    ;;

health)
    "$SDIR/engine.sh" health
    ;;

# ---- master switch ----------------------------------------------------
on)
    rm -f "$DATA/disable" /data/local/tmp/directpath_off
    rm -f "$STATEDIR/auto_disabled" "$STATEDIR/crash_count"
    cfg_set enabled 1 || fail "could not save the setting"
    "$SDIR/engine.sh" start >/dev/null 2>&1
    okay ",\"status\":\"$(get_status)\""
    ;;

off)
    cfg_set enabled 0 || fail "could not save the setting"
    "$SDIR/engine.sh" stop >/dev/null 2>&1
    okay ",\"status\":\"$(get_status)\""
    ;;

# ---- the panic button -------------------------------------------------
# Writes the kill switch first, then tears down. Written first on purpose:
# if the teardown itself hangs, the next boot still comes up clean.
panic)
    printf 'user pressed emergency off\n' | atomic_write "$DATA/disable"
    "$SDIR/engine.sh" stop >/dev/null 2>&1
    nf_down 2>/dev/null
    okay ",\"status\":\"disabled\""
    ;;

clear-panic)
    rm -f "$DATA/disable" /data/local/tmp/directpath_off "$STATEDIR/auto_disabled"
    rm -f "$STATEDIR/crash_count"
    okay ""
    ;;

# ---- configuration ----------------------------------------------------
config)
    # Every setting at once, so the WebUI can populate its fields in one call.
    printf '{'
    _first=1
    for _k in $CFG_KEYS; do
        [ "$_first" = 1 ] || printf ','
        printf '"%s":"%s"' "$_k" "$(cfg_get "$_k")"
        _first=0
    done
    printf '}\n'
    ;;

get)
    [ -n "$1" ] || fail "missing key"
    one_of "$1" $CFG_KEYS || fail "unknown key"
    printf '{"ok":true,"key":"%s","value":"%s"}\n' "$1" "$(cfg_get "$1")"
    ;;

set)
    [ -n "$1" ] && [ $# -ge 2 ] || fail "usage: set KEY VALUE"
    _k=$1; _v=$2
    # The WebUI cannot send an empty argument, so it sends this sentinel.
    [ "$_v" = "_EMPTY_" ] && _v=""
    one_of "$_k" $CFG_KEYS || fail "unknown key"
    cfg_valid "$_k" "$_v" || fail "value not allowed for $_k"
    cfg_set "$_k" "$_v" || fail "could not save"
    okay ",\"key\":\"$_k\",\"value\":\"$_v\""
    ;;

mode)
    one_of "$1" auto compat performance aggressive custom || fail "unknown mode"
    cfg_set mode "$1" || fail "could not save"
    okay ",\"mode\":\"$1\""
    ;;

apply)
    "$SDIR/engine.sh" apply >/dev/null 2>&1
    okay ",\"status\":\"$(get_status)\""
    ;;

restart)
    "$SDIR/engine.sh" restart >/dev/null 2>&1
    okay ",\"status\":\"$(get_status)\""
    ;;

# ---- destination groups -----------------------------------------------
groups-list)
    printf '['
    _sel=$(cfg_get groups)
    _first=1
    for f in "$RULEDIR"/*.list; do
        [ -f "$f" ] || continue
        _g=$(basename "$f" .list)
        [ "$_g" = "bogus-ip" ] && continue
        _n=$(grep -c '^[a-z0-9]' "$f" 2>/dev/null)
        is_int "$_n" || _n=0
        _on=false
        case ",$_sel," in *",$_g,"*) _on=true ;; esac
        [ "$_first" = 1 ] || printf ','
        printf '{"name":"%s","count":%s,"enabled":%s}' "$_g" "$_n" "$_on"
        _first=0
    done
    printf ']\n'
    ;;

groups-set)
    [ -n "$1" ] || fail "missing group list"
    cfg_valid groups "$1" || fail "invalid group list"
    # Every named group must actually exist as a rule file.
    _bad=""
    _list=$(printf '%s' "$1" | tr ',' ' ')
    for _g in $_list; do
        [ -f "$RULEDIR/$_g.list" ] || _bad="$_bad $_g"
    done
    [ -n "$_bad" ] && fail "unknown group:$_bad"
    cfg_set groups "$1" || fail "could not save"
    okay ",\"groups\":\"$1\""
    ;;

# ---- applications ------------------------------------------------------
apps-list)
    printf '['
    _first=1
    apps_list | while IFS="$(printf '\t')" read -r pkg uid sys sel; do
        [ -n "$pkg" ] || continue
        [ "$_first" = 1 ] || printf ','
        printf '{"pkg":"%s","uid":%s,"system":%s,"selected":%s}' \
            "$pkg" "$uid" \
            "$([ "$sys" = 1 ] && printf true || printf false)" \
            "$([ "$sel" = 1 ] && printf true || printf false)"
        _first=0
    done
    printf ']\n'
    ;;

apps-add)
    is_pkgname "$1" || fail "invalid package name"
    apps_appid "$1" >/dev/null 2>&1 || fail "package is not installed"
    apps_add "$1" || fail "could not add"
    okay ""
    ;;

apps-remove)
    is_pkgname "$1" || fail "invalid package name"
    apps_remove "$1" || fail "could not remove"
    okay ""
    ;;

apps-profile)
    one_of "$1" social video messaging developer ai browsers everything clear ||
        fail "unknown profile"
    apps_set_profile "$1" || fail "could not apply the profile"
    okay ",\"profile\":\"$1\",\"count\":$(apps_count)"
    ;;

# ---- diagnostics and logs ----------------------------------------------
diag)
    "$SDIR/diag.sh" run
    ;;

caps)
    caps_load
    cat "$CAPSFILE" 2>/dev/null | kv_to_json
    ;;

caps-refresh)
    caps_detect
    cat "$CAPSFILE" 2>/dev/null | kv_to_json
    ;;

logs)
    _n=${1:-200}
    in_range "$_n" 10 2000 || _n=200
    { cat "$ENGINE_LOG" 2>/dev/null; cat "$LOGDIR/dpcore.log" 2>/dev/null; } |
        sort -k1,2 | tail -n "$_n"
    ;;

logs-clear)
    : | atomic_write "$ENGINE_LOG"
    : | atomic_write "$LOGDIR/dpcore.log"
    rm -f "$ENGINE_LOG.1" "$LOGDIR/dpcore.log.1"
    log_i "logs cleared by the user"
    okay ""
    ;;

# ---- backup and restore -------------------------------------------------
export-config)
    # Settings and the app selection only. No logs, no learned hosts, no
    # addresses: an exported file should be safe to paste into a bug report.
    printf '# directpath settings export %s\n' "$(date '+%Y-%m-%d %H:%M:%S')"
    printf '[settings]\n'
    cat "$CONF" 2>/dev/null
    printf '[apps]\n'
    apps_selected_packages
    ;;

export-diagnostics)
    # Includes device and capability context, still without any traffic data.
    printf '# directpath diagnostics %s\n' "$(date '+%Y-%m-%d %H:%M:%S')"
    printf 'module=%s\n' "$(grep -m1 '^version=' "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2-)"
    printf 'android=%s\n' "$(getprop ro.build.version.release 2>/dev/null)"
    printf 'sdk=%s\n'     "$(getprop ro.build.version.sdk 2>/dev/null)"
    printf 'device=%s\n'  "$(getprop ro.product.model 2>/dev/null)"
    printf 'kernel=%s\n'  "$(uname -r 2>/dev/null)"
    printf '\n[capabilities]\n'; cat "$CAPSFILE" 2>/dev/null
    printf '\n[status]\n';       "$SDIR/engine.sh" status
    printf '\n[settings]\n';     cat "$CONF" 2>/dev/null
    printf '\n[recent log]\n'
    { cat "$ENGINE_LOG" 2>/dev/null; cat "$LOGDIR/dpcore.log" 2>/dev/null; } | tail -n 120
    ;;

import-config)
    # Accepts the [settings] section of an export on stdin. Each line is
    # revalidated; anything unrecognised is dropped rather than trusted.
    _imported=0
    _rejected=0
    while IFS= read -r line; do
        case "$line" in
            \#*|'['*|'') continue ;;
        esac
        _k=${line%%=*}
        _v=${line#*=}
        [ "$_k" = "$line" ] && continue
        if one_of "$_k" $CFG_KEYS && cfg_valid "$_k" "$_v"; then
            cfg_set "$_k" "$_v" >/dev/null && _imported=$((_imported + 1))
        else
            _rejected=$((_rejected + 1))
        fi
    done
    okay ",\"imported\":$_imported,\"rejected\":$_rejected"
    ;;

reset-config)
    cfg_reset
    okay ""
    ;;

restore-good)
    cfg_restore_good || fail "no known-good configuration saved yet"
    okay ""
    ;;

update-rules)
    "$SDIR/update.sh" rules
    ;;

version)
    printf '{"module":"%s","core":"%s"}\n' \
        "$(grep -m1 '^version=' "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2-)" \
        "$("$BINDIR/dpcore" --version 2>/dev/null || printf 'missing')"
    ;;

*)
    fail "unknown command"
    ;;
esac
