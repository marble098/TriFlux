#!/system/bin/sh
# engine.sh - start, stop and supervise the whole subsystem.
#
# Ordering here is the anti-bootloop design. The daemon is started first and
# proven to be listening before a single firewall rule exists. If it never
# comes up, nothing was changed and the phone's networking is untouched. If
# rules fail to apply, they are removed again immediately. There is no state
# in which traffic is pointed at a socket that is not there for longer than
# the supervisor's tick.
#
# usage: engine.sh {start|stop|restart|apply|status|health|panic|suspend|resume}

SDIR=${0%/*}
. "$SDIR/lib/util.sh"
. "$SDIR/lib/config.sh"
. "$SDIR/lib/caps.sh"
. "$SDIR/lib/apps.sh"
. "$SDIR/lib/net.sh"
. "$SDIR/lib/netfilter.sh"

case "$(cfg_get log_level 2>/dev/null)" in
    error) LOG_LEVEL_NUM=1 ;;
    warn)  LOG_LEVEL_NUM=2 ;;
    debug) LOG_LEVEL_NUM=4 ;;
    *)     LOG_LEVEL_NUM=3 ;;
esac

# --------------------------------------------------------------- the daemon

core_bin() { printf '%s/dpcore' "$BINDIR"; }

core_running() {
    _cp=$(read_pid "$PIDFILE") || return 1
    pid_alive "$_cp" || return 1
    grep -q dpcore "/proc/$_cp/cmdline" 2>/dev/null || return 1
    return 0
}

core_start() {
    _bin=$(core_bin)
    if [ ! -x "$_bin" ]; then
        log_e "dpcore binary missing at $_bin"
        return 1
    fi
    core_running && return 0

    rm -f "$STATEDIR/dns_unhealthy"
    cfg_write_core

    "$_bin" --config "$COREONF" --rollback "$SDIR/engine.sh" || {
        log_e "dpcore refused to start (exit $?)"
        return 1
    }

    # Prove it is actually listening before anything is redirected to it.
    _wait=0
    while [ "$_wait" -lt 15 ]; do
        if core_running && port_listening "$(cfg_get proxy_port)"; then
            log_i "dpcore is listening on $(cfg_get proxy_port)"
            return 0
        fi
        sleep 1
        _wait=$((_wait + 1))
    done
    log_e "dpcore did not begin listening within 15s"
    core_stop
    return 1
}

core_stop() {
    stop_pidfile "$PIDFILE"
    # Belt and braces for a daemon that lost its pidfile.
    for p in $(ls /proc 2>/dev/null); do
        is_int "$p" || continue
        if grep -q "dpcore" "/proc/$p/cmdline" 2>/dev/null; then
            grep -q "$COREONF" "/proc/$p/cmdline" 2>/dev/null && kill -TERM "$p" 2>/dev/null
        fi
    done
    return 0
}

# ------------------------------------------------------------------ actions

engine_start() {
    ensure_tree
    cfg_init

    if emergency_off; then
        log_w "start refused: $(emergency_reason)"
        set_status disabled
        nf_down
        return 0
    fi
    if [ "$(cfg_get enabled)" != 1 ]; then
        log_i "start skipped, master switch is off"
        set_status off
        nf_down
        return 0
    fi

    lock_acquire 30 || return 1
    set_status starting

    caps_detect

    if portal_detected; then
        log_w "captive portal suspected, staying out of the way for now"
        nf_down
        core_stop
        set_status portal
        lock_release
        return 0
    fi

    dns_decide

    if ! core_start; then
        set_status error
        printf 'daemon failed to start\n' | atomic_write "$RUNDIR/last_error"
        lock_release
        return 1
    fi

    if ! nf_up; then
        log_e "rule application failed, reverting to stock networking"
        core_stop
        set_status error
        printf 'rules could not be applied\n' | atomic_write "$RUNDIR/last_error"
        lock_release
        return 1
    fi

    net_signature_store
    rm -f "$RUNDIR/last_error"
    set_status active
    cfg_save_good
    printf '%s\n' "$(date '+%s')" | atomic_write "$STATEDIR/started_at"
    log_i "engine active"
    lock_release
    watchdog_ensure
    return 0
}

engine_stop() {
    lock_acquire 20 || {
        # Never let a stuck lock prevent a rollback.
        log_w "forcing teardown without the lock"
    }
    nf_down
    core_stop
    dns_restore_private
    set_status off
    rm -f "$STATEDIR/started_at"
    log_i "engine stopped, stock networking restored"
    lock_release
    return 0
}

# Called from dpcore's fatal signal handler. Must be fast and must not
# depend on any state the crashing process owned.
engine_panic() {
    nf_down
    set_status recovering
    printf 'daemon crashed, rules removed\n' | atomic_write "$RUNDIR/last_error"
    log_e "panic rollback executed"
    return 0
}

engine_suspend() {
    nf_down
    set_status suspended
    log_i "suspended, rules removed but daemon left running"
}

engine_resume() {
    engine_start
}

engine_restart() {
    engine_stop
    engine_start
}

# Reapply after a settings change, without a reboot.
engine_apply() {
    if [ "$(cfg_get enabled)" != 1 ]; then
        engine_stop
        return 0
    fi
    core_stop
    engine_start
}

# engine_health -> 0 healthy, 1 degraded, 2 down
engine_health() {
    [ "$(cfg_get enabled)" = 1 ] || return 2
    emergency_off && return 2
    core_running || return 2
    port_listening "$(cfg_get proxy_port)" || return 2
    nf_active || return 1
    [ -f "$STATEDIR/dns_unhealthy" ] && return 1
    return 0
}

engine_status() {
    _st=$(get_status)
    _up=0
    if [ -f "$STATEDIR/started_at" ]; then
        _s=$(cat "$STATEDIR/started_at" 2>/dev/null)
        is_int "$_s" && _up=$(( $(date '+%s') - _s ))
    fi
    caps_load
    cfg_resolve_mode
    dns_decide

    printf 'status=%s\n'        "$_st"
    printf 'enabled=%s\n'       "$(cfg_get enabled)"
    printf 'mode=%s\n'          "$(cfg_get mode)"
    printf 'strategy=%s\n'      "$RES_STRATEGY"
    printf 'scope=%s\n'         "$RES_SCOPE"
    printf 'app_mode=%s\n'      "$(cfg_get app_mode)"
    printf 'apps=%s\n'          "$(apps_count)"
    printf 'groups=%s\n'        "$(cfg_get groups)"
    printf 'uptime=%s\n'        "$_up"
    printf 'daemon=%s\n'        "$(core_running && printf running || printf stopped)"
    printf 'rules=%s\n'         "$(nf_active && printf applied || printf none)"
    printf 'dns_forwarder=%s\n' "$DNS_FORWARDER_ON"
    printf 'private_dns=%s\n'   "$(private_dns_mode)"
    printf 'ipv6_mode=%s\n'     "$RES_IPV6"
    printf 'ipv6_up=%s\n'       "$CAP_IPV6_UP"
    printf 'quic_block=%s\n'    "$RES_QUIC"
    printf 'nat4=%s\n'          "$CAP_NAT4"
    printf 'nat6=%s\n'          "$CAP_NAT6"
    printf 'owner_match=%s\n'   "$CAP_OWNER"
    printf 'tcp_repair=%s\n'    "$CAP_TCP_REPAIR"
    printf 'emergency=%s\n'     "$(emergency_reason)"
    printf 'last_error=%s\n'    "$(cat "$RUNDIR/last_error" 2>/dev/null || printf none)"
    printf 'boot_count=%s\n'    "$(cat "$BOOTCOUNT" 2>/dev/null || printf 0)"
    printf 'version=%s\n'       "$(grep -m1 '^version=' "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2-)"
    [ -f "$STATSFILE" ] && cat "$STATSFILE"
    return 0
}

watchdog_ensure() {
    _wp=$(read_pid "$RUNDIR/watchdog.pid") && pid_alive "$_wp" && return 0
    rm -f "$RUNDIR/watchdog.pid"
    "$SDIR/watchdog.sh" &
    return 0
}

case "${1:-status}" in
    start)    engine_start ;;
    stop)     engine_stop ;;
    restart)  engine_restart ;;
    apply)    engine_apply ;;
    suspend)  engine_suspend ;;
    resume)   engine_resume ;;
    panic)    engine_panic ;;
    health)   engine_health; printf '%s\n' "$?" ;;
    status)   engine_status ;;
    *)        printf 'usage: engine.sh {start|stop|restart|apply|suspend|resume|panic|health|status}\n' >&2
              exit 2 ;;
esac
