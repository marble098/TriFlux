#!/system/bin/sh
# watchdog.sh - the supervisor.
#
# One shell process that sleeps most of its life. On each tick it answers
# four questions and nothing else:
#
#   Should we be running at all?      -> kill switches and the master switch
#   Is the daemon alive and bound?    -> if not, remove rules first, then retry
#   Are our rules still installed?    -> netd flushes tables on network change
#   Did the network change under us?  -> re-evaluate portal and re-apply
#
# The ordering in the second question is the important one. Rules that point
# at a dead socket are the only way this module can take the internet away,
# so removal always happens before any attempt to recover.

SDIR=${0%/*}
. "$SDIR/lib/util.sh"
. "$SDIR/lib/config.sh"
. "$SDIR/lib/caps.sh"
. "$SDIR/lib/apps.sh"
. "$SDIR/lib/net.sh"
. "$SDIR/lib/netfilter.sh"
WD_PID=$RUNDIR/watchdog.pid
CRASHFILE=$STATEDIR/crash_count
MAX_CRASHES=3

ensure_tree

# Only one supervisor, ever.
_old=$(read_pid "$WD_PID") && pid_alive "$_old" && exit 0
printf '%s\n' "$$" > "$WD_PID"

trap 'rm -f "$WD_PID"; exit 0' TERM INT

crash_count()  { cat "$CRASHFILE" 2>/dev/null || printf 0; }
crash_bump()   { printf '%s\n' "$(( $(crash_count) + 1 ))" | atomic_write "$CRASHFILE"; }
crash_clear()  { rm -f "$CRASHFILE"; }

auto_disable() {
    printf '%s\n' "$1" | atomic_write "$STATEDIR/auto_disabled"
    nf_down
    "$SDIR/engine.sh" stop >/dev/null 2>&1
    set_status disabled
    log_e "auto-disabled: $1"
}

INTERVAL=$(cfg_get watchdog_interval)
is_int "$INTERVAL" || INTERVAL=30
HEALTHY_SINCE=$(date '+%s')

log_i "supervisor started, interval ${INTERVAL}s"

while :; do
    sleep "$INTERVAL"

    if emergency_off; then
        log_w "kill switch active, tearing down and exiting"
        nf_down
        stop_pidfile "$PIDFILE"
        set_status disabled
        rm -f "$WD_PID"
        exit 0
    fi

    if [ "$(cfg_get enabled)" != 1 ]; then
        nf_down
        stop_pidfile "$PIDFILE"
        set_status off
        rm -f "$WD_PID"
        exit 0
    fi

    # A suspended engine is a deliberate state; leave it alone.
    [ "$(get_status)" = suspended ] && continue

    # ---- 1. daemon liveness -------------------------------------------
    _pid=$(read_pid "$PIDFILE")
    if [ -z "$_pid" ] || ! pid_alive "$_pid"; then
        log_e "daemon is gone, removing rules before anything else"
        nf_down
        set_status recovering
        crash_bump

        if [ "$(crash_count)" -ge "$MAX_CRASHES" ]; then
            auto_disable "daemon failed $(crash_count) times in a row"
            rm -f "$WD_PID"
            exit 0
        fi

        log_i "restart attempt $(crash_count) of $MAX_CRASHES"
        if "$SDIR/engine.sh" start >/dev/null 2>&1; then
            HEALTHY_SINCE=$(date '+%s')
        fi
        continue
    fi

    # ---- 2. the daemon is up but stopped listening ---------------------
    if ! port_listening "$(cfg_get proxy_port)"; then
        log_e "daemon is running but not accepting connections"
        nf_down
        stop_pidfile "$PIDFILE"
        crash_bump
        set_status recovering
        continue
    fi

    # ---- 3. DNS forwarder asked to be taken out of the path ------------
    if [ -f "$STATEDIR/dns_unhealthy" ]; then
        nf_drop_dns
        rm -f "$STATEDIR/dns_unhealthy"
        set_status degraded
    fi

    # ---- 4. network change --------------------------------------------
    if net_signature_changed; then
        net_signature_store
        log_i "active network changed, re-evaluating"
        # A new network may be a hotel portal; let the engine decide.
        "$SDIR/engine.sh" apply >/dev/null 2>&1
        continue
    fi

    # ---- 5. our rules disappeared (netd reload, ROM housekeeping) ------
    if ! nf_active; then
        log_w "rules are missing, reinstalling"
        dns_decide
        if ! nf_up; then
            log_e "reinstall failed, staying out of the path"
            nf_down
            set_status degraded
            crash_bump
            [ "$(crash_count)" -ge "$MAX_CRASHES" ] && {
                auto_disable "rules could not be reapplied"
                rm -f "$WD_PID"
                exit 0
            }
            continue
        fi
        set_status active
        continue
    fi

    # ---- 6. everything is fine ----------------------------------------
    [ "$(get_status)" = active ] || set_status active
    if [ $(( $(date '+%s') - HEALTHY_SINCE )) -ge 600 ]; then
        [ "$(crash_count)" -gt 0 ] && log_i "stable for 10 minutes, clearing crash counter"
        crash_clear
        HEALTHY_SINCE=$(date '+%s')
    fi
done
