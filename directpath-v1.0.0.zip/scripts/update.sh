#!/system/bin/sh
# update.sh - refresh the destination rule database.
#
# What this does and does not do, deliberately:
#
#   It downloads a plain text bundle of domain lists and a detached SHA-256
#   manifest over HTTPS, verifies every file against the manifest, stages
#   the result in a scratch directory, and only then swaps it into place.
#   The previous database is kept and restored if anything fails.
#
#   It never downloads or executes code. The only thing that can arrive from
#   the network is a list of domain names, and each line is validated as a
#   domain before it is accepted. A compromised update server can therefore
#   cause the module to repair the wrong websites; it cannot gain execution.
#
#   Module updates themselves go through KernelSU's own flashing flow, which
#   already verifies the zip. This script does not self-update the module.
#
# usage: update.sh {rules|check|status}

SDIR=${0%/*}
. "$SDIR/lib/util.sh"
. "$SDIR/lib/config.sh"

STAGE=$DATA/.stage
RULES_BAK=$BACKUPDIR/rules.prev
SOURCE_FILE=$CONFDIR/update-source
DEFAULT_SOURCE="https://raw.githubusercontent.com/directpath-module/rules/main"

MAX_FILE_BYTES=1048576
VALID_GROUPS="social video messaging developer ai news gaming custom bogus-ip"

fail_json() { printf '{"ok":false,"error":"%s"}\n' "$1"; exit 1; }

update_source() {
    if [ -f "$SOURCE_FILE" ]; then
        _s=$(head -n1 "$SOURCE_FILE" | tr -d '\r\n ')
        case "$_s" in
            https://*) printf '%s' "$_s"; return ;;
            *) log_w "ignoring non-HTTPS update source" ;;
        esac
    fi
    printf '%s' "$DEFAULT_SOURCE"
}

# Android ships curl on most builds; wget is the usual fallback.
fetch() {
    _url=$1; _dst=$2
    case "$_url" in https://*) ;; *) return 1 ;; esac

    if command -v curl >/dev/null 2>&1; then
        curl -fsSL --max-time 40 --max-filesize "$MAX_FILE_BYTES" \
             --proto '=https' --tlsv1.2 -o "$_dst" "$_url" 2>/dev/null
        return $?
    fi
    if command -v wget >/dev/null 2>&1; then
        wget -q -T 40 -O "$_dst" "$_url" 2>/dev/null
        return $?
    fi
    return 1
}

sha256_of() {
    if command -v sha256sum >/dev/null 2>&1; then
        sha256sum "$1" 2>/dev/null | cut -d' ' -f1
    elif command -v toybox >/dev/null 2>&1; then
        toybox sha256sum "$1" 2>/dev/null | cut -d' ' -f1
    else
        printf ''
    fi
}

# Reject anything that is not a plain list of domain names. This is the
# check that keeps a hostile bundle from becoming anything more than noise.
sanitise_list() {
    _src=$1; _dst=$2
    _kept=0
    : > "$_dst"
    while IFS= read -r line; do
        line=$(printf '%s' "$line" | tr -d '\r' | tr -d ' \t')
        [ -z "$line" ] && continue
        case "$line" in \#*) continue ;; esac
        case "$line" in \*.*) line=${line#\*.} ;; esac
        if is_domain "$line"; then
            printf '%s\n' "$line" >> "$_dst"
            _kept=$((_kept + 1))
        fi
    done < "$_src"
    [ "$_kept" -gt 0 ]
}

do_update() {
    ensure_tree
    _base=$(update_source)
    log_i "rule update from $_base"

    rm -rf "$STAGE"
    mkdir -p "$STAGE" || fail_json "could not create the staging directory"

    if ! fetch "$_base/SHA256SUMS" "$STAGE/SHA256SUMS"; then
        rm -rf "$STAGE"
        fail_json "could not reach the update source"
    fi
    if [ ! -s "$STAGE/SHA256SUMS" ]; then
        rm -rf "$STAGE"
        fail_json "the manifest was empty"
    fi

    _got=0
    _bad=0
    while read -r want name; do
        [ -n "$name" ] || continue
        # Only files we recognise, never a path the manifest chose.
        _g=${name%.list}
        one_of "$_g" $VALID_GROUPS || { log_w "manifest names unknown group $_g"; continue; }
        case "$want" in
            ''|*[!0-9a-fA-F]*) log_w "malformed digest for $name"; _bad=$((_bad + 1)); continue ;;
        esac

        if ! fetch "$_base/$name" "$STAGE/$name.raw"; then
            log_w "download failed: $name"
            _bad=$((_bad + 1))
            continue
        fi
        _have=$(sha256_of "$STAGE/$name.raw")
        if [ -z "$_have" ]; then
            rm -rf "$STAGE"
            fail_json "no SHA-256 tool on this device, refusing an unverified update"
        fi
        if [ "$_have" != "$want" ]; then
            log_e "digest mismatch for $name"
            _bad=$((_bad + 1))
            rm -f "$STAGE/$name.raw"
            continue
        fi
        if sanitise_list "$STAGE/$name.raw" "$STAGE/$name"; then
            _got=$((_got + 1))
        else
            log_w "$name contained nothing usable"
            _bad=$((_bad + 1))
        fi
        rm -f "$STAGE/$name.raw"
    done < "$STAGE/SHA256SUMS"

    if [ "$_got" = 0 ]; then
        rm -rf "$STAGE"
        fail_json "no rule files passed verification, keeping the existing database"
    fi

    # Atomic-ish swap: keep the old copy until the new one is in place.
    rm -rf "$RULES_BAK"
    cp -a "$RULEDIR" "$RULES_BAK" 2>/dev/null

    _moved=0
    for f in "$STAGE"/*.list; do
        [ -f "$f" ] || continue
        if mv -f "$f" "$RULEDIR/$(basename "$f")"; then
            _moved=$((_moved + 1))
        fi
    done

    if [ "$_moved" = 0 ]; then
        log_e "swap failed, restoring the previous database"
        rm -rf "$RULEDIR"
        mv "$RULES_BAK" "$RULEDIR"
        rm -rf "$STAGE"
        fail_json "could not install the new rules"
    fi

    printf '%s\n' "$(date '+%s')" | atomic_write "$STATEDIR/rules_updated"
    rm -rf "$STAGE"
    chmod 644 "$RULEDIR"/*.list 2>/dev/null
    log_i "rule update complete: $_moved files, $_bad rejected"

    # The daemon loads rules at startup, so a restart is what publishes them.
    "$SDIR/engine.sh" apply >/dev/null 2>&1

    printf '{"ok":true,"updated":%s,"rejected":%s}\n' "$_moved" "$_bad"
}

case "${1:-status}" in
    rules) do_update ;;
    check)
        _base=$(update_source)
        if fetch "$_base/SHA256SUMS" "$RUNDIR/manifest.check" 2>/dev/null; then
            printf '{"ok":true,"reachable":true}\n'
        else
            printf '{"ok":true,"reachable":false}\n'
        fi
        rm -f "$RUNDIR/manifest.check"
        ;;
    status)
        _when=$(cat "$STATEDIR/rules_updated" 2>/dev/null || printf 0)
        _count=0
        for f in "$RULEDIR"/*.list; do
            [ -f "$f" ] || continue
            _c=$(grep -c '^[a-z0-9]' "$f" 2>/dev/null)
            is_int "$_c" || _c=0
            _count=$((_count + _c))
        done
        printf '{"ok":true,"last_update":%s,"domains":%s,"source":"%s"}\n' \
            "$_when" "$_count" "$(update_source)"
        ;;
    *) printf 'usage: update.sh {rules|check|status}\n' >&2; exit 2 ;;
esac
