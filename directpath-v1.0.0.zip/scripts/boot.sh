#!/system/bin/sh
# boot.sh - the guarded boot starter.
#
# Called from both service.sh and boot-completed.sh. Holds its own lock so
# only one instance ever runs. The sequence is deliberately unhurried:
#
#   1. wait for Android to say it has finished booting
#   2. wait out the configured settling delay on top of that
#   3. start the engine, which itself refuses to touch the firewall until
#      the daemon is proven to be listening
#   4. stay alive for a minute and check the result
#   5. only then clear the boot attempt counter
#
# Step 5 is the whole point. The counter incremented in post-fs-data.sh is
# cleared here and nowhere else, so a boot that reaches Android but dies
# afterwards still counts as a failure and still trips the kill switch.

SDIR=${0%/*}
. "$SDIR/lib/util.sh"
. "$SDIR/lib/config.sh"

BOOTLOCK=$RUNDIR/bootlock
SETTLE_AFTER_START=60

ensure_tree
cfg_init

# ---------------------------------------------------------------- one only

if ! mkdir "$BOOTLOCK" 2>/dev/null; then
    _bp=$(cat "$BOOTLOCK/pid" 2>/dev/null)
    if [ -n "$_bp" ] && pid_alive "$_bp"; then
        log_d "boot starter already running as $_bp, invoked by ${1:-unknown}"
        exit 0
    fi
    rm -rf "$BOOTLOCK"
    mkdir "$BOOTLOCK" 2>/dev/null || exit 0
fi
printf '%s\n' "$$" > "$BOOTLOCK/pid"
trap 'rm -rf "$BOOTLOCK"' EXIT

log_i "boot starter invoked by ${1:-unknown}"

if emergency_off; then
    log_w "boot start refused: $(emergency_reason)"
    set_status disabled
    exit 0
fi

# ------------------------------------------------------- wait for Android

# Bounded: if the property never appears we carry on anyway rather than
# leave a shell asleep forever.
_waited=0
while [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ] && [ "$_waited" -lt 180 ]; do
    sleep 3
    _waited=$((_waited + 3))
done
log_d "sys.boot_completed after ${_waited}s"

# Settling delay. Android is still bringing up connectivity, netd is still
# rewriting tables, and starting into that is how modules end up fighting
# the platform. Waiting costs the user a few seconds of unrepaired traffic.
DELAY=$(cfg_get start_delay)
is_int "$DELAY" || DELAY=25
[ "$DELAY" -gt 0 ] && sleep "$DELAY"

if emergency_off; then
    log_w "boot start refused after the delay: $(emergency_reason)"
    exit 0
fi

if [ "$(cfg_get enabled)" != 1 ]; then
    log_i "master switch is off, nothing started"
    set_status off
    # A deliberate off state is a healthy boot.
    printf '0\n' | atomic_write "$BOOTCOUNT"
    exit 0
fi

# ------------------------------------------------------------------ start

if "$SDIR/engine.sh" start >/dev/null 2>&1; then
    log_i "engine start returned success"
else
    log_e "engine start failed"
fi

# ------------------------------------------------------- confirm and clear

sleep "$SETTLE_AFTER_START"

"$SDIR/engine.sh" health >/dev/null 2>&1
HEALTH=$?

case "$HEALTH" in
    0)
        log_i "healthy after ${SETTLE_AFTER_START}s, clearing the boot counter"
        printf '0\n' | atomic_write "$BOOTCOUNT"
        rm -f "$STATEDIR/crash_count"
        cfg_save_good
        ;;
    1)
        log_w "degraded after ${SETTLE_AFTER_START}s, boot counter kept"
        printf '0\n' | atomic_write "$BOOTCOUNT"
        ;;
    *)
        log_e "not healthy after ${SETTLE_AFTER_START}s, removing rules"
        "$SDIR/engine.sh" stop >/dev/null 2>&1
        set_status error
        ;;
esac

exit 0
