#!/system/bin/sh
# lib/caps.sh - find out what this particular kernel can actually do.
#
# Android kernels differ enormously in which netfilter pieces are built in.
# Rather than assume, we probe once per boot by creating a scratch chain,
# adding the exact rule shapes we intend to use, and deleting it again. A
# feature that fails here is simply never used, and the engine picks a
# different path instead of producing a half-applied ruleset.

CAP_IPT=0            # iptables usable at all
CAP_IP6T=0           # ip6tables usable at all
CAP_NAT4=0           # nat table + REDIRECT on IPv4
CAP_NAT6=0           # nat table + REDIRECT on IPv6
CAP_OWNER=0          # -m owner --uid-owner
CAP_OWNER_RANGE=0    # --uid-owner LOW-HIGH
CAP_REJECT=0         # REJECT target in filter
CAP_NFT=0            # nft binary present
CAP_IPV6_UP=0        # a global IPv6 address exists right now
CAP_TCP_REPAIR=0     # reported by dpcore --probe
CAP_TTL=0

IPT=""
IP6T=""

PROBE_CHAIN=DPPROBE

_cap_find_bins() {
    for c in /system/bin/iptables /system/bin/iptables-nft iptables; do
        command -v "$c" >/dev/null 2>&1 && { IPT=$c; break; }
    done
    for c in /system/bin/ip6tables /system/bin/ip6tables-nft ip6tables; do
        command -v "$c" >/dev/null 2>&1 && { IP6T=$c; break; }
    done
    command -v nft >/dev/null 2>&1 && CAP_NFT=1
}

# Remove a scratch chain wherever it may have survived a previous crash.
_cap_cleanup() {
    _cc_bin=$1; _cc_tab=$2
    [ -n "$_cc_bin" ] || return 0
    "$_cc_bin" -t "$_cc_tab" -F "$PROBE_CHAIN" >/dev/null 2>&1
    "$_cc_bin" -t "$_cc_tab" -X "$PROBE_CHAIN" >/dev/null 2>&1
}

_cap_probe_nat() {
    _cp_bin=$1
    _cp_ok=0
    [ -n "$_cp_bin" ] || return 1

    _cap_cleanup "$_cp_bin" nat
    "$_cp_bin" -t nat -N "$PROBE_CHAIN" >/dev/null 2>&1 || return 1
    if "$_cp_bin" -t nat -A "$PROBE_CHAIN" -p tcp --dport 443 \
            -j REDIRECT --to-ports 9451 >/dev/null 2>&1; then
        _cp_ok=1
    fi
    _cap_cleanup "$_cp_bin" nat
    [ "$_cp_ok" = 1 ]
}

_cap_probe_owner() {
    _co_bin=$1
    _co_ok=0
    [ -n "$_co_bin" ] || return 1

    _cap_cleanup "$_co_bin" nat
    "$_co_bin" -t nat -N "$PROBE_CHAIN" >/dev/null 2>&1 || return 1
    if "$_co_bin" -t nat -A "$PROBE_CHAIN" -m owner --uid-owner 10000 \
            -j RETURN >/dev/null 2>&1; then
        _co_ok=1
        # Range syntax is a separate question: some builds only take a
        # single uid, and silently rejecting a range would drop rules.
        if "$_co_bin" -t nat -A "$PROBE_CHAIN" -m owner --uid-owner 10000-19999 \
                -j RETURN >/dev/null 2>&1; then
            CAP_OWNER_RANGE=1
        fi
    fi
    _cap_cleanup "$_co_bin" nat
    [ "$_co_ok" = 1 ]
}

_cap_probe_reject() {
    _cr_bin=$1
    _cr_ok=0
    [ -n "$_cr_bin" ] || return 1

    _cap_cleanup "$_cr_bin" filter
    "$_cr_bin" -t filter -N "$PROBE_CHAIN" >/dev/null 2>&1 || return 1
    "$_cr_bin" -t filter -A "$PROBE_CHAIN" -p udp --dport 443 \
        -j REJECT --reject-with icmp-port-unreachable >/dev/null 2>&1 && _cr_ok=1
    _cap_cleanup "$_cr_bin" filter
    [ "$_cr_ok" = 1 ]
}

# A global (non link-local) IPv6 address on a non-loopback interface is the
# only reliable signal that IPv6 is genuinely usable on this network.
_cap_probe_ipv6() {
    command -v ip >/dev/null 2>&1 || return 1
    ip -6 addr show scope global 2>/dev/null | grep -q 'inet6' && return 0
    return 1
}

caps_detect() {
    ensure_tree
    _cap_find_bins

    [ -n "$IPT" ] && "$IPT" -t filter -L -n >/dev/null 2>&1 && CAP_IPT=1
    [ -n "$IP6T" ] && "$IP6T" -t filter -L -n >/dev/null 2>&1 && CAP_IP6T=1

    if [ "$CAP_IPT" = 1 ]; then
        _cap_probe_nat "$IPT" && CAP_NAT4=1
        _cap_probe_owner "$IPT" && CAP_OWNER=1
        _cap_probe_reject "$IPT" && CAP_REJECT=1
    fi
    if [ "$CAP_IP6T" = 1 ]; then
        _cap_probe_nat "$IP6T" && CAP_NAT6=1
    fi
    _cap_probe_ipv6 && CAP_IPV6_UP=1

    if [ -x "$BINDIR/dpcore" ]; then
        _cd_out=$("$BINDIR/dpcore" --probe 2>/dev/null)
        case "$_cd_out" in
            *cap_tcp_repair=1*) CAP_TCP_REPAIR=1 ;;
        esac
        case "$_cd_out" in
            *cap_ttl=1*) CAP_TTL=1 ;;
        esac
    fi

    {
        printf 'ipt=%s\n'          "$IPT"
        printf 'ip6t=%s\n'         "$IP6T"
        printf 'cap_ipt=%s\n'      "$CAP_IPT"
        printf 'cap_ip6t=%s\n'     "$CAP_IP6T"
        printf 'cap_nat4=%s\n'     "$CAP_NAT4"
        printf 'cap_nat6=%s\n'     "$CAP_NAT6"
        printf 'cap_owner=%s\n'    "$CAP_OWNER"
        printf 'cap_owner_range=%s\n' "$CAP_OWNER_RANGE"
        printf 'cap_reject=%s\n'   "$CAP_REJECT"
        printf 'cap_nft=%s\n'      "$CAP_NFT"
        printf 'cap_ipv6_up=%s\n'  "$CAP_IPV6_UP"
        printf 'cap_tcp_repair=%s\n' "$CAP_TCP_REPAIR"
        printf 'cap_ttl=%s\n'      "$CAP_TTL"
        printf 'detected=%s\n'     "$(date '+%s')"
    } | atomic_write "$CAPSFILE"

    log_i "capabilities: nat4=$CAP_NAT4 nat6=$CAP_NAT6 owner=$CAP_OWNER" \
          "range=$CAP_OWNER_RANGE reject=$CAP_REJECT ipv6=$CAP_IPV6_UP" \
          "repair=$CAP_TCP_REPAIR"
}

caps_load() {
    if [ ! -f "$CAPSFILE" ]; then
        caps_detect
        return
    fi
    IPT=$(grep -m1 '^ipt=' "$CAPSFILE" | cut -d= -f2-)
    IP6T=$(grep -m1 '^ip6t=' "$CAPSFILE" | cut -d= -f2-)
    for k in cap_ipt cap_ip6t cap_nat4 cap_nat6 cap_owner cap_owner_range \
             cap_reject cap_nft cap_ipv6_up cap_tcp_repair cap_ttl; do
        v=$(grep -m1 "^$k=" "$CAPSFILE" | cut -d= -f2-)
        is_int "$v" || v=0
        case "$k" in
            cap_ipt)         CAP_IPT=$v ;;
            cap_ip6t)        CAP_IP6T=$v ;;
            cap_nat4)        CAP_NAT4=$v ;;
            cap_nat6)        CAP_NAT6=$v ;;
            cap_owner)       CAP_OWNER=$v ;;
            cap_owner_range) CAP_OWNER_RANGE=$v ;;
            cap_reject)      CAP_REJECT=$v ;;
            cap_nft)         CAP_NFT=$v ;;
            cap_ipv6_up)     CAP_IPV6_UP=$v ;;
            cap_tcp_repair)  CAP_TCP_REPAIR=$v ;;
            cap_ttl)         CAP_TTL=$v ;;
        esac
    done
}

# port_listening PORT -> 0 when something is bound on loopback.
# Reads /proc directly because ss and netstat are both optional on Android.
port_listening() {
    is_int "$1" || return 1
    _pl_hex=$(printf '%04X' "$1")
    grep -qi ":$_pl_hex " /proc/net/tcp 2>/dev/null && return 0
    grep -qi ":$_pl_hex " /proc/net/tcp6 2>/dev/null && return 0
    return 1
}

udp_port_listening() {
    is_int "$1" || return 1
    _ul_hex=$(printf '%04X' "$1")
    grep -qi ":$_ul_hex " /proc/net/udp 2>/dev/null && return 0
    grep -qi ":$_ul_hex " /proc/net/udp6 2>/dev/null && return 0
    return 1
}
