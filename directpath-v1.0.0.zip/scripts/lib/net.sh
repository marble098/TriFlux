#!/system/bin/sh
# lib/net.sh - questions about the network we are currently attached to.
#
# Shared by the engine and the supervisor so both reach identical answers.

DNS_FORWARDER_ON=0

# ------------------------------------------------------------- private DNS

# Android's own Private DNS gives encrypted, authenticated resolution. When
# it is switched on we get out of the way completely rather than redirect a
# port 53 the system is no longer using.
private_dns_mode() {
    command -v settings >/dev/null 2>&1 || { printf 'unknown'; return; }
    _pd=$(settings get global private_dns_mode 2>/dev/null | tr -d '\r')
    case "$_pd" in
        hostname|opportunistic|off) printf '%s' "$_pd" ;;
        *) printf 'off' ;;
    esac
}

dns_apply_private() {
    _host=$(cfg_get private_dns_host)
    [ -n "$_host" ] || { log_w "private DNS requested with no hostname set"; return 1; }
    is_domain "$_host" || { log_w "invalid private DNS hostname"; return 1; }
    command -v settings >/dev/null 2>&1 || return 1

    if [ ! -f "$STATEDIR/private_dns.bak" ]; then
        {
            printf 'mode=%s\n' "$(settings get global private_dns_mode 2>/dev/null | tr -d '\r')"
            printf 'host=%s\n' "$(settings get global private_dns_specifier 2>/dev/null | tr -d '\r')"
        } | atomic_write "$STATEDIR/private_dns.bak"
    fi
    settings put global private_dns_specifier "$_host" 2>/dev/null
    settings put global private_dns_mode hostname 2>/dev/null
    log_i "Private DNS pointed at $_host"
}

dns_restore_private() {
    [ -f "$STATEDIR/private_dns.bak" ] || return 0
    command -v settings >/dev/null 2>&1 || return 0
    _m=$(grep -m1 '^mode=' "$STATEDIR/private_dns.bak" | cut -d= -f2-)
    _h=$(grep -m1 '^host=' "$STATEDIR/private_dns.bak" | cut -d= -f2-)
    case "$_m" in
        off|opportunistic|hostname) settings put global private_dns_mode "$_m" 2>/dev/null ;;
        *) settings put global private_dns_mode off 2>/dev/null ;;
    esac
    if [ -n "$_h" ] && [ "$_h" != null ] && is_domain "$_h"; then
        settings put global private_dns_specifier "$_h" 2>/dev/null
    fi
    rm -f "$STATEDIR/private_dns.bak"
    log_i "Private DNS setting restored"
}

# dns_decide sets DNS_FORWARDER_ON for the current configuration and network.
dns_decide() {
    case "$(cfg_get dns_mode)" in
        off)         DNS_FORWARDER_ON=0 ;;
        forwarder)   DNS_FORWARDER_ON=1 ;;
        private_dns) dns_apply_private; DNS_FORWARDER_ON=0 ;;
        *)
            if [ "$(private_dns_mode)" = hostname ]; then
                DNS_FORWARDER_ON=0
            else
                DNS_FORWARDER_ON=1
            fi ;;
    esac
    # The daemon raises this flag when every upstream is unreachable. Name
    # resolution matters more than the repair, so we yield.
    [ -f "$STATEDIR/dns_unhealthy" ] && DNS_FORWARDER_ON=0
    export DNS_FORWARDER_ON
}

# ----------------------------------------------------------- captive portal

# The signal differs across Android versions and OEM builds, so we look for
# several shapes and treat "cannot tell" as "no portal". Refusing to run on
# an ambiguous answer would be worse than the occasional missed portal,
# which the user can resolve with the master switch in one tap.
portal_detected() {
    command -v dumpsys >/dev/null 2>&1 || return 1
    _dp=$(dumpsys connectivity 2>/dev/null | head -n 200)
    [ -n "$_dp" ] || return 1
    case "$_dp" in
        *CAPTIVE_PORTAL*)                       return 0 ;;
        *captivePortalValidationPending=true*)  return 0 ;;
        *"Validated: false"*)                   return 0 ;;
    esac
    return 1
}

# ------------------------------------------------------ network fingerprint

# A cheap hash of "which network am I on". Default route plus global
# addresses changes on every Wi-Fi/mobile transition, tethering change and
# roaming event, which is exactly when the policy needs revisiting.
net_signature() {
    if command -v ip >/dev/null 2>&1; then
        {
            ip route show default 2>/dev/null | head -n 2
            ip -o addr show scope global 2>/dev/null | awk '{print $2, $4}'
        } | cksum 2>/dev/null | cut -d' ' -f1
    else
        printf '0'
    fi
}

net_signature_store() {
    printf '%s\n' "$(net_signature)" | atomic_write "$NETSIGFILE"
}

net_signature_changed() {
    _cur=$(net_signature)
    _old=$(cat "$NETSIGFILE" 2>/dev/null)
    [ "$_cur" != "$_old" ]
}
