#!/system/bin/sh
# lib/config.sh - the configuration model.
#
# The user-facing config is a flat key=value file. It is never sourced.
# Sourcing would let a corrupted or hostile file execute code with root, so
# every key is read with a grep/cut pair and then range checked against an
# allowlist. Unknown keys are dropped on write.

# ------------------------------------------------------- schema and defaults

# Order matters only for readability of the written file.
CFG_KEYS="enabled mode strategy scope app_mode groups dns_mode dns_upstream \
private_dns_host ipv6_mode block_quic tethering log_level start_delay \
watchdog_interval proxy_port dns_port split_delay_us fake_ttl adaptive \
telemetry"

cfg_default() {
    case "$1" in
        enabled)          printf '1' ;;
        mode)             printf 'auto' ;;
        strategy)         printf 'split' ;;
        scope)            printf 'rules' ;;
        app_mode)         printf 'selected' ;;
        groups)           printf 'social,video,messaging,developer,ai,news' ;;
        dns_mode)         printf 'auto' ;;
        dns_upstream)     printf '1.1.1.1,9.9.9.9,8.8.8.8' ;;
        private_dns_host) printf '' ;;
        ipv6_mode)        printf 'auto' ;;
        block_quic)       printf 'auto' ;;
        tethering)        printf '0' ;;
        log_level)        printf 'info' ;;
        start_delay)      printf '25' ;;
        watchdog_interval) printf '30' ;;
        proxy_port)       printf '9451' ;;
        dns_port)         printf '9453' ;;
        split_delay_us)   printf '0' ;;
        fake_ttl)         printf '4' ;;
        adaptive)         printf '1' ;;
        telemetry)        printf '0' ;;
        *)                printf '' ;;
    esac
}

# cfg_valid KEY VALUE -> 0 when the value is acceptable
cfg_valid() {
    _k=$1; _v=$2
    case "$_k" in
        enabled|tethering|adaptive|telemetry)
            one_of "$_v" 0 1 ;;
        mode)
            one_of "$_v" auto compat performance aggressive custom ;;
        strategy)
            one_of "$_v" none split split-multi disorder fake oob ;;
        scope)
            one_of "$_v" rules all ;;
        app_mode)
            one_of "$_v" all selected excluded ;;
        groups)
            case "$_v" in
                ''|*[!a-z,]*) return 1 ;;
                *) [ "${#_v}" -le 200 ] ;;
            esac ;;
        dns_mode)
            one_of "$_v" auto forwarder private_dns off ;;
        dns_upstream)
            case "$_v" in
                ''|*[!0-9a-fA-F.:,]*) return 1 ;;
                *) [ "${#_v}" -le 160 ] ;;
            esac ;;
        private_dns_host)
            [ -z "$_v" ] && return 0
            is_domain "$_v" ;;
        ipv6_mode)
            one_of "$_v" auto prefer4 prefer6 off ;;
        block_quic)
            one_of "$_v" auto on off ;;
        log_level)
            one_of "$_v" error warn info debug ;;
        start_delay)       in_range "$_v" 0 300 ;;
        watchdog_interval) in_range "$_v" 15 600 ;;
        proxy_port|dns_port) in_range "$_v" 1024 65535 ;;
        split_delay_us)    in_range "$_v" 0 50000 ;;
        fake_ttl)          in_range "$_v" 1 16 ;;
        *) return 1 ;;
    esac
}

# cfg_get KEY -> value (falls back to the default when missing or invalid)
cfg_get() {
    _cg_k=$1
    _cg_v=$(grep -m1 "^${_cg_k}=" "$CONF" 2>/dev/null | cut -d= -f2- | tr -d '\r')
    if [ -n "$_cg_v" ] && cfg_valid "$_cg_k" "$_cg_v"; then
        printf '%s' "$_cg_v"
    elif [ "$_cg_v" = "" ] && grep -q "^${_cg_k}=$" "$CONF" 2>/dev/null &&
         cfg_valid "$_cg_k" ""; then
        printf ''
    else
        cfg_default "$_cg_k"
    fi
}

# cfg_set KEY VALUE -> rewrites the file atomically, rejecting bad input
cfg_set() {
    _cs_k=$1; _cs_v=$2
    one_of "$_cs_k" $CFG_KEYS || { log_w "rejected unknown key $_cs_k"; return 1; }
    cfg_valid "$_cs_k" "$_cs_v" || { log_w "rejected value for $_cs_k"; return 1; }

    _cs_tmp=$RUNDIR/cfg.$$
    : > "$_cs_tmp"
    for _cs_key in $CFG_KEYS; do
        if [ "$_cs_key" = "$_cs_k" ]; then
            printf '%s=%s\n' "$_cs_key" "$_cs_v" >> "$_cs_tmp"
        else
            printf '%s=%s\n' "$_cs_key" "$(cfg_get "$_cs_key")" >> "$_cs_tmp"
        fi
    done
    cat "$_cs_tmp" | atomic_write "$CONF"
    rm -f "$_cs_tmp"
    log_i "config $_cs_k=$_cs_v"
    return 0
}

cfg_init() {
    ensure_tree
    [ -f "$CONF" ] && return 0
    _ci_tmp=$RUNDIR/cfg.init.$$
    : > "$_ci_tmp"
    for _ci_k in $CFG_KEYS; do
        printf '%s=%s\n' "$_ci_k" "$(cfg_default "$_ci_k")" >> "$_ci_tmp"
    done
    cat "$_ci_tmp" | atomic_write "$CONF"
    rm -f "$_ci_tmp"
    log_i "created default configuration"
}

cfg_reset() {
    rm -f "$CONF"
    cfg_init
}

# ------------------------------------------------------------------- presets
#
# A mode is a named point in the tradeoff space between compatibility and
# effectiveness. Resolving it here keeps the modes out of the daemon and
# means "custom" is simply "do not resolve".

RES_STRATEGY=split
RES_SCOPE=rules
RES_ADAPTIVE=1
RES_QUIC=off
RES_DELAY=0
RES_IPV6=auto

cfg_resolve_mode() {
    _m=$(cfg_get mode)
    RES_IPV6=$(cfg_get ipv6_mode)
    case "$_m" in
        compat)
            RES_STRATEGY=split;    RES_SCOPE=rules; RES_ADAPTIVE=0
            RES_QUIC=off;          RES_DELAY=0
            [ "$RES_IPV6" = auto ] && RES_IPV6=prefer4
            ;;
        performance)
            RES_STRATEGY=split;    RES_SCOPE=rules; RES_ADAPTIVE=1
            RES_QUIC=on;           RES_DELAY=0
            ;;
        aggressive)
            RES_STRATEGY=disorder; RES_SCOPE=all;   RES_ADAPTIVE=1
            RES_QUIC=on;           RES_DELAY=1000
            ;;
        custom)
            RES_STRATEGY=$(cfg_get strategy)
            RES_SCOPE=$(cfg_get scope)
            RES_ADAPTIVE=$(cfg_get adaptive)
            RES_DELAY=$(cfg_get split_delay_us)
            case "$(cfg_get block_quic)" in
                on) RES_QUIC=on ;;
                off) RES_QUIC=off ;;
                *) RES_QUIC=on ;;
            esac
            ;;
        *)  # auto
            RES_STRATEGY=split;    RES_SCOPE=rules; RES_ADAPTIVE=1
            RES_QUIC=on;           RES_DELAY=0
            ;;
    esac

    # An explicit block_quic setting always wins over the preset.
    case "$(cfg_get block_quic)" in
        on)  RES_QUIC=on ;;
        off) RES_QUIC=off ;;
    esac
}

# ------------------------------------------------- daemon config generation

# Produces dpcore.conf from the resolved user settings. The daemon reads
# only this file, so the daemon never has to know what a "mode" is.
cfg_write_core() {
    cfg_resolve_mode
    _lvl=$(cfg_get log_level)

    {
        printf '# generated by directpath, do not edit by hand\n'
        printf 'rundir=%s\n'   "$DATA"
        printf 'ruledir=%s\n'  "$RULEDIR"
        printf 'logfile=%s\n'  "$LOGDIR/dpcore.log"
        printf 'loglevel=%s\n' "$_lvl"
        printf 'log_max_bytes=196608\n'
        printf 'proxy_port=%s\n' "$(cfg_get proxy_port)"
        printf 'dns_port=%s\n'   "$(cfg_get dns_port)"
        printf 'proxy_enabled=1\n'
        printf 'dns_enabled=%s\n' "$DNS_FORWARDER_ON"
        printf 'strategy=%s\n'    "$RES_STRATEGY"
        printf 'split_pos=3\n'
        printf 'fake_ttl=%s\n'    "$(cfg_get fake_ttl)"
        printf 'split_delay_us=%s\n' "$RES_DELAY"
        printf 'scope_all=%s\n'   "$([ "$RES_SCOPE" = all ] && printf 1 || printf 0)"
        printf 'adaptive=%s\n'    "$RES_ADAPTIVE"
        printf 'dns_upstream=%s\n' "$(cfg_get dns_upstream)"
        printf 'dns_desync=1\n'
        printf 'dns_cache_ttl_min=60\n'
        printf 'dns_cache_ttl_max=3600\n'
    } | atomic_write "$COREONF"

    printf '%s\n' "$(cfg_get groups)" | atomic_write "$GROUPFILE"
    chmod 600 "$COREONF" 2>/dev/null
}

# ------------------------------------------------------------ known good copy

cfg_save_good() {
    [ -f "$CONF" ] || return 1
    cp -f "$CONF" "$BACKUPDIR/directpath.conf.good" 2>/dev/null
    date '+%Y-%m-%d %H:%M:%S' > "$BACKUPDIR/good.stamp" 2>/dev/null
    log_i "saved last-known-good configuration"
}

cfg_restore_good() {
    [ -f "$BACKUPDIR/directpath.conf.good" ] || return 1
    cp -f "$BACKUPDIR/directpath.conf.good" "$CONF" 2>/dev/null || return 1
    log_w "restored last-known-good configuration"
    return 0
}
