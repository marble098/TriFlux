#!/system/bin/sh
# lib/apps.sh - turn package names into the UIDs netfilter can match on.
#
# /data/system/packages.list is authoritative and costs one file read, so we
# use it first and only fall back to `pm` when it is unreadable. Android
# gives the same app a different UID in every profile (appId + user * 100000),
# so a selection has to be expanded across the users that exist on the device
# or the rules silently miss work profiles and second spaces.

PKGLIST=/data/system/packages.list
SYSPKGS=$STATEDIR/syspkgs

# ------------------------------------------------------------------- users

apps_users() {
    if [ -d /data/user ]; then
        for d in /data/user/*; do
            u=$(basename "$d" 2>/dev/null)
            is_int "$u" && printf '%s\n' "$u"
        done
    else
        printf '0\n'
    fi
}

# ------------------------------------------------------------- appid lookup

# apps_appid PACKAGE -> base uid, empty when unknown
apps_appid() {
    is_pkgname "$1" || return 1
    if [ -r "$PKGLIST" ]; then
        _aa=$(grep -m1 "^$1 " "$PKGLIST" 2>/dev/null | cut -d' ' -f2)
        if is_int "$_aa"; then printf '%s' "$_aa"; return 0; fi
    fi
    if command -v pm >/dev/null 2>&1; then
        _aa=$(pm list packages -U 2>/dev/null | grep -m1 "^package:$1 " |
              sed -n 's/.*uid://p')
        if is_int "$_aa"; then printf '%s' "$_aa"; return 0; fi
    fi
    return 1
}

# Expand one appid into every per-user UID that exists on this device.
apps_expand_uid() {
    _ae_base=$1
    is_int "$_ae_base" || return 1
    # Shared system UIDs below 10000 are not per-user.
    if [ "$_ae_base" -lt 10000 ]; then
        printf '%s\n' "$_ae_base"
        return 0
    fi
    for u in $(apps_users); do
        printf '%s\n' "$((_ae_base % 100000 + u * 100000))"
    done
}

# --------------------------------------------------------------- selection

apps_selected_packages() {
    [ -f "$APPLIST" ] || return 0
    while IFS= read -r line; do
        line=$(printf '%s' "$line" | tr -d '\r \t')
        [ -z "$line" ] && continue
        case "$line" in \#*) continue ;; esac
        is_pkgname "$line" || continue
        printf '%s\n' "$line"
    done < "$APPLIST"
}

# apps_uid_set -> one UID per line for the current app_mode.
# Prints nothing for "all" and "excluded"; the caller reads apps_mode()
# and builds range rules instead.
apps_uid_set() {
    for p in $(apps_selected_packages); do
        base=$(apps_appid "$p") || { log_d "unknown package $p"; continue; }
        apps_expand_uid "$base"
    done | sort -u
}

apps_count() {
    apps_selected_packages | wc -l | tr -d ' '
}

# ---------------------------------------------------------- listing for UI

_apps_refresh_syspkgs() {
    _now=$(date '+%s')
    if [ -f "$SYSPKGS" ]; then
        _age=$(( _now - $(stat -c %Y "$SYSPKGS" 2>/dev/null || echo 0) ))
        [ "$_age" -lt 86400 ] && return 0
    fi
    command -v pm >/dev/null 2>&1 || { : > "$SYSPKGS"; return 0; }
    pm list packages -s 2>/dev/null | sed 's/^package://' | sort |
        atomic_write "$SYSPKGS"
}

# Emits "package<TAB>uid<TAB>is_system<TAB>is_selected", sorted with
# user-installed apps first because that is what people are looking for.
apps_list() {
    _apps_refresh_syspkgs
    _sel=$RUNDIR/sel.$$
    apps_selected_packages | sort > "$_sel"

    if [ -r "$PKGLIST" ]; then
        cut -d' ' -f1,2 "$PKGLIST" 2>/dev/null
    elif command -v pm >/dev/null 2>&1; then
        pm list packages -U 2>/dev/null |
            sed -n 's/^package:\([^ ]*\) uid:\([0-9]*\)$/\1 \2/p'
    fi | sort | while read -r pkg uid; do
        is_pkgname "$pkg" || continue
        is_int "$uid" || continue
        sys=0
        [ -s "$SYSPKGS" ] && grep -qx "$pkg" "$SYSPKGS" 2>/dev/null && sys=1
        chosen=0
        grep -qx "$pkg" "$_sel" 2>/dev/null && chosen=1
        printf '%s\t%s\t%s\t%s\n' "$pkg" "$uid" "$sys" "$chosen"
    done | sort -t"$(printf '\t')" -k3,3n -k1,1

    rm -f "$_sel"
}

# ------------------------------------------------------------- modification

apps_add() {
    is_pkgname "$1" || return 1
    ensure_tree
    [ -f "$APPLIST" ] || : > "$APPLIST"
    grep -qx "$1" "$APPLIST" 2>/dev/null && return 0
    { cat "$APPLIST" 2>/dev/null; printf '%s\n' "$1"; } |
        grep -v '^$' | sort -u | atomic_write "$APPLIST"
    log_i "app added: $1"
}

apps_remove() {
    is_pkgname "$1" || return 1
    [ -f "$APPLIST" ] || return 0
    grep -vx "$1" "$APPLIST" 2>/dev/null | atomic_write "$APPLIST"
    log_i "app removed: $1"
}

# apps_set_profile NAME - replaces the selection with a curated preset.
# The presets name packages, not UIDs, so they survive reinstalls.
apps_set_profile() {
    case "$1" in
        social)
            set -- com.instagram.android com.twitter.android com.zhiliaoapp.musically \
                   com.reddit.frontpage com.facebook.katana com.linkedin.android \
                   com.pinterest tv.twitch.android.app ;;
        video)
            set -- com.google.android.youtube com.google.android.apps.youtube.music \
                   tv.twitch.android.app com.netflix.mediaclient com.vimeo.android.videoapp ;;
        messaging)
            set -- org.telegram.messenger com.discord com.whatsapp org.thoughtcrime.securesms \
                   com.viber.voip messenger.messenger ;;
        developer)
            set -- com.github.android com.termux com.google.android.apps.docs \
                   com.stackexchange.marvin ;;
        ai)
            set -- com.anthropic.claude com.openai.chatgpt com.google.android.apps.bard \
                   ai.perplexity.app.android ;;
        browsers)
            set -- com.android.chrome org.mozilla.firefox com.brave.browser \
                   com.microsoft.emmx com.opera.browser com.duckduckgo.mobile.android ;;
        everything)
            cfg_set app_mode all
            return 0 ;;
        clear)
            : | atomic_write "$APPLIST"
            log_i "app selection cleared"
            return 0 ;;
        *)  return 1 ;;
    esac

    # Only add what is genuinely installed, so the list stays meaningful.
    _added=0
    for p in "$@"; do
        if apps_appid "$p" >/dev/null 2>&1; then
            apps_add "$p"
            _added=$((_added + 1))
        fi
    done
    log_i "profile applied, $_added packages matched"
    return 0
}
