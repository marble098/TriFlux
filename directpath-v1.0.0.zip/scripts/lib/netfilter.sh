#!/system/bin/sh
# lib/netfilter.sh - build, verify and tear down the redirect rules.
#
# Design rules that are not negotiable:
#
#   1. Everything we add lives inside chains named DP_*. We never write into
#      Android's own chains beyond a single jump, and we never run
#      iptables-restore against a whole table. netd owns those tables and
#      rewrites them constantly; fighting it is how modules brick networking.
#
#   2. Teardown is unconditional and idempotent. nf_down() can be called at
#      any moment, twice, from a crash handler, and always leaves the device
#      in stock state.
#
#   3. Every command's exit status is checked. A partially applied ruleset is
#      worse than none, so any failure during nf_up() triggers an immediate
#      nf_down() and the engine reports the failure instead of pretending.

NAT_CHAIN=DP_NAT_OUT
TCP_CHAIN=DP_TCP
DNS_CHAIN=DP_DNS
FLT_CHAIN=DP_FLT_OUT
V6_CHAIN=DP_V6BLOCK

NF_ERRORS=0

PRIVATE_V4="0.0.0.0/8 10.0.0.0/8 100.64.0.0/10 127.0.0.0/8 169.254.0.0/16 \
172.16.0.0/12 192.168.0.0/16 224.0.0.0/4 240.0.0.0/4"
PRIVATE_V6="::1/128 fc00::/7 fe80::/10 ff00::/8"

# UIDs that must keep stock networking even in "all apps" mode on kernels
# without uid-range matching: connectivity probes, telephony and the
# provisioning stack live here and breaking them breaks the phone.
CORE_UIDS="1000 1001 1002 1010 1013 1019 1021 1041 1047 1073 9999"

# ------------------------------------------------------------------ runner

# nf_run BIN args... - run a netfilter command, remember failures.
nf_run() {
    if "$@" >/dev/null 2>&1; then
        return 0
    fi
    NF_ERRORS=$((NF_ERRORS + 1))
    log_w "rule failed: $*"
    return 1
}

# Quiet variant for teardown, where "already gone" is the expected case.
nf_try() { "$@" >/dev/null 2>&1; return 0; }

# ------------------------------------------------------------- chain setup

_nf_make_chains() {
    _bin=$1
    nf_run "$_bin" -t nat -N "$NAT_CHAIN" || return 1
    nf_run "$_bin" -t nat -N "$TCP_CHAIN" || return 1
    if [ "$DNS_FORWARDER_ON" = 1 ]; then
        nf_run "$_bin" -t nat -N "$DNS_CHAIN" || return 1
    fi
    return 0
}

# ------------------------------------------------------- uid matching rules

# _nf_uid_rules BIN CHAIN PORT
# Fills a leaf chain with the per-UID redirects for the active app mode.
_nf_uid_rules() {
    _bin=$1; _chain=$2; _port=$3
    _mode=$(cfg_get app_mode)

    case "$_mode" in
        selected)
            _n=0
            for uid in $(apps_uid_set); do
                is_int "$uid" || continue
                nf_run "$_bin" -t nat -A "$_chain" -m owner --uid-owner "$uid" \
                    -j REDIRECT --to-ports "$_port" && _n=$((_n + 1))
            done
            [ "$_n" = 0 ] && log_w "no applications resolved for chain $_chain"
            ;;
        excluded)
            for uid in $(apps_uid_set); do
                is_int "$uid" || continue
                nf_run "$_bin" -t nat -A "$_chain" -m owner --uid-owner "$uid" \
                    -j RETURN
            done
            _nf_catch_all "$_bin" "$_chain" "$_port"
            ;;
        all)
            _nf_catch_all "$_bin" "$_chain" "$_port"
            ;;
    esac
    return 0
}

_nf_catch_all() {
    _bin=$1; _chain=$2; _port=$3

    if [ "$CAP_OWNER_RANGE" = 1 ]; then
        # One rule covers every installed app across every profile.
        nf_run "$_bin" -t nat -A "$_chain" -m owner --uid-owner 10000-4294967294 \
            -j REDIRECT --to-ports "$_port"
    else
        # No range support: protect the platform UIDs by name, then catch
        # everything else. Less precise, but never breaks telephony.
        for uid in $CORE_UIDS; do
            nf_run "$_bin" -t nat -A "$_chain" -m owner --uid-owner "$uid" -j RETURN
        done
        nf_run "$_bin" -t nat -A "$_chain" -j REDIRECT --to-ports "$_port"
    fi
}

# ---------------------------------------------------------- main nat chain

_nf_build_nat() {
    _bin=$1; _fam=$2

    # Loopback and our own traffic never enter the relay. The uid 0 return
    # is what stops dpcore's upstream connections looping back into itself.
    nf_run "$_bin" -t nat -A "$NAT_CHAIN" -o lo -j RETURN
    nf_run "$_bin" -t nat -A "$NAT_CHAIN" -m owner --uid-owner 0 -j RETURN

    # DNS first: resolvers usually live on a private address, so this has to
    # precede the private-destination exemptions below.
    if [ "$DNS_FORWARDER_ON" = 1 ]; then
        nf_run "$_bin" -t nat -A "$NAT_CHAIN" -p udp --dport 53 -j "$DNS_CHAIN"
    fi

    if [ "$_fam" = 4 ]; then
        for net in $PRIVATE_V4; do
            nf_run "$_bin" -t nat -A "$NAT_CHAIN" -d "$net" -j RETURN
        done
    else
        for net in $PRIVATE_V6; do
            nf_run "$_bin" -t nat -A "$NAT_CHAIN" -d "$net" -j RETURN
        done
    fi

    nf_run "$_bin" -t nat -A "$NAT_CHAIN" -p tcp --dport 443 -j "$TCP_CHAIN"
    nf_run "$_bin" -t nat -A "$NAT_CHAIN" -p tcp --dport 80  -j "$TCP_CHAIN"
}

# -------------------------------------------------------------- QUIC block

# QUIC rides UDP and carries its own encrypted transport, so the relay
# cannot help it. Refusing it makes browsers and the YouTube app fall back
# to TLS over TCP within a few hundred milliseconds, where we can help.
# REJECT is used in preference to DROP precisely so the fallback is instant.
_nf_quic_block() {
    _bin=$1

    nf_run "$_bin" -t filter -N "$FLT_CHAIN" || return 1
    nf_run "$_bin" -t filter -A "$FLT_CHAIN" -m owner --uid-owner 0 -j RETURN

    if [ "$CAP_REJECT" = 1 ]; then
        _act="REJECT --reject-with icmp-port-unreachable"
        [ "$_bin" = "$IP6T" ] && _act="REJECT --reject-with icmp6-port-unreachable"
    else
        _act="DROP"
    fi

    _mode=$(cfg_get app_mode)
    case "$_mode" in
        selected)
            for uid in $(apps_uid_set); do
                is_int "$uid" || continue
                nf_run "$_bin" -t filter -A "$FLT_CHAIN" -p udp --dport 443 \
                    -m owner --uid-owner "$uid" -j $_act
            done ;;
        excluded)
            for uid in $(apps_uid_set); do
                is_int "$uid" || continue
                nf_run "$_bin" -t filter -A "$FLT_CHAIN" -m owner --uid-owner "$uid" \
                    -j RETURN
            done
            nf_run "$_bin" -t filter -A "$FLT_CHAIN" -p udp --dport 443 -j $_act ;;
        all)
            if [ "$CAP_OWNER_RANGE" = 1 ]; then
                nf_run "$_bin" -t filter -A "$FLT_CHAIN" -p udp --dport 443 \
                    -m owner --uid-owner 10000-4294967294 -j $_act
            else
                for uid in $CORE_UIDS; do
                    nf_run "$_bin" -t filter -A "$FLT_CHAIN" -m owner \
                        --uid-owner "$uid" -j RETURN
                done
                nf_run "$_bin" -t filter -A "$FLT_CHAIN" -p udp --dport 443 -j $_act
            fi ;;
    esac

    nf_run "$_bin" -t filter -I OUTPUT 1 -j "$FLT_CHAIN"
}

# --------------------------------------------------------- IPv6 preference

# When the relay cannot service IPv6 (no NAT6 in this kernel) but IPv6 is up,
# selected apps would quietly bypass every repair over v6. Refusing their v6
# web traffic pushes them onto v4 where the relay works. This is narrow on
# purpose: only TCP 80/443, only selected apps, never a global v6 shutdown.
_nf_prefer_v4() {
    [ -n "$IP6T" ] || return 0
    [ "$CAP_IP6T" = 1 ] || return 0

    nf_run "$IP6T" -t filter -N "$V6_CHAIN" || return 1
    nf_run "$IP6T" -t filter -A "$V6_CHAIN" -m owner --uid-owner 0 -j RETURN

    if [ "$CAP_REJECT" = 1 ]; then
        _act6="REJECT --reject-with icmp6-port-unreachable"
    else
        _act6="DROP"
    fi

    case "$(cfg_get app_mode)" in
        selected)
            for uid in $(apps_uid_set); do
                is_int "$uid" || continue
                nf_run "$IP6T" -t filter -A "$V6_CHAIN" -p tcp -m multiport \
                    --dports 80,443 -m owner --uid-owner "$uid" -j $_act6 ||
                {
                    nf_run "$IP6T" -t filter -A "$V6_CHAIN" -p tcp --dport 443 \
                        -m owner --uid-owner "$uid" -j $_act6
                    nf_run "$IP6T" -t filter -A "$V6_CHAIN" -p tcp --dport 80 \
                        -m owner --uid-owner "$uid" -j $_act6
                }
            done ;;
        *)
            # In all/excluded modes a blanket v6 refusal is too blunt, so we
            # leave IPv6 alone and accept that some traffic bypasses us.
            log_i "IPv6 preference skipped in $(cfg_get app_mode) mode"
            nf_try "$IP6T" -t filter -X "$V6_CHAIN"
            return 0 ;;
    esac

    nf_run "$IP6T" -t filter -I OUTPUT 1 -j "$V6_CHAIN"
}

# ------------------------------------------------------------------- apply

# nf_up - returns 0 only when the complete ruleset is in place.
nf_up() {
    NF_ERRORS=0
    caps_load
    cfg_resolve_mode

    if [ "$CAP_IPT" != 1 ] || [ "$CAP_NAT4" != 1 ]; then
        log_e "kernel has no usable IPv4 nat/REDIRECT, cannot proceed"
        return 1
    fi
    if [ "$CAP_OWNER" != 1 ] && [ "$(cfg_get app_mode)" != all ]; then
        log_w "no owner match in this kernel, falling back to all-apps mode"
        cfg_set app_mode all
    fi

    nf_down                      # start from a known clean slate

    _nf_make_chains "$IPT" || { nf_down; return 1; }
    _nf_uid_rules "$IPT" "$TCP_CHAIN" "$(cfg_get proxy_port)"
    [ "$DNS_FORWARDER_ON" = 1 ] &&
        _nf_uid_rules "$IPT" "$DNS_CHAIN" "$(cfg_get dns_port)"
    _nf_build_nat "$IPT" 4
    nf_run "$IPT" -t nat -I OUTPUT 1 -j "$NAT_CHAIN"
    printf 'v4\n' >> "$APPLIEDFILE"

    # IPv6: mirror the relay when the kernel can NAT it, otherwise steer
    # selected apps back to IPv4 rather than let them leak past us.
    case "$RES_IPV6" in
        off)
            log_i "IPv6 handling disabled by configuration" ;;
        prefer6|auto)
            if [ "$CAP_NAT6" = 1 ] && [ "$CAP_IP6T" = 1 ]; then
                _nf_make_chains "$IP6T"
                _nf_uid_rules "$IP6T" "$TCP_CHAIN" "$(cfg_get proxy_port)"
                [ "$DNS_FORWARDER_ON" = 1 ] &&
                    _nf_uid_rules "$IP6T" "$DNS_CHAIN" "$(cfg_get dns_port)"
                _nf_build_nat "$IP6T" 6
                nf_run "$IP6T" -t nat -I OUTPUT 1 -j "$NAT_CHAIN"
                printf 'v6nat\n' >> "$APPLIEDFILE"
            elif [ "$CAP_IPV6_UP" = 1 ]; then
                log_i "no IPv6 nat available, steering selected apps to IPv4"
                _nf_prefer_v4 && printf 'v6block\n' >> "$APPLIEDFILE"
            fi ;;
        prefer4)
            if [ "$CAP_IPV6_UP" = 1 ]; then
                _nf_prefer_v4 && printf 'v6block\n' >> "$APPLIEDFILE"
            fi ;;
    esac

    if [ "$RES_QUIC" = on ]; then
        _nf_quic_block "$IPT" && printf 'quic4\n' >> "$APPLIEDFILE"
        if [ "$CAP_IP6T" = 1 ]; then
            _nf_quic_block "$IP6T" && printf 'quic6\n' >> "$APPLIEDFILE"
        fi
    fi

    if ! nf_verify; then
        log_e "verification failed after apply, rolling back"
        nf_down
        return 1
    fi
    if [ "$NF_ERRORS" -gt 0 ]; then
        log_w "$NF_ERRORS individual rules were rejected by the kernel"
    fi
    log_i "rules applied (mode=$(cfg_get app_mode) strategy=$RES_STRATEGY quic=$RES_QUIC)"
    return 0
}

# nf_verify - the jump into our chain is the one thing that must exist.
nf_verify() {
    [ -n "$IPT" ] || return 1
    "$IPT" -t nat -C OUTPUT -j "$NAT_CHAIN" >/dev/null 2>&1 || return 1
    return 0
}

nf_active() { nf_verify; }

# ------------------------------------------------------------------ remove

_nf_drop_family() {
    _bin=$1
    [ -n "$_bin" ] || return 0

    # Remove every copy of the jump, in case a previous run left duplicates.
    _n=0
    while "$_bin" -t nat -C OUTPUT -j "$NAT_CHAIN" >/dev/null 2>&1; do
        "$_bin" -t nat -D OUTPUT -j "$NAT_CHAIN" >/dev/null 2>&1 || break
        _n=$((_n + 1))
        [ "$_n" -gt 8 ] && break
    done
    _n=0
    while "$_bin" -t filter -C OUTPUT -j "$FLT_CHAIN" >/dev/null 2>&1; do
        "$_bin" -t filter -D OUTPUT -j "$FLT_CHAIN" >/dev/null 2>&1 || break
        _n=$((_n + 1))
        [ "$_n" -gt 8 ] && break
    done
    _n=0
    while "$_bin" -t filter -C OUTPUT -j "$V6_CHAIN" >/dev/null 2>&1; do
        "$_bin" -t filter -D OUTPUT -j "$V6_CHAIN" >/dev/null 2>&1 || break
        _n=$((_n + 1))
        [ "$_n" -gt 8 ] && break
    done

    for ch in "$NAT_CHAIN" "$TCP_CHAIN" "$DNS_CHAIN"; do
        nf_try "$_bin" -t nat -F "$ch"
        nf_try "$_bin" -t nat -X "$ch"
    done
    for ch in "$FLT_CHAIN" "$V6_CHAIN"; do
        nf_try "$_bin" -t filter -F "$ch"
        nf_try "$_bin" -t filter -X "$ch"
    done
}

# nf_down - always succeeds, always safe to repeat.
nf_down() {
    caps_load
    [ -n "$IPT" ]  && _nf_drop_family "$IPT"
    [ -n "$IP6T" ] && _nf_drop_family "$IP6T"

    # Last resort for a machine where caps were never detected.
    if [ -z "$IPT" ]; then
        for b in /system/bin/iptables /system/bin/ip6tables; do
            [ -x "$b" ] && _nf_drop_family "$b"
        done
    fi
    rm -f "$APPLIEDFILE"
    return 0
}

# Remove only the DNS redirect, leaving the TCP relay in place. Used when
# the forwarder reports its upstreams are unreachable: better to lose the
# DNS repair than to lose name resolution.
nf_drop_dns() {
    caps_load
    for b in "$IPT" "$IP6T"; do
        [ -n "$b" ] || continue
        nf_try "$b" -t nat -D "$NAT_CHAIN" -p udp --dport 53 -j "$DNS_CHAIN"
        nf_try "$b" -t nat -F "$DNS_CHAIN"
    done
    log_w "DNS redirect removed, system resolver back in charge"
}
