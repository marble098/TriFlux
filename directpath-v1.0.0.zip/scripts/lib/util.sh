#!/system/bin/sh
# lib/util.sh - paths, logging, locking, atomic writes, input validation.
#
# Sourced by every other script. POSIX sh only: this has to run under mksh
# on stock Android and under busybox ash on custom ROMs, so no arrays, no
# [[ ]], no echo -e, no process substitution.

MODID=directpath
MODDIR=/data/adb/modules/$MODID
DATA=/data/adb/$MODID

CONFDIR=$DATA/config
RULEDIR=$DATA/rules
STATEDIR=$DATA/state
RUNDIR=$DATA/run
LOGDIR=$DATA/log
BACKUPDIR=$DATA/backup
BINDIR=$DATA/bin

CONF=$CONFDIR/directpath.conf
COREONF=$CONFDIR/dpcore.conf
APPLIST=$CONFDIR/apps.list
GROUPFILE=$CONFDIR/groups.active

ENGINE_LOG=$LOGDIR/engine.log
STATUSFILE=$RUNDIR/status
PIDFILE=$RUNDIR/dpcore.pid
STATSFILE=$RUNDIR/dpcore.stats
CAPSFILE=$STATEDIR/caps
APPLIEDFILE=$STATEDIR/applied
NETSIGFILE=$STATEDIR/netsig
BOOTCOUNT=$STATEDIR/boot_count

LOG_MAX=196608          # bytes, rotated once -> 384 KiB ceiling

umask 077

# ---------------------------------------------------------------- logging

LOG_LEVEL_NUM=3         # 1 error 2 warn 3 info 4 debug

_log_rotate() {
    [ -f "$ENGINE_LOG" ] || return 0
    size=$(stat -c %s "$ENGINE_LOG" 2>/dev/null || echo 0)
    [ "$size" -lt "$LOG_MAX" ] 2>/dev/null && return 0
    mv -f "$ENGINE_LOG" "$ENGINE_LOG.1" 2>/dev/null
    : > "$ENGINE_LOG"
    chmod 600 "$ENGINE_LOG" 2>/dev/null
}

_log() {
    lvl=$1; num=$2; shift 2
    [ "$num" -le "$LOG_LEVEL_NUM" ] || return 0
    [ -d "$LOGDIR" ] || return 0
    _log_rotate
    printf '%s %s engine: %s\n' "$(date '+%m-%d %H:%M:%S')" "$lvl" "$*" >> "$ENGINE_LOG"
}

log_e() { _log E 1 "$@"; }
log_w() { _log W 2 "$@"; }
log_i() { _log I 3 "$@"; }
log_d() { _log D 4 "$@"; }

# --------------------------------------------------------------- fs helpers

# Write stdin to $1 without ever leaving a half-written file behind.
atomic_write() {
    _aw_dst=$1
    _aw_tmp="$_aw_dst.tmp.$$"
    cat > "$_aw_tmp" || { rm -f "$_aw_tmp"; return 1; }
    chmod 600 "$_aw_tmp" 2>/dev/null
    mv -f "$_aw_tmp" "$_aw_dst" || { rm -f "$_aw_tmp"; return 1; }
    return 0
}

ensure_tree() {
    for d in "$CONFDIR" "$RULEDIR" "$STATEDIR" "$RUNDIR" "$LOGDIR" \
             "$BACKUPDIR" "$BINDIR"; do
        [ -d "$d" ] || mkdir -p "$d" 2>/dev/null
    done
    chmod 700 "$DATA" "$CONFDIR" "$STATEDIR" "$RUNDIR" "$BACKUPDIR" 2>/dev/null
    chmod 755 "$RULEDIR" "$BINDIR" "$LOGDIR" 2>/dev/null
}

# ------------------------------------------------------------------ locking

# mkdir is atomic on every filesystem Android uses, which makes it a
# dependable mutex without flock (absent from some toybox builds).
LOCKDIR=$RUNDIR/lock

lock_acquire() {
    _la_wait=${1:-20}
    while [ "$_la_wait" -gt 0 ]; do
        if mkdir "$LOCKDIR" 2>/dev/null; then
            printf '%s\n' "$$" > "$LOCKDIR/pid"
            return 0
        fi
        # Reclaim a lock whose owner no longer exists.
        _la_pid=$(cat "$LOCKDIR/pid" 2>/dev/null)
        if [ -n "$_la_pid" ] && [ ! -d "/proc/$_la_pid" ]; then
            log_w "clearing stale lock from pid $_la_pid"
            rm -rf "$LOCKDIR"
            continue
        fi
        sleep 1
        _la_wait=$((_la_wait - 1))
    done
    log_e "could not acquire lock"
    return 1
}

lock_release() { rm -rf "$LOCKDIR" 2>/dev/null; }

# --------------------------------------------------------------- validation

# Everything that can reach us from the WebUI goes through one of these.
# Nothing else is ever interpolated into a command.

is_int() {
    case "$1" in
        ''|*[!0-9]*) return 1 ;;
        *) return 0 ;;
    esac
}

in_range() {
    is_int "$1" || return 1
    [ "$1" -ge "$2" ] && [ "$1" -le "$3" ]
}

# A conservative package-name / identifier check.
is_pkgname() {
    case "$1" in
        ''|*[!a-zA-Z0-9._]*) return 1 ;;
        .*|*..*) return 1 ;;
        *) [ "${#1}" -le 200 ] ;;
    esac
}

is_domain() {
    case "$1" in
        ''|*[!a-zA-Z0-9.-]*) return 1 ;;
        .*|-*|*.) return 1 ;;
        *) case "$1" in *.*) [ "${#1}" -le 253 ] ;; *) return 1 ;; esac ;;
    esac
}

is_ipaddr() {
    case "$1" in
        ''|*[!0-9a-fA-F.:]*) return 1 ;;
        *) [ "${#1}" -le 45 ] ;;
    esac
}

# one_of VALUE a b c...
one_of() {
    _oo_v=$1; shift
    for _oo_c in "$@"; do
        [ "$_oo_v" = "$_oo_c" ] && return 0
    done
    return 1
}

# ------------------------------------------------------------- process help

pid_alive() {
    [ -n "$1" ] && [ -d "/proc/$1" ]
}

read_pid() {
    [ -f "$1" ] || return 1
    _rp=$(cat "$1" 2>/dev/null)
    is_int "$_rp" || return 1
    printf '%s' "$_rp"
}

# Kill politely, then insistently, then give up rather than hang forever.
stop_pidfile() {
    _sp_pid=$(read_pid "$1") || { rm -f "$1"; return 0; }
    if pid_alive "$_sp_pid"; then
        kill -TERM "$_sp_pid" 2>/dev/null
        _sp_n=0
        while pid_alive "$_sp_pid" && [ "$_sp_n" -lt 10 ]; do
            sleep 1
            _sp_n=$((_sp_n + 1))
        done
        pid_alive "$_sp_pid" && kill -KILL "$_sp_pid" 2>/dev/null
    fi
    rm -f "$1"
    return 0
}

# ------------------------------------------------------------ kill switches

# Any one of these means "do nothing at all". Checked before every start and
# by the supervisor on every tick, so recovery never depends on a reboot.
emergency_off() {
    [ -f "$MODDIR/disable" ] && return 0
    [ -f "$DATA/disable" ] && return 0
    [ -f "$STATEDIR/auto_disabled" ] && return 0
    [ -f /data/local/tmp/directpath_off ] && return 0
    return 1
}

emergency_reason() {
    [ -f "$MODDIR/disable" ] && { printf 'Module disabled in KernelSU'; return; }
    [ -f "$DATA/disable" ] && { printf 'Emergency disable file present'; return; }
    [ -f "$STATEDIR/auto_disabled" ] && {
        printf 'Auto-disabled: %s' "$(cat "$STATEDIR/auto_disabled" 2>/dev/null)"
        return
    }
    [ -f /data/local/tmp/directpath_off ] && { printf 'Disabled via /data/local/tmp'; return; }
    printf 'none'
}

set_status() {
    ensure_tree
    printf '%s\n' "$1" | atomic_write "$STATUSFILE"
}

get_status() {
    cat "$STATUSFILE" 2>/dev/null || printf 'stopped'
}
