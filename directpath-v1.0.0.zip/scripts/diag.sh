#!/system/bin/sh
# diag.sh - measure what is actually wrong, in plain language.
#
# Every line this produces comes from a real probe. Where a probe cannot
# prove something, the verdict says so rather than guessing: "unknown" is a
# legitimate and frequently correct answer on a filtered network.
#
# usage: diag.sh {run|quick|targets|json}

SDIR=${0%/*}
. "$SDIR/lib/util.sh"
. "$SDIR/lib/config.sh"
. "$SDIR/lib/caps.sh"
. "$SDIR/lib/net.sh"

CORE=$BINDIR/dpcore
RESULTS=$RUNDIR/diag.json
LASTRUN=$STATEDIR/diag_last
MIN_INTERVAL=20          # seconds between full runs, to stay off the battery

# Anchors chosen to be individually meaningful:
#   1.1.1.1 / 2606:...  raw reachability, no name involved
#   the rest            one representative host per destination group
TARGETS="www.youtube.com:video
www.instagram.com:social
x.com:social
www.reddit.com:social
discord.com:messaging
web.telegram.org:messaging
github.com:developer
claude.ai:ai
www.google.com:core"

# ------------------------------------------------------------------ helpers

# probe_field OUTPUT KEY
probe_field() {
    printf '%s\n' "$1" | grep -m1 "^$2=" | cut -d= -f2-
}

json_escape() {
    printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g' | tr -d '\n\r\t'
}

rate_limited() {
    [ -f "$LASTRUN" ] || return 1
    _lr=$(cat "$LASTRUN" 2>/dev/null)
    is_int "$_lr" || return 1
    [ $(( $(date '+%s') - _lr )) -lt "$MIN_INTERVAL" ]
}

core_ready() {
    [ -x "$CORE" ] || { log_e "diagnostics need dpcore at $CORE"; return 1; }
    return 0
}

# --------------------------------------------------------------- test units

# test_reach LABEL ADDR PORT -> "state|detail"
test_reach() {
    _out=$("$CORE" --check "$2" "$3" --timeout 5000 2>/dev/null)
    _r=$(probe_field "$_out" result)
    case "$_r" in
        ok)        printf 'working|reachable in %s ms' "$(probe_field "$_out" rtt_ms)" ;;
        refused)   printf 'blocked|the connection was refused' ;;
        timeout)   printf 'unavailable|no response' ;;
        dnsfail)   printf 'unknown|the name could not be resolved' ;;
        *)         printf 'unknown|%s' "$(probe_field "$_out" note)" ;;
    esac
}

# test_dns NAME -> "state|detail"
# Compares an unencrypted UDP answer against a TCP answer from the same
# resolver. Divergence, or a sinkhole address over UDP only, is the
# signature of injected replies.
test_dns() {
    _server=$(printf '%s' "$(cfg_get dns_upstream)" | cut -d, -f1)
    is_ipaddr "$_server" || _server=1.1.1.1

    _u=$("$CORE" --resolve "$1" --server "$_server" --udp \
          --bogus "$RULEDIR/bogus-ip.list" --timeout 3000 2>/dev/null)
    _t=$("$CORE" --resolve "$1" --server "$_server" --tcp \
          --bogus "$RULEDIR/bogus-ip.list" --timeout 4000 2>/dev/null)

    _ur=$(probe_field "$_u" result); _ua=$(probe_field "$_u" address)
    _tr=$(probe_field "$_t" result); _ta=$(probe_field "$_t" address)

    if [ "$_ur" = poisoned ]; then
        printf 'poisoned|UDP answered with a sinkhole address (%s)' "$_ua"
        return
    fi
    if [ "$_ur" = ok ] && [ "$_tr" = ok ] && [ "$_ua" != "$_ta" ]; then
        printf 'suspect|UDP and TCP answers disagree (%s vs %s)' "$_ua" "$_ta"
        return
    fi
    if [ "$_tr" = ok ]; then
        printf 'working|resolved to %s' "$_ta"
        return
    fi
    if [ "$_ur" = ok ]; then
        printf 'partial|only UDP resolution succeeded'
        return
    fi
    case "$_tr" in
        timeout)     printf 'unavailable|the resolver did not answer' ;;
        unreachable) printf 'unavailable|the resolver could not be reached' ;;
        nxdomain)    printf 'working|the resolver says this name does not exist' ;;
        *)           printf 'unknown|%s' "$(probe_field "$_t" note)" ;;
    esac
}

# test_site HOST -> "state|detail"
# Two passes. The first is an unmodified handshake; if that works there is
# nothing to fix. If it does not, the second pass repeats it with the repair
# applied, which turns "this site is blocked" into the far more useful "this
# site is blocked and we can do something about it".
test_site() {
    _plain=$("$CORE" --check "$1" 443 --sni "$1" --strategy none --timeout 6000 2>/dev/null)
    _pr=$(probe_field "$_plain" result)

    case "$_pr" in
        ok)
            printf 'working|normal handshake succeeded in %s ms' "$(probe_field "$_plain" rtt_ms)"
            return ;;
        dnsfail)
            printf 'blocked|the name could not be resolved'
            return ;;
    esac

    cfg_resolve_mode
    _fix=$("$CORE" --check "$1" 443 --sni "$1" --strategy "$RES_STRATEGY" \
            --timeout 6000 2>/dev/null)
    _fr=$(probe_field "$_fix" result)

    if [ "$_fr" = ok ]; then
        printf 'repaired|blocked normally, works with the %s repair' "$RES_STRATEGY"
        return
    fi
    case "$_pr" in
        reset)   printf 'restricted|the handshake was reset, the repair did not help here' ;;
        silent)  printf 'restricted|connected but the server never replied' ;;
        refused) printf 'blocked|the connection was refused' ;;
        timeout) printf 'unavailable|no response, this may be the network rather than filtering' ;;
        *)       printf 'unknown|%s' "$(probe_field "$_plain" note)" ;;
    esac
}

# --------------------------------------------------------------- emit JSON

emit() {
    _name=$1; _state=${2%%|*}; _detail=${2#*|}
    printf '    {"name":"%s","state":"%s","detail":"%s"}' \
        "$(json_escape "$_name")" "$(json_escape "$_state")" "$(json_escape "$_detail")"
}

diag_run() {
    core_ready || return 1
    ensure_tree
    caps_load

    if rate_limited; then
        log_d "diagnostics rate limited, returning the previous run"
        [ -f "$RESULTS" ] && cat "$RESULTS"
        return 0
    fi
    printf '%s\n' "$(date '+%s')" | atomic_write "$LASTRUN"
    log_i "running diagnostics"

    _tmp=$RUNDIR/diag.$$
    {
        printf '{\n  "generated": %s,\n' "$(date '+%s')"
        printf '  "network": {\n'
        printf '    "portal": %s,\n' "$(portal_detected && printf true || printf false)"
        printf '    "ipv6_available": %s,\n' "$([ "$CAP_IPV6_UP" = 1 ] && printf true || printf false)"
        printf '    "private_dns": "%s"\n' "$(private_dns_mode)"
        printf '  },\n'
        printf '  "checks": [\n'

        emit "IPv4 connectivity" "$(test_reach v4 1.1.1.1 443)"; printf ',\n'

        if [ "$CAP_IPV6_UP" = 1 ]; then
            emit "IPv6 connectivity" "$(test_reach v6 2606:4700:4700::1111 443)"
        else
            emit "IPv6 connectivity" "unavailable|no global IPv6 address on this network"
        fi
        printf ',\n'

        emit "DNS resolution" "$(test_dns www.google.com)"; printf ',\n'
        emit "DNS integrity" "$(test_dns www.youtube.com)"; printf ',\n'

        printf '%s\n' "$TARGETS" | while IFS=: read -r host group; do
            [ -n "$host" ] || continue
            printf ',\n'
            emit "$host" "$(test_site "$host")"
        done | sed '1s/^,//'

        printf '\n  ]\n}\n'
    } > "$_tmp"

    mv -f "$_tmp" "$RESULTS"
    chmod 600 "$RESULTS" 2>/dev/null
    cat "$RESULTS"
    log_i "diagnostics complete"
}

# A two-probe version for the dashboard tile: fast and cheap.
diag_quick() {
    core_ready || return 1
    printf '{"dns":"%s","ipv4":"%s"}\n' \
        "$(test_dns www.google.com | cut -d'|' -f1)" \
        "$(test_reach v4 1.1.1.1 443 | cut -d'|' -f1)"
}

case "${1:-run}" in
    run)     diag_run ;;
    quick)   diag_quick ;;
    targets) printf '%s\n' "$TARGETS" ;;
    json)    [ -f "$RESULTS" ] && cat "$RESULTS" || diag_run ;;
    *)       printf 'usage: diag.sh {run|quick|targets|json}\n' >&2; exit 2 ;;
esac
