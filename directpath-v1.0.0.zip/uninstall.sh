#!/system/bin/sh
# uninstall.sh - leave the device exactly as we found it.
#
# Runs when the module is removed. Every step is best effort and none of it
# may fail the removal, so nothing here is allowed to abort. We remove only
# what this module created; no Android setting or user file is touched
# beyond restoring the Private DNS values we ourselves changed.

MODDIR=${0%/*}
DATA=/data/adb/directpath

# 1. Stop supervising, so nothing reinstalls rules behind us.
for f in "$DATA/run/watchdog.pid" "$DATA/run/dpcore.pid"; do
    p=$(cat "$f" 2>/dev/null)
    case "$p" in
        ''|*[!0-9]*) continue ;;
    esac
    kill -TERM "$p" 2>/dev/null
done
sleep 1
for f in "$DATA/run/watchdog.pid" "$DATA/run/dpcore.pid"; do
    p=$(cat "$f" 2>/dev/null)
    case "$p" in
        ''|*[!0-9]*) continue ;;
    esac
    kill -KILL "$p" 2>/dev/null
done

# 2. Remove every rule we may have installed, on both families.
#    Written out longhand rather than sourcing the libraries, because the
#    module directory may already be gone by the time this runs.
for BIN in iptables ip6tables /system/bin/iptables /system/bin/ip6tables; do
    command -v "$BIN" >/dev/null 2>&1 || continue
    n=0
    while "$BIN" -t nat -C OUTPUT -j DP_NAT_OUT >/dev/null 2>&1 && [ $n -lt 8 ]; do
        "$BIN" -t nat -D OUTPUT -j DP_NAT_OUT >/dev/null 2>&1 || break
        n=$((n + 1))
    done
    n=0
    while "$BIN" -t filter -C OUTPUT -j DP_FLT_OUT >/dev/null 2>&1 && [ $n -lt 8 ]; do
        "$BIN" -t filter -D OUTPUT -j DP_FLT_OUT >/dev/null 2>&1 || break
        n=$((n + 1))
    done
    n=0
    while "$BIN" -t filter -C OUTPUT -j DP_V6BLOCK >/dev/null 2>&1 && [ $n -lt 8 ]; do
        "$BIN" -t filter -D OUTPUT -j DP_V6BLOCK >/dev/null 2>&1 || break
        n=$((n + 1))
    done
    for CH in DP_NAT_OUT DP_TCP DP_DNS; do
        "$BIN" -t nat -F "$CH" >/dev/null 2>&1
        "$BIN" -t nat -X "$CH" >/dev/null 2>&1
    done
    for CH in DP_FLT_OUT DP_V6BLOCK DPPROBE; do
        "$BIN" -t filter -F "$CH" >/dev/null 2>&1
        "$BIN" -t filter -X "$CH" >/dev/null 2>&1
        "$BIN" -t nat -F "$CH" >/dev/null 2>&1
        "$BIN" -t nat -X "$CH" >/dev/null 2>&1
    done
done

# 3. Put the Private DNS setting back if we were the ones who changed it.
if [ -f "$DATA/state/private_dns.bak" ] && command -v settings >/dev/null 2>&1; then
    M=$(grep -m1 '^mode=' "$DATA/state/private_dns.bak" | cut -d= -f2-)
    H=$(grep -m1 '^host=' "$DATA/state/private_dns.bak" | cut -d= -f2-)
    case "$M" in
        off|opportunistic|hostname) settings put global private_dns_mode "$M" 2>/dev/null ;;
        *) settings put global private_dns_mode off 2>/dev/null ;;
    esac
    if [ -n "$H" ] && [ "$H" != null ]; then
        settings put global private_dns_specifier "$H" 2>/dev/null
    fi
fi

# 4. Remove our own data directory, and nothing else.
rm -f /data/local/tmp/directpath_off 2>/dev/null
rm -rf "$DATA" 2>/dev/null

exit 0
