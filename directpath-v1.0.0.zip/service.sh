#!/system/bin/sh
# service.sh - late_start. Hands off to the guarded starter and returns.
#
# KernelSU runs this in the background already, but we still detach so a
# slow start can never delay the rest of the boot sequence. All the waiting,
# and all the decisions, happen in boot.sh.

MODDIR=${0%/*}

[ -f "$MODDIR/disable" ] && exit 0
[ -f /data/adb/directpath/disable ] && exit 0
[ -f /data/adb/directpath/state/auto_disabled ] && exit 0
[ -f /data/local/tmp/directpath_off ] && exit 0

[ -x "$MODDIR/scripts/boot.sh" ] || exit 0
"$MODDIR/scripts/boot.sh" service >/dev/null 2>&1 &

exit 0
