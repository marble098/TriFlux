/* DirectPath control panel logic.
 *
 * Security posture of this file:
 *
 *   KernelSU's ksu.exec runs whatever string it is handed, as root. So this
 *   side never builds a command out of free text. Every argument passes
 *   through safeArg(), which accepts a narrow character class and rejects
 *   everything else outright rather than trying to escape it. The shell
 *   side (control.sh) validates all of it a second time and does not trust
 *   this file either. Two independent allowlists, no escaping anywhere.
 */

'use strict';

const CTL = '/data/adb/modules/directpath/scripts/control.sh';
const ARG_OK = /^[A-Za-z0-9._:,-]{1,220}$/;

let cbSeq = 0;
let state = {};
let appCache = [];
let busy = false;

/* ------------------------------------------------------------ ksu bridge */

function rawExec(cmd) {
  return new Promise((resolve, reject) => {
    const ksu = window.ksu;
    if (!ksu || typeof ksu.exec !== 'function') {
      reject(new Error('This page needs to be opened from the KernelSU manager.'));
      return;
    }
    const name = '__dp_cb_' + (cbSeq++);
    let settled = false;

    window[name] = function (errno, stdout, stderr) {
      if (settled) return;
      settled = true;
      delete window[name];
      resolve({ errno: Number(errno) || 0, stdout: stdout || '', stderr: stderr || '' });
    };

    // A command that never calls back would hang the UI forever.
    setTimeout(() => {
      if (settled) return;
      settled = true;
      delete window[name];
      reject(new Error('The command took too long.'));
    }, 90000);

    try {
      // Newer builds take (cmd, options, callback); older ones (cmd, callback).
      if (ksu.exec.length >= 3) ksu.exec(cmd, JSON.stringify({ cwd: '/' }), name);
      else ksu.exec(cmd, name);
    } catch (e) {
      settled = true;
      delete window[name];
      reject(e);
    }
  });
}

function safeArg(v) {
  const s = String(v);
  if (!ARG_OK.test(s)) throw new Error('That value contains characters that are not allowed.');
  return s;
}

async function ctl(verb, ...args) {
  const parts = [CTL, safeArg(verb)];
  for (const a of args) parts.push(safeArg(a));
  const r = await rawExec(parts.join(' '));
  return r.stdout;
}

async function ctlJson(verb, ...args) {
  const out = await ctl(verb, ...args);
  const start = out.search(/[[{]/);
  if (start < 0) throw new Error('The command returned nothing usable.');
  return JSON.parse(out.slice(start));
}

/* --------------------------------------------------------------- helpers */

const $ = (id) => document.getElementById(id);

function toast(msg) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove('show'), 2600);
}

function withBusy(btn, label, fn) {
  return async () => {
    if (busy) return;
    busy = true;
    const old = btn ? btn.textContent : null;
    if (btn) { btn.disabled = true; if (label) btn.textContent = label; }
    try {
      await fn();
    } catch (e) {
      toast(e.message || 'That did not work.');
    } finally {
      busy = false;
      if (btn) { btn.disabled = false; if (old !== null) btn.textContent = old; }
    }
  };
}

function duration(sec) {
  const n = Number(sec) || 0;
  if (n < 60) return n + 's';
  if (n < 3600) return Math.floor(n / 60) + 'm';
  if (n < 86400) return Math.floor(n / 3600) + 'h ' + Math.floor((n % 3600) / 60) + 'm';
  return Math.floor(n / 86400) + 'd ' + Math.floor((n % 86400) / 3600) + 'h';
}

function num(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n.toLocaleString() : '—';
}

/* ----------------------------------------------------- state rendering */

/* Each visible state gets a word and a sentence that says what to do next,
 * because "error" on its own tells nobody anything. */
const STATES = {
  active:     ['ok',      'Working',      'Selected apps are being repaired.'],
  degraded:   ['warn',    'Partly on',    'Some repairs are running, one part had to be switched off.'],
  starting:   ['unknown', 'Starting',     'Bringing the repair up.'],
  recovering: ['warn',    'Recovering',   'Rules were removed after a failure. Retrying shortly.'],
  portal:     ['warn',    'Standing by',  'A Wi-Fi sign-in page was detected. Finish signing in first.'],
  suspended:  ['off',     'Paused',       'Rules removed. The background service is still running.'],
  off:        ['off',     'Off',          'Nothing is redirected. Networking is stock.'],
  stopped:    ['off',     'Off',          'Nothing is redirected. Networking is stock.'],
  disabled:   ['err',     'Switched off', 'A safety switch is set. Clear it to start again.'],
  error:      ['err',     'Not running',  'The repair could not start. Run diagnostics or check the log.'],
  unknown:    ['unknown', 'Unknown',      'Could not read the current status.']
};

function paintPath(s) {
  const strip = $('pathStrip');
  const set = (sel, st) => {
    const el = strip.querySelector(sel);
    if (el) el.setAttribute('data-state', st);
  };

  const running = s.status === 'active' || s.status === 'degraded';
  const dnsOn = s.dns_forwarder === '1' || s.private_dns === 'hostname';

  set('[data-node="app"]', running ? 'ok' : 'unknown');
  set('[data-node="dns"]', dnsOn ? 'ok' : (running ? 'warn' : 'unknown'));
  set('[data-node="tls"]', running ? 'ok' : 'unknown');
  set('[data-node="dest"]', running ? 'ok' : 'unknown');

  // A repaired hop is drawn dashed: it is deliberately segmented traffic.
  set('[data-link="dns"]', dnsOn ? 'warn' : (running ? 'ok' : ''));
  set('[data-link="tls"]', running ? 'warn' : '');
  set('[data-link="dest"]', running ? 'ok' : '');

  let note = '';
  if (running) {
    const bits = [];
    bits.push('handshakes repaired with ' + (s.strategy || 'split'));
    if (dnsOn) bits.push(s.private_dns === 'hostname' ? 'names via Android Private DNS'
                                                      : 'names checked for tampering');
    if (s.quic_block === 'on') bits.push('QUIC held back so apps use TCP');
    note = bits.join(' · ');
  } else if (s.emergency && s.emergency !== 'none') {
    note = s.emergency;
  }
  $('pathNote').textContent = note || '\u00a0';
}

function render(s) {
  state = s;
  const key = STATES[s.status] ? s.status : 'unknown';
  const [cls, word, line] = STATES[key];

  const w = $('stateWord');
  w.textContent = word;
  w.className = 'state-word state-' + cls;

  let detail = line;
  if (key === 'error' && s.last_error && s.last_error !== 'none') detail = s.last_error + '.';
  if (key === 'disabled' && s.emergency && s.emergency !== 'none') detail = s.emergency + '.';
  $('stateLine').textContent = detail;

  const on = s.enabled === '1' && key !== 'disabled';
  const sw = $('master');
  sw.setAttribute('aria-checked', on ? 'true' : 'false');
  sw.setAttribute('aria-busy', 'false');

  $('sRepaired').textContent = num(s.conn_repaired);
  $('sPass').textContent = num(s.conn_passthrough);
  $('sReset').textContent = num(s.reset_seen);
  $('sBogus').textContent = num(s.dns_bogus);
  $('sApps').textContent = s.app_mode === 'all' ? 'all' : num(s.apps);
  $('sUptime').textContent = s.status === 'active' ? duration(s.uptime) : '—';

  $('appModeTag').textContent = s.app_mode || 'selected';

  document.querySelectorAll('#modeSeg button').forEach((b) => {
    b.setAttribute('aria-checked', b.dataset.mode === s.mode ? 'true' : 'false');
  });
  $('modeSub').textContent = ({
    compat:      'Conservative techniques only. The best choice if something misbehaves.',
    auto:        'Picks a technique and steps it up per site when handshakes keep failing.',
    performance: 'Lowest overhead. Blocks QUIC so apps fall back to repairable TCP.',
    aggressive:  'Strongest techniques, applied to every destination. Uses more battery.',
    custom:      'Your own settings, from the Technique section under Advanced.'
  })[s.mode] || '';

  $('verLine').textContent = 'DirectPath ' + (s.version || '?');

  $('dnsHint').textContent = s.private_dns === 'hostname'
    ? 'Android Private DNS is on, so the built-in forwarder stays out of the way.'
    : 'The forwarder asks upstream over TCP and rejects answers that point at known block pages.';

  paintPath(s);
}

/* The advanced pane shows raw settings, which the status view deliberately
 * reports in resolved form, so it is populated from the config dump. */
async function loadSettings() {
  try {
    const c = await ctlJson('config');
    const put = (id, v) => { const el = $(id); if (el && v !== undefined) el.value = v; };
    put('dnsMode', c.dns_mode);
    put('dnsUpstream', c.dns_upstream);
    put('privateDnsHost', c.private_dns_host);
    put('ipv6Mode', c.ipv6_mode);
    put('quicMode', c.block_quic);
    put('logLevel', c.log_level);
    put('strategy', c.strategy);
    put('scope', c.scope);
  } catch (e) { /* the pane simply keeps its defaults */ }
}

async function refresh() {
  try {
    const s = await ctlJson('status');
    render(s);
  } catch (e) {
    render({ status: 'unknown' });
    $('stateLine').textContent = e.message;
  }
}

/* ------------------------------------------------------------ the switch */

async function toggleMaster() {
  const sw = $('master');
  const on = sw.getAttribute('aria-checked') === 'true';
  sw.setAttribute('aria-busy', 'true');
  try {
    await ctl(on ? 'off' : 'on');
    toast(on ? 'Turned off. Networking is back to stock.' : 'Turned on.');
  } catch (e) {
    toast(e.message);
  }
  await refresh();
}

/* ------------------------------------------------------------------ apps */

function renderApps() {
  const q = $('appFilter').value.trim().toLowerCase();
  const showSys = $('showSystem').checked;
  const box = $('appList');

  const rows = appCache.filter((a) =>
    (showSys || !a.system) && (!q || a.pkg.toLowerCase().includes(q)));

  if (!rows.length) {
    box.innerHTML = '<p class="muted">No apps match that filter.</p>';
    return;
  }

  const frag = document.createDocumentFragment();
  rows.slice(0, 400).forEach((a) => {
    const row = document.createElement('label');
    row.className = 'approw' + (a.system ? ' is-system' : '');

    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.checked = a.selected;
    cb.addEventListener('change', async () => {
      cb.disabled = true;
      try {
        await ctl(cb.checked ? 'apps-add' : 'apps-remove', a.pkg);
        a.selected = cb.checked;
      } catch (e) {
        cb.checked = !cb.checked;
        toast(e.message);
      }
      cb.disabled = false;
    });

    const name = document.createElement('span');
    name.className = 'apppkg';
    name.textContent = a.pkg;

    const uid = document.createElement('span');
    uid.className = 'appuid';
    uid.textContent = a.uid;

    row.append(cb, name, uid);
    frag.append(row);
  });

  box.innerHTML = '';
  box.append(frag);
  if (rows.length > 400) {
    const more = document.createElement('p');
    more.className = 'muted';
    more.textContent = rows.length - 400 + ' more. Use the filter to narrow it down.';
    box.append(more);
  }
}

async function loadApps() {
  try {
    appCache = await ctlJson('apps-list');
    renderApps();
  } catch (e) {
    $('appList').innerHTML = '<p class="muted">Could not read the app list.</p>';
  }
}

/* ---------------------------------------------------------------- groups */

async function loadGroups() {
  const box = $('groupList');
  try {
    const groups = await ctlJson('groups-list');
    box.innerHTML = '';
    groups.forEach((g) => {
      const row = document.createElement('label');
      row.className = 'grouprow';

      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.checked = g.enabled;
      cb.addEventListener('change', saveGroups);
      cb.dataset.group = g.name;

      const name = document.createElement('span');
      name.className = 'gname';
      name.textContent = g.name.replace(/-/g, ' ');

      const count = document.createElement('span');
      count.className = 'gcount';
      count.textContent = g.count + ' sites';

      row.append(cb, name, count);
      box.append(row);
    });
  } catch (e) {
    box.innerHTML = '<p class="muted">Could not read the destination groups.</p>';
  }
}

async function saveGroups() {
  const on = [];
  document.querySelectorAll('#groupList input[type=checkbox]').forEach((cb) => {
    if (cb.checked) on.push(cb.dataset.group);
  });
  if (!on.length) { toast('Pick at least one group.'); await loadGroups(); return; }
  try {
    await ctl('groups-set', on.join(','));
    await ctl('apply');
    toast('Destinations updated.');
    refresh();
  } catch (e) {
    toast(e.message);
  }
}

/* ----------------------------------------------------------- diagnostics */

function diagClass(stateName) {
  if (stateName === 'working' || stateName === 'repaired') return 'd-ok';
  if (stateName === 'partial' || stateName === 'suspect' || stateName === 'restricted') return 'd-warn';
  if (stateName === 'poisoned' || stateName === 'blocked') return 'd-err';
  return 'd-unknown';
}

async function runDiag() {
  const box = $('diagOut');
  const strip = $('pathStrip');
  box.innerHTML = '<p class="muted">Testing. This takes up to a minute.</p>';
  strip.classList.add('testing');
  try {
    const data = await ctlJson('diag');
    box.innerHTML = '';
    (data.checks || []).forEach((c) => {
      const row = document.createElement('div');
      row.className = 'diagrow';
      const n = document.createElement('span');
      n.className = 'dname';
      n.textContent = c.name;
      const s = document.createElement('span');
      s.className = 'dstate ' + diagClass(c.state);
      s.textContent = c.state;
      const d = document.createElement('span');
      d.className = 'ddetail';
      d.textContent = c.detail;
      row.append(n, s, d);
      box.append(row);
    });
    if (data.network && data.network.portal) {
      const p = document.createElement('p');
      p.className = 'hint';
      p.textContent = 'A Wi-Fi sign-in page looks to be in the way. Sign in, then test again.';
      box.append(p);
    }
  } catch (e) {
    box.innerHTML = '<p class="muted">The tests could not run: ' + e.message + '</p>';
  } finally {
    strip.classList.remove('testing');
  }
}

/* -------------------------------------------------------- advanced pane */

async function loadCaps() {
  const box = $('capsOut');
  try {
    const c = await ctlJson('caps');
    const rows = [
      ['IPv4 redirection', c.cap_nat4 === '1'],
      ['IPv6 redirection', c.cap_nat6 === '1'],
      ['Per-app matching', c.cap_owner === '1'],
      ['App ranges', c.cap_owner_range === '1'],
      ['Reject target', c.cap_reject === '1'],
      ['TTL control', c.cap_ttl === '1'],
      ['Decoy handshakes', c.cap_tcp_repair === '1'],
      ['IPv6 on this network', c.cap_ipv6_up === '1']
    ];
    box.innerHTML = '';
    rows.forEach(([k, v]) => {
      const a = document.createElement('span'); a.className = 'ck'; a.textContent = k;
      const b = document.createElement('span');
      b.className = 'cv ' + (v ? 'd-ok' : 'd-unknown');
      b.textContent = v ? 'yes' : 'no';
      box.append(a, b);
    });
  } catch (e) {
    box.innerHTML = '<p class="muted">Could not read the capability report.</p>';
  }
}

async function loadLog() {
  try {
    const out = await ctl('logs', '300');
    $('logOut').textContent = out.trim() || 'The log is empty.';
  } catch (e) {
    $('logOut').textContent = 'Could not read the log.';
  }
}

async function copyOut(verb, what) {
  const text = await ctl(verb);
  try {
    await navigator.clipboard.writeText(text);
    toast(what + ' copied.');
  } catch (e) {
    // Clipboard is blocked in some webviews; fall back to a selectable pre.
    $('logOut').textContent = text;
    $('advanced').hidden = false;
    toast('Clipboard is unavailable. Shown in the log box instead.');
  }
}

/* Settings import is done key by key through the same validated verb the
 * rest of the UI uses, so a pasted file can never smuggle in a command. */
async function importSettings() {
  const text = window.prompt('Paste an exported settings block:');
  if (!text) return;
  let ok = 0, skipped = 0;
  for (const raw of text.split('\n')) {
    const line = raw.trim();
    if (!line || line.startsWith('#') || line.startsWith('[')) continue;
    const eq = line.indexOf('=');
    if (eq < 1) continue;
    const k = line.slice(0, eq), v = line.slice(eq + 1);
    if (!/^[a-z_]{2,32}$/.test(k) || (v !== '' && !ARG_OK.test(v))) { skipped++; continue; }
    try {
      const r = JSON.parse(await ctl('set', k, v === '' ? '_EMPTY_' : v));
      r.ok ? ok++ : skipped++;
    } catch (e) { skipped++; }
  }
  await ctl('apply');
  toast('Applied ' + ok + ' settings, skipped ' + skipped + '.');
  refresh();
}

/* --------------------------------------------------------- select wiring */

function bindSelect(id, key, afterApply) {
  const el = $(id);
  el.addEventListener('change', async () => {
    try {
      const r = JSON.parse(await ctl('set', key, el.value || '_EMPTY_'));
      if (!r.ok) throw new Error(r.error);
      if (afterApply) await ctl('apply');
      toast('Saved.');
      refresh();
    } catch (e) {
      toast(e.message || 'That value was not accepted.');
    }
  });
}

function bindText(id, key) {
  const el = $(id);
  el.addEventListener('change', async () => {
    const v = el.value.trim();
    if (v && !ARG_OK.test(v)) { toast('That value contains characters that are not allowed.'); return; }
    try {
      const r = JSON.parse(await ctl('set', key, v === '' ? '_EMPTY_' : v));
      if (!r.ok) throw new Error(r.error);
      await ctl('apply');
      toast('Saved.');
      refresh();
    } catch (e) {
      toast(e.message || 'That value was not accepted.');
    }
  });
}

/* ---------------------------------------------------------------- theme */

const THEMES = ['system', 'dark', 'light'];
const GLYPHS = { system: '◐', dark: '●', light: '○' };

function applyTheme(t) {
  document.documentElement.setAttribute('data-theme', t);
  $('themeGlyph').textContent = GLYPHS[t];
  try { localStorage.setItem('dp-theme', t); } catch (e) { /* private mode */ }
}

/* ------------------------------------------------------------------ init */

function init() {
  let saved = 'system';
  try { saved = localStorage.getItem('dp-theme') || 'system'; } catch (e) { /* ignore */ }
  applyTheme(THEMES.includes(saved) ? saved : 'system');

  $('themeBtn').addEventListener('click', () => {
    const cur = document.documentElement.getAttribute('data-theme');
    applyTheme(THEMES[(THEMES.indexOf(cur) + 1) % THEMES.length]);
  });

  $('advBtn').addEventListener('click', () => {
    const pane = $('advanced');
    const now = pane.hidden;
    pane.hidden = !now;
    $('advBtn').setAttribute('aria-pressed', now ? 'true' : 'false');
    if (now) { loadSettings(); loadCaps(); loadLog(); }
  });

  $('master').addEventListener('click', toggleMaster);

  document.querySelectorAll('#modeSeg button').forEach((b) => {
    b.addEventListener('click', withBusy(null, null, async () => {
      await ctl('mode', b.dataset.mode);
      await ctl('apply');
      toast('Mode set to ' + b.textContent + '.');
      await refresh();
    }));
  });

  document.querySelectorAll('#profileChips button').forEach((b) => {
    b.addEventListener('click', withBusy(b, null, async () => {
      const r = JSON.parse(await ctl('apps-profile', b.dataset.profile));
      if (!r.ok) throw new Error(r.error);
      await ctl('apply');
      toast(b.dataset.profile === 'clear'
        ? 'App selection cleared.'
        : 'Added the installed apps from that group.');
      await loadApps();
      await refresh();
    }));
  });

  $('appFilter').addEventListener('input', renderApps);
  $('showSystem').addEventListener('change', renderApps);

  $('diagBtn').addEventListener('click', withBusy($('diagBtn'), 'Testing', runDiag));
  $('capsBtn').addEventListener('click', withBusy($('capsBtn'), 'Checking', async () => {
    await ctl('caps-refresh');
    await loadCaps();
  }));
  $('logBtn').addEventListener('click', withBusy($('logBtn'), null, loadLog));
  $('logClear').addEventListener('click', withBusy($('logClear'), null, async () => {
    await ctl('logs-clear');
    await loadLog();
    toast('Log cleared.');
  }));

  bindSelect('dnsMode', 'dns_mode', true);
  bindSelect('ipv6Mode', 'ipv6_mode', true);
  bindSelect('quicMode', 'block_quic', true);
  bindSelect('logLevel', 'log_level', true);
  bindText('dnsUpstream', 'dns_upstream');
  bindText('privateDnsHost', 'private_dns_host');

  // Picking a technique by hand implies the user wants custom control.
  ['strategy', 'scope'].forEach((id) => {
    $(id).addEventListener('change', async () => {
      try {
        await ctl('set', id, $(id).value);
        await ctl('mode', 'custom');
        await ctl('apply');
        toast('Switched to Custom with your choice.');
        refresh();
      } catch (e) { toast(e.message); }
    });
  });

  $('expCfg').addEventListener('click', withBusy($('expCfg'), null,
    () => copyOut('export-config', 'Settings')));
  $('expDiag').addEventListener('click', withBusy($('expDiag'), null,
    () => copyOut('export-diagnostics', 'Diagnostics')));
  $('impCfg').addEventListener('click', withBusy($('impCfg'), null, importSettings));

  $('restoreGood').addEventListener('click', withBusy($('restoreGood'), null, async () => {
    const r = JSON.parse(await ctl('restore-good'));
    if (!r.ok) throw new Error(r.error);
    await ctl('apply');
    toast('Restored the last working settings.');
    refresh();
  }));

  $('resetCfg').addEventListener('click', withBusy($('resetCfg'), null, async () => {
    if (!window.confirm('Reset every setting to its default?')) return;
    await ctl('reset-config');
    await ctl('apply');
    toast('Settings reset.');
    refresh(); loadGroups(); loadApps();
  }));

  $('updBtn').addEventListener('click', withBusy($('updBtn'), 'Checking', async () => {
    const r = await ctlJson('update-rules');
    $('updOut').textContent = r.ok
      ? 'Updated ' + r.updated + ' lists' + (r.rejected ? ', ' + r.rejected + ' rejected.' : '.')
      : 'Update failed: ' + r.error;
    loadGroups();
  }));

  $('panicBtn').addEventListener('click', withBusy($('panicBtn'), 'Stopping', async () => {
    if (!window.confirm('Remove all rules and switch the module off?')) return;
    await ctl('panic');
    toast('Everything is off. Networking is back to stock.');
    await refresh();
  }));

  refresh();
  loadGroups();
  loadApps();

  // Cheap periodic refresh while the panel is actually on screen.
  setInterval(() => { if (!document.hidden && !busy) refresh(); }, 12000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refresh(); });
}

document.addEventListener('DOMContentLoaded', init);
